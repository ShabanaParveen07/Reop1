package com.concentrix.executeTest;

import org.testng.TestNG;

import java.util.ArrayList;
import java.util.List;

public class Start {

    public static String TESTNG_ENDPOINT_XML = null;
    public static String TESTNG_ML_XML = null;

    public static void main(String[] args) {
        String user_dir = System.getProperty("user.dir");
        TESTNG_ENDPOINT_XML = user_dir + "/EndPoint-Suite.xml";
        TESTNG_ML_XML= user_dir+ "/ML-Suite.xml";
        List<String> suites = new ArrayList<String>();
        suites.add(TESTNG_ENDPOINT_XML);
        suites.add(TESTNG_ML_XML);
        TestNG testng = new TestNG();
        testng.setTestSuites(suites);
        testng.run();
        System.exit(testng.getStatus());
    }
}
