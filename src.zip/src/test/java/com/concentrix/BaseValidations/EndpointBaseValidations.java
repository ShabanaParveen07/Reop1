package com.concentrix.BaseValidations;

import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.service.streaming.pojo.response.GetAuthenticatedUserConfigResponse;
import com.concentrix.automation.service.streaming.pojo.response.StandardResponse;
import io.restassured.response.Response;
import org.testng.Assert;

public class EndpointBaseValidations {

  public void assertStandardResponse(Response response) {
    StandardResponse standardResponse = response.as(StandardResponse.class);
    Assert.assertEquals(response.getStatusCode(), Integer.parseInt(ConfigurationFileHelper.getInstance().getStatusCode()));
    Assert.assertNotNull(standardResponse.getCorrelationId());
    if (standardResponse.getStatus() != null)
      Assert.assertTrue(standardResponse.getStatus());
    else
      Assert.assertTrue(standardResponse.getSuccess());
  }

  public void assertGetAuthenticatedUserConfigResponse(Response response) {
    GetAuthenticatedUserConfigResponse standardResponse = response.as(GetAuthenticatedUserConfigResponse.class);
    Assert.assertEquals(response.getStatusCode(), Integer.parseInt(ConfigurationFileHelper.getInstance().getStatusCode()));
    Assert.assertNotNull(standardResponse.getCorrelationId());
    Assert.assertTrue(standardResponse.getSuccess());
  }
}
