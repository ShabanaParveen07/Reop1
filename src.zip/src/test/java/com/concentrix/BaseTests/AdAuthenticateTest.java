package com.concentrix.BaseTests;


import com.concentrix.automation.helper.ConfigurationFileHelper;
import org.apache.oltu.oauth2.client.OAuthClient;
import org.apache.oltu.oauth2.client.URLConnectionClient;
import org.apache.oltu.oauth2.client.request.OAuthClientRequest;
import org.apache.oltu.oauth2.client.response.OAuthJSONAccessTokenResponse;
import org.apache.oltu.oauth2.common.OAuth;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class AdAuthenticateTest {

  public static String getAuthToken() {
    String clientId = ConfigurationFileHelper.getInstance().getClientId();
    String clientSecret = ConfigurationFileHelper.getInstance().getClientSecret();
    String tenetId = ConfigurationFileHelper.getInstance().getTenetId();
    String secureCxAppId = ConfigurationFileHelper.getInstance().getSecureCxAppId();
    String accessTokenUrl = "https://login.microsoftonline.com/" + tenetId + "/oauth2/v2.0/token";

    String encodedValue = getBase64Encoded(clientId, clientSecret);
    OAuthClient client = new OAuthClient(new URLConnectionClient());
    try {
      OAuthClientRequest request =
          OAuthClientRequest.tokenLocation(accessTokenUrl)
              .setGrantType(org.apache.oltu.oauth2.common.message.types.GrantType.CLIENT_CREDENTIALS)
              .setScope("api://" + secureCxAppId + "/.default")
              .buildBodyMessage();
      request.addHeader("Authorization", "Basic " + encodedValue);
      //OAuthClientRequest.authorizationProvider(OAuthProviderType.MICROSOFT);

      OAuthJSONAccessTokenResponse token = client.accessToken(request, OAuth.HttpMethod.POST, OAuthJSONAccessTokenResponse.class);
      String finalToken = token.getAccessToken();

      System.out.println("Token-->" + finalToken);
      return finalToken;

    } catch (OAuthSystemException e) {


      System.out.println(e);
      //e.printStackTrace();
    } catch (OAuthProblemException e) {
      throw new RuntimeException(e);
    }

    return null;
  }

  public static String getBase64Encoded(String id, String password) {
    return Base64.getEncoder().encodeToString((id + ":" + password).getBytes(StandardCharsets.UTF_8));
  }
}
