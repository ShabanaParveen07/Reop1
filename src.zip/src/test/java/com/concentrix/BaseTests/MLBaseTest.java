package com.concentrix.BaseTests;

import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.helper.DBConnectionHelper;
import com.concentrix.automation.helper.FileHelper;
import com.concentrix.automation.helper.streaming.MLConfusionMetricsHelper;
import com.concentrix.automation.helper.streaming.StreamingApiHelper;
import com.concentrix.automation.service.streaming.constants.EndPointConstants;
import com.concentrix.automation.service.streaming.pojo.request.AuthenticationRequest;
import com.concentrix.automation.service.streaming.pojo.request.TestData;
import com.concentrix.automation.service.streaming.pojo.response.GeneralResponse;
import com.concentrix.automation.service.streaming.pojo.response.GetLastImageProcessedStatusResponse;
import io.restassured.response.Response;
import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.concentrix.automation.helper.DateHelper.convertTimeToGivenDateFormat;
import static com.concentrix.automation.service.streaming.constants.EndPointConstants.FACE_AUTH_MODE_RESUME;

@Log4j
public class MLBaseTest extends ConcentrixBaseTest {
  String imageData;
  GeneralResponse generalResponse;
  StreamingApiHelper streamingApiHelper;

  public final String user_dir = System.getProperty("user.dir");

  protected static ArrayList<List<String>> list = new ArrayList<>();

  @BeforeSuite(alwaysRun = true)
  public void setup() {
    streamingApiHelper = new StreamingApiHelper();
    // Deleting confusion metrics data
    FileHelper.deleteDirectory("./mlConfusionMetricsResults");
    // Deleting test output images
    FileHelper.deleteDirectory("test-output/images");
    //Deleting Actual results
    FileHelper.deleteDirectory("test-output/Actual Results");
    //Executing flush cache and check base validation API
    streamingApiHelper.refreshFaceStreaming(ConfigurationFileHelper.getInstance().getLanID());
    streamingApiHelper.getCheckBaseValidation(ConfigurationFileHelper.getInstance().getLanID());
  }

  @AfterSuite
  public void tearDown(ITestContext context) {
    log.info("****************** Results after suite execution *******************");
    log.info("cellphonePRE_TP" + " " + context.getAttribute("cellphonePRE_TP"));
    log.info("cellphonePRE_FN" + " " + context.getAttribute("cellphonePRE_FN"));
    log.info("cellphonePRE_TN" + " " + context.getAttribute("cellphonePRE_TN"));
    log.info("cellphonePRE_FP" + " " + context.getAttribute("cellphonePRE_FP"));

    log.info("cellphoneTP" + " " + context.getAttribute("cellphoneTP"));
    log.info("cellphoneFN" + " " + context.getAttribute("cellphoneFN"));
    log.info("cellphoneTN" + " " + context.getAttribute("cellphoneTN"));
    log.info("cellphoneFP" + " " + context.getAttribute("cellphoneFP"));

    log.info("blockedCameraTP" + " " + context.getAttribute("blockedCameraTP"));
    log.info("blockedCameraFN" + " " + context.getAttribute("blockedCameraFN"));
    log.info("blockedCameraTN" + " " + context.getAttribute("blockedCameraTN"));
    log.info("blockedCameraFP" + " " + context.getAttribute("blockedCameraFP"));

    log.info("multiplePersonPRE_TP" + " " + context.getAttribute("multiplePersonPRE_TP"));
    log.info("multiplePersonPRE_FN" + " " + context.getAttribute("multiplePersonPRE_FN"));
    log.info("multiplePersonPRE_TN" + " " + context.getAttribute("multiplePersonPRE_TN"));
    log.info("multiplePersonPRE_FP" + " " + context.getAttribute("multiplePersonPRE_FP"));

    log.info("noFaceFound_TP" + " " + context.getAttribute("noFaceFound_TP"));
    log.info("noFaceFound_FN" + " " + context.getAttribute("noFaceFound_FN"));
    log.info("noFaceFound_TN" + " " + context.getAttribute("noFaceFound_TN"));
    log.info("noFaceFound_FP" + " " + context.getAttribute("noFaceFound_FP"));

    log.info("multiplePerson_TP" + " " + context.getAttribute("multiplePerson_TP"));
    log.info("multiplePerson_FN" + " " + context.getAttribute("multiplePerson_FN"));
    log.info("multiplePerson_TN" + " " + context.getAttribute("multiplePerson_TN"));
    log.info("multiplePerson_FP" + " " + context.getAttribute("multiplePerson_FP"));

    log.info("spoofTP" + " " + context.getAttribute("spoofTP"));
    log.info("spoofFN" + " " + context.getAttribute("spoofFN"));
    log.info("spoofTN" + " " + context.getAttribute("spoofTN"));
    log.info("spoofFP" + " " + context.getAttribute("spoofFP"));

    log.info("spoofPossibilityTP" + " " + context.getAttribute("spoofPossibilityTP"));
    log.info("spoofPossibilityFN" + " " + context.getAttribute("spoofPossibilityFN"));
    log.info("spoofPossibilityTN" + " " + context.getAttribute("spoofPossibilityTN"));
    log.info("spoofPossibilityFP" + " " + context.getAttribute("spoofPossibilityFP"));

    log.info("facialAuthenticationFailedTP" + " " + context.getAttribute("facialAuthenticationFailed_TP"));
    log.info("facialAuthenticationFailedFN" + " " + context.getAttribute("facialAuthenticationFailed_FN"));
    log.info("facialAuthenticationFailedTN" + " " + context.getAttribute("facialAuthenticationFailed_TN"));
    log.info("facialAuthenticationFailedFP" + " " + context.getAttribute("facialAuthenticationFailed_FP"));

    log.info("Actual Result ids:" + " " + context.getAttribute("resultList"));
    if (context.getAttribute("resultList") != null) {
      List<List<String>> actualResultslist = (List<List<String>>) context.getAttribute("resultList");
      if (!actualResultslist.isEmpty()) {
        createActualResultCsvFile(actualResultslist);
        FileHelper.createFailedTestJsonFile(actualResultslist);
      }
    }
    try {
      log.info("Calculating Confusion Matrix:");

      MLConfusionMetricsHelper mlConfusionMetricsHelper = new MLConfusionMetricsHelper();

      if (context.getAttribute("multiplePersonPRE") != null)
        mlConfusionMetricsHelper.generateValidationDataSet("Multiple person PRE", (int) context.getAttribute("multiplePersonPRE_TP"), (int) context.getAttribute("multiplePersonPRE_FP"), (int) context.getAttribute("multiplePersonPRE_FN"), (int) context.getAttribute("multiplePersonPRE_TN"));
      if (context.getAttribute("multiplePerson") != null)
        mlConfusionMetricsHelper.generateValidationDataSet("Multiple Person", (int) context.getAttribute("multiplePerson_TP"), (int) context.getAttribute("multiplePerson_FP"), (int) context.getAttribute("multiplePerson_FN"), (int) context.getAttribute("multiplePerson_TN"));
      if (context.getAttribute("blockedCameraTP") != null)
        mlConfusionMetricsHelper.generateValidationDataSet("Blocked Camera", (int) context.getAttribute("blockedCameraTP"), (int) context.getAttribute("blockedCameraFP"), (int) context.getAttribute("blockedCameraFN"), (int) context.getAttribute("blockedCameraTN"));
      if (context.getAttribute("cellphonePRE") != null)
        mlConfusionMetricsHelper.generateValidationDataSet("Cell Phone PRE", (int) context.getAttribute("cellphonePRE_TP"), (int) context.getAttribute("cellphonePRE_FP"), (int) context.getAttribute("cellphonePRE_FN"), (int) context.getAttribute("cellphonePRE_TN"));
      if (context.getAttribute("cellphone") != null)
        mlConfusionMetricsHelper.generateValidationDataSet("Cell Phone", (int) context.getAttribute("cellphoneTP"), (int) context.getAttribute("cellphoneFP"), (int) context.getAttribute("cellphoneFN"), (int) context.getAttribute("cellphoneTN"));
      if (context.getAttribute("spoofTP") != null)
        mlConfusionMetricsHelper.generateValidationDataSet("Spoof Images", (int) context.getAttribute("spoofTP"), (int) context.getAttribute("spoofFP"), (int) context.getAttribute("spoofFN"), (int) context.getAttribute("spoofTN"));
      if (context.getAttribute("spoofPossibilityTP") != null) {
        System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------");
        System.out.format("%30s %20s %20s %5s %5s %5s %5s %10s %10s %10s %10s", ConfigurationFileHelper.getInstance().getModelName(), "Spoof Possibility", (int) context.getAttribute("spoofPossibilityTP") + (int) context.getAttribute("spoofPossibilityFP") + (int) context.getAttribute("spoofPossibilityFN") + (int) context.getAttribute("spoofPossibilityTN"), context.getAttribute("spoofPossibilityTP"), context.getAttribute("spoofPossibilityFP"), context.getAttribute("spoofPossibilityFN"), context.getAttribute("spoofPossibilityTN"), "NA", "NA", "NA", "NA");
        System.out.println();
        System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------");
      }
      if (context.getAttribute("noFaceFound_TP") != null)
        mlConfusionMetricsHelper.generateValidationDataSet("No Face Found", (int) context.getAttribute("noFaceFound_TP"), (int) context.getAttribute("noFaceFound_FP"), (int) context.getAttribute("noFaceFound_FN"), (int) context.getAttribute("noFaceFound_TN"));
      if (context.getAttribute("facialAuthenticationFailed_TP") != null)
        mlConfusionMetricsHelper.generateValidationDataSet("Facial Authentication Failed", (int) context.getAttribute("facialAuthenticationFailed_TP"), (int) context.getAttribute("facialAuthenticationFailed_FP"), (int) context.getAttribute("facialAuthenticationFailed_FN"), (int) context.getAttribute("facialAuthenticationFailed_TN"));
    } catch (NullPointerException e) {
      log.error(e.getMessage());
    }
  }

  @SneakyThrows
  protected Response executeMlAPIs(File file) {
    Response response;
    streamingApiHelper = new StreamingApiHelper();
    String formattedTimeStamp = convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss");
    HashMap<Object, Object> faceStreamingRequestMap = createFaceStreamingRequestMap(
        authToken, ipAddress.toString().split("/")[1], hostName, formattedTimeStamp, file);
    response = streamingApiHelper.postImageToStreaming(authToken, faceStreamingRequestMap);
    if(response.getStatusCode() != 200){
      return response;
    }else{
      generalResponse = response.getBody().as(GeneralResponse.class);
      imageData = generalResponse.getData();
      Thread.sleep(5000);
      response = streamingApiHelper.getLastImageProcessedStatus(
          imageData, ConfigurationFileHelper.getInstance().getLanID());
      //Added loop to handle API latency issue
      for (int i = 0; i < 3; i++) {
        if (response.getStatusCode() == 204) {
          log.warn("Retrying count " + i);
          Thread.sleep(8000);
          response = streamingApiHelper.getLastImageProcessedStatus(
              imageData, ConfigurationFileHelper.getInstance().getLanID());
        } else
          break;
      }
    }
    return response;
  }

  @SneakyThrows
  protected Response executeMlAPIsForSpoof(File file) {
    Response response;
    //Customise the request with Additional Parameters
    HashMap<Object, Object> additionalParams = new HashMap<>();
    additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_RESUME);
    additionalParams.put("BlurType", "NoBlur");
    streamingApiHelper = new StreamingApiHelper();
    String formattedTimeStamp = convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss");
    HashMap<Object, Object> faceStreamingRequestMap = createFaceStreamingRequestMapWithAdditionalParams(
        authToken, ipAddress.toString().split("/")[1], hostName,
        formattedTimeStamp, file, additionalParams);
    response = streamingApiHelper.postImageToStreaming(authToken, faceStreamingRequestMap);
    generalResponse = response.getBody().as(GeneralResponse.class);
    imageData = generalResponse.getData();
    Thread.sleep(5000);
    response = streamingApiHelper.getLastImageProcessedStatus(
        imageData, ConfigurationFileHelper.getInstance().getLanID());
    //Added loop to handle API latency issue
    for(int i=0;i<3;i++){
      if (response.getStatusCode() == 204) {
        Thread.sleep(5000);
        response = streamingApiHelper.getLastImageProcessedStatus(
            imageData, ConfigurationFileHelper.getInstance().getLanID());
      }else
        break;
    }

    return response;
  }

  @SneakyThrows
  protected Response executeMlAPIsForSpoof(File file,String authTokenValue,String lanId) {
    Response response;
    //Customise the request with Additional Parameters
    HashMap<Object, Object> additionalParams = new HashMap<>();
    additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_RESUME);
    additionalParams.put("LanId", lanId);
    additionalParams.put("BlurType", "NoBlur");
    streamingApiHelper = new StreamingApiHelper();
    String formattedTimeStamp = convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss");
    HashMap<Object, Object> faceStreamingRequestMap = createFaceStreamingRequestMapWithSpecificUser(
        authTokenValue, ipAddress.toString().split("/")[1], hostName,
        formattedTimeStamp, file, additionalParams);
    response = streamingApiHelper.postImageToStreaming(authToken, faceStreamingRequestMap);
    if(response.getStatusCode() != 200){
      return response;
    }else{
      generalResponse = response.getBody().as(GeneralResponse.class);
      imageData = generalResponse.getData();
      Thread.sleep(5000);
      response = streamingApiHelper.getLastImageProcessedStatus(
          imageData, lanId);
      //Added loop to handle API latency issue
      for(int i=0;i<3;i++){
        if (response.getStatusCode() == 204) {
          log.warn("Retrying count " + i);
          Thread.sleep(5000);
          response = streamingApiHelper.getLastImageProcessedStatus(
              imageData, lanId);
        }else
          break;
      }
    }
    return response;
  }

  public String generateAuthToken(String landId) throws UnknownHostException {
    String token;
    streamingApiHelper = new StreamingApiHelper();
    ipAddress = InetAddress.getLocalHost();
    // hostName = ipAddress.getHostName();
    hostName = "CNX-Test";
    log.info(hostName);
    AuthenticationRequest authenticationRequest = AuthenticationRequest.builder().
        utcOffsetinSecs(ConfigurationFileHelper.getInstance().getUtcOffsetinSecs()).
        lanID(landId).
        applicationKey(ConfigurationFileHelper.getInstance().getApplicationKey()).
        sSOId(landId).
        streamingAppVersion(ConfigurationFileHelper.getInstance().getStreamingAppVersion()).
        systemIP(ipAddress.toString().split("/")[1]).
        systemName(hostName)
        .build();
    Response response = streamingApiHelper.authenticateStreaming(authenticationRequest);
    GeneralResponse generalResponse = response.getBody().as(GeneralResponse.class);
    token = generalResponse.getResponseResult();
    Assert.assertEquals(generalResponse.getResponseStatus(), "Success");
    return token;
  }

  protected void assertResponseData(Response response, Integer resultId) {
    GetLastImageProcessedStatusResponse getLastImageProcessedStatusResponse = response.getBody().as(
        GetLastImageProcessedStatusResponse.class);
    Assert.assertEquals(response.getStatusCode(), EndPointConstants.responseOK, "Actual status code: " + response.getStatusCode());
    Assert.assertNotNull(getLastImageProcessedStatusResponse.getImageBagID());
    Assert.assertNotNull(getLastImageProcessedStatusResponse.getProcessedOn());
    Assert.assertEquals(getLastImageProcessedStatusResponse.getResultId(), resultId, "Actual result Id: " + getLastImageProcessedStatusResponse.getResultId());
  }

  protected String getTestName(ITestResult result) {
    String testName = "";
    for (Object param : result.getParameters()) {
      TestData testData = (TestData) param;
      testName = testData.getFileName();
      log.info("Test name: " + testName);
    }
    return testName;
  }

  protected TestData getTestData(ITestResult result) {
    String testName;
    TestData testData = null;
    for (Object param : result.getParameters()) {
      testData = (TestData) param;
      testName = testData.getFileName();
      log.info("Test name: " + testName);
    }
    return testData;
  }

  protected void writeImageToPath(File file, boolean isFailedImage) {
    BufferedImage image;
    String result = "";
    if (file.getParent().contains("/")) {
      result = file.getParent().replace("src/test/resources/ML", "test-output/images");
    } else if (file.getParent().contains("\\")) {
      result = file.getParent().replace("src\\test\\resources\\ML", "test-output/images");
    }
    if (isFailedImage) {
      result = result.contains("TP") ? result.replace("TP", "FN") : result.replace("TN", "FP");
    }
    File path = new File(result);
    try {
      if (!path.exists()) {
        path.mkdirs();
      }
      image = ImageIO.read(file);
      ImageIO.write(image, "jpg", new File(path + "/" + file.getName()));
    } catch (IOException e) {
      log.error(e.getMessage());
    }
  }

  protected void saveActualResult(String fileName, int resultId, String testName, String expectedResultId, String filePath, String imagePathId) {
    ArrayList<String> data = new ArrayList<>();
    data.add(testName);
    data.add(fileName);
    data.add(String.valueOf(resultId));
    data.add(String.valueOf(expectedResultId));
    data.add(filePath.replace("\\", "/"));
    data.add(imagePathId);
    list.add(data);
  }

  protected void saveActualResult(String fileName, int resultId, double spoofScore, String testName, String expectedResultId, String filePath) {
    ArrayList<String> data = new ArrayList<>();
    data.add(testName);
    data.add(fileName);
    data.add(String.valueOf(resultId));
    data.add(String.valueOf(expectedResultId));
    data.add(user_dir.replace("\\", "/") + "/" + filePath);
    data.add(String.valueOf(spoofScore));
    list.add(data);
  }

  protected void saveActualResult(String fileName, int resultId, double spoofScore,String resData,String accuracy, String testName, String expectedResultId, String filePath) {
    ArrayList<String> data = new ArrayList<>();
    data.add(testName);
    data.add(fileName);
    data.add(String.valueOf(resultId));
    data.add(String.valueOf(expectedResultId));
    data.add(user_dir.replace("\\", "/") + "/" + filePath);
    data.add(String.valueOf(spoofScore));
    data.add(accuracy);
    data.add(resData);
    list.add(data);
  }


  protected void createActualResultCsvFile(List<List<String>> list) {
    Date date = new Date(System.currentTimeMillis());
    DateFormat format = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
    File dir = new File("test-output/Actual Results");
    if (!dir.exists() && !list.isEmpty())
      dir.mkdirs();
    String csvFilePath = dir + "/ActualResult" + "_" + format.format(date) + ".csv";
    try (
        BufferedWriter writer = Files.newBufferedWriter(Paths.get(csvFilePath));
        CSVPrinter csvPrinter = new CSVPrinter(writer, CSVFormat.DEFAULT.withHeader("Test Name", "Image File Name", "Actual result Id", "Expected result Id", "Image File Path", "Image Path Id", "Spoof Score"))
    ) {
      for (List<String> record : list) {
        if (record.size() == 6)
          csvPrinter.printRecord(record.get(0), record.get(1), record.get(2), record.get(3), record.get(4), record.get(5));
        else if (record.size() == 7)
          csvPrinter.printRecord(record.get(0), record.get(1), record.get(2), record.get(3), record.get(4), record.get(5), record.get(6));
        else if (record.size() == 8)
          csvPrinter.printRecord(record.get(0), record.get(1), record.get(2), record.get(3), record.get(4), record.get(5), record.get(6),record.get(7));
      }
      csvPrinter.flush();
    } catch (IOException e) {
      log.error(e.getMessage());
    }
  }

  /*
   Read actual result CSV file and create CSB file with confidence score for FP images
   */
  protected void createCSVFileWithConfidenceScore() {
    List<List<String>> actualResulsList = new ArrayList<>();
    String envName = System.getProperty("env");
    if (envName == null)
      envName = "qa";
    String line;
    DBConnectionHelper dbConnectionHelper = DBConnectionHelper.getInstance();
    String splitBy = ",";
    try {
      BufferedReader br = new BufferedReader(new FileReader("ActualResult.csv"));
      while ((line = br.readLine()) != null) {
        String[] record = line.split(splitBy);
        if (record[0].endsWith("TNTest") && record.length == 6) {
          ResultSet rs1 = dbConnectionHelper.executeQuery("SELECT * from fb_biometrics_" + envName + ".imageprocess_status where imagePath in ('" + record[5] + "')");
          while (rs1.next()) {
            String confidenceScore = rs1.getString("confidence");
            log.info("Confidence score is: " + confidenceScore);
            ArrayList<String> recordList = new ArrayList<>();
            recordList.addAll(Arrays.asList(record));
            recordList.add(confidenceScore);
            actualResulsList.add(recordList);
          }
          rs1.close();
        }
      }
      createActualResultCsvFile(actualResulsList);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

}

