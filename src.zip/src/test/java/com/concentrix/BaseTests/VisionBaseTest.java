package com.concentrix.BaseTests;

import com.concentrix.automation.helper.DBConnectionHelper;
import com.concentrix.automation.helper.vision.VisionHelper;
import com.concentrix.automation.service.vision.constants.VisionConstants;
import com.concentrix.automation.service.vision.pojo.response.TokenDataResponse;
import com.concentrix.automation.service.vision.pojo.response.UserTokenResponse;
import com.concentrix.automation.service.vision.pojo.response.VisionStandardResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.response.Response;
import lombok.extern.log4j.Log4j;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Base64;

import static com.concentrix.automation.helper.DateHelper.convertTimeToGivenDateFormat;

@Log4j
public class VisionBaseTest {
  public VisionHelper visionHelper = new VisionHelper();
  public static String EmailId;
  public static String Token;
  public static Response response;
  public static ObjectMapper objectMapper = new ObjectMapper();
  public static DBConnectionHelper dbConnectionHelper;
  public  static UserTokenResponse userTokenResponse;
  public final String imageFilePath = System.getProperty("user.dir") + File.separator + "src" + File.separator + "test" + File.separator + "resources" + File.separator + "ML" + File.separator + "EnrollmentImages" + File.separator;


  @BeforeSuite(alwaysRun = true)
  public void Setup() throws JsonProcessingException {
    String timestamp = convertTimeToGivenDateFormat("HHmmss");
    EmailId =String.format(VisionConstants.EMIALID,timestamp);
    response = visionHelper.TokenHelper(EmailId);
    VisionStandardResponse standardResponse = response.as(VisionStandardResponse.class);
    TokenDataResponse tokenDataResponse = objectMapper.readValue(standardResponse.getData(), TokenDataResponse.class);
    Token = tokenDataResponse.getAccessToken();
     userTokenResponse = objectMapper.readValue(decodeString(tokenDataResponse.getUserToken()),UserTokenResponse.class);
    dbConnectionHelper = DBConnectionHelper.getInstance();
  }

  public String imageToBase64Converter(String filePath) {
    String base64 = "";
    File file = new File(filePath);
    try (FileInputStream fis = new FileInputStream(file);
         ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
      byte[] buf = new byte[1024];
      for (int readNum; (readNum = fis.read(buf)) != -1; ) {
        bos.write(buf, 0, readNum);
      }
      byte[] bytes = bos.toByteArray();
      base64 = Base64.getEncoder().encodeToString(bytes);
    } catch (IOException e) {
      log.error(e.getMessage());
    }
    return base64;
  }

  public String decodeString(String encodedValue){
    return new String(Base64.getDecoder().decode(encodedValue));
  }
  @AfterSuite(alwaysRun = true)
  public void TearDown() throws SQLException {
    dbConnectionHelper.closeConnection();
  }

}
