package com.concentrix.BaseTests;

import com.concentrix.automation.helper.Base64Helper;
import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.helper.GCSHelper;
import com.concentrix.automation.helper.streaming.StreamingApiHelper;
import com.concentrix.automation.rest.ConversionUtil;
import com.concentrix.automation.service.corebr.pojo.request.ApproveAgentMonitoringRequest;
import com.concentrix.automation.service.corebr.pojo.request.BulkUpsertConfigurations;
import com.concentrix.automation.service.corebr.pojo.request.BulkUpsertRequest;
import com.concentrix.automation.service.streaming.pojo.request.AuthenticationRequest;
import com.concentrix.automation.service.streaming.pojo.request.FaceAuthRequest;
import com.concentrix.automation.service.streaming.pojo.request.FaceStreamingRequest;
import com.concentrix.automation.service.streaming.pojo.request.FeedbackRequest;
import com.concentrix.automation.service.streaming.pojo.response.GeneralResponse;

import static com.concentrix.automation.helper.DateHelper.convertTimeToGivenDateFormat;
import static com.concentrix.automation.service.streaming.constants.EndPointConstants.BASE_LINE_IMAGE;
import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

import com.concentrix.automation.service.streaming.pojo.response.ResponseResult;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.playwright.*;

import com.microsoft.playwright.options.AriaRole;
import com.microsoft.playwright.options.LoadState;
import io.restassured.response.Response;
import lombok.Getter;
import lombok.extern.log4j.Log4j;
import org.apache.oltu.oauth2.client.OAuthClient;
import org.apache.oltu.oauth2.client.URLConnectionClient;
import org.apache.oltu.oauth2.client.request.OAuthClientRequest;
import org.apache.oltu.oauth2.client.response.OAuthJSONAccessTokenResponse;
import org.apache.oltu.oauth2.common.OAuth;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

import java.io.*;
import java.net.InetAddress;
import java.net.UnknownHostException;

import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;

import java.util.Arrays;

import java.util.Base64;
import java.util.HashMap;
import java.util.regex.Pattern;


@Log4j
public class ConcentrixBaseTest {

  protected InetAddress ipAddress;

  protected String authToken;

  protected String hostName;

  protected StreamingApiHelper streamingApiHelper;

  private final String imageFolder = System.getProperty("user.dir") + "//src//test//resources//Endpoint//";

  public enum CreateViolationScenarios {
    BLOCKED_CAMERA,
    CELL_PHONE_ONLY_ONCE,
    CELL_PHONE_CONSECUTIVELY,

    NO_FACES_FOUND,

    NO_FACES_FOUND_CONSECUTIVELY,
    MULTIPLE_PERSONS,
    MULTIPLE_PERSONS_CONSECUTIVELY,

  }

  public enum AuthenticationScenariosWithBlurType {
    NO_BLUR_SUCCESS,

    NO_BLUR_NO_FACES_FOUND,

    NO_BLUR_MULTIPLE_PERSONS,

    NO_BLUR_CELL_PHONE,

    NO_BLUR_BLOCKED_CAMERA,

    NO_BLUR_OTHER_PERSON,

    NO_BLUR_OTHER_PERSON_CONSECUTIVELY,

    SECONDARY_PERSON_BLUR_SUCCESS,

    SECONDARY_PERSON_BLUR_NO_FACES_FOUND,

    SECONDARY_PERSON_BLUR_MULTIPLE_PERSONS,

    SECONDARY_PERSON_BLUR_CELL_PHONE,

    SECONDARY_PERSON_BLUR_BLOCKED_CAMERA,

    SECONDARY_PERSON_BLUR_OTHER_PERSON,

    SECONDARY_PERSON_BLUR_OTHER_PERSON_CONSECUTIVELY,

    BLUR_BACKGROUND_SUCCESS,

    BLUR_BACKGROUND_NO_FACES_FOUND,

    BLUR_BACKGROUND_MULTIPLE_PERSONS,

    BLUR_BACKGROUND_CELL_PHONE,

    BLUR_BACKGROUND_BLOCKED_CAMERA,

    BLUR_BACKGROUND_OTHER_PERSON,

    BLUR_BACKGROUND_OTHER_PERSON_CONSECUTIVELY,

    NO_BLUR_SPOOF,

    SECONDARY_PERSON_BLUR_SPOOF,

    BLUR_BACKGROUND_SPOOF

  }

  public enum FeedbackScenarios {

    FEEDBACK_TYPE_I_FOUND_A_BUG,

    FEEDBACK_TYPE_I_HAVE_A_SUGGESTION,

    FEEDBACK_TYPE_OTHER,

    FEEDBACK_TYPE_NULL
  }

  public enum ClientEventAuditScenarios {
    LOCK("Lock"),
    UNLOCK("Unlock"),
    CAMERA_CONNECTED("CameraConnected"),

    CAMERA_DISCONNECTED("CameraDisconnected"),

    FACIAL_AUTHENTICATION_PASSED("FacialAuthenticationPassed"),
    FACIAL_AUTHENTICATION_FAILED("FacialAuthenticationFailed"),
    FACIAL_AUTHENTICATION_PASSED_ON_RESUME("FacialAuthenticationPassedOnResume"),
    FACIAL_AUTHENTICATION_FAILED_ON_RESUME("FacialAuthenticationFailedOnResume"),
    FACIAL_AUTHENTICATION_DURING_SESSION_PASSED("FacialAuthenticationDuringSessionPassed"),
    FACIAL_AUTHENTICATION_DURING_SESSION_FAILED("FacialAuthenticationDuringSessionFailed"),
    PREVIEW_BY_USER("PreviewByUser");
    private final String label;

    private ClientEventAuditScenarios(String label) {
      this.label = label;
    }

    public String getLabel() {
      return this.label;
    }

  }

  @Getter
  public enum AgentErrorLogScenarios {
    NETWORK_ISSUE("NetworkIssue", "Network disconnected. please check wifi or Lan connection."),

    DATA_ISSUE("DataIssue", "Your enrollment images not found."),

    APP_CRASH("AppCrash", "App Quit"),

    ACCESS_BLOCKED("AccessBlocked", "Authentication failed. Null response."),

    CAMERA_ERROR("CameraError", "Camera NameIntegrated Camera Poor image or blank image received from camera."),

    USB_CAMERA("USBCamera", "Camera Model: A4tech FHD 1080P PC Camera (Disconnected), SecureCx CPU/RAM Utilization: 0.49 % /86.89 MB, System CPU/RAM Utilization: 5.45 % /5316 MB");

    private final String errorType;

    private final String errorMessage;

    private AgentErrorLogScenarios(String errorType, String errorMessage) {
      this.errorType = errorType;
      this.errorMessage = errorMessage;
    }

  }


  @BeforeClass(alwaysRun = true)
  public void Authenticate() throws UnknownHostException {

    streamingApiHelper = new StreamingApiHelper();
    ipAddress = InetAddress.getLocalHost();
    // hostName = ipAddress.getHostName();
    hostName = "CNX-Test";
    log.info(hostName);
    AuthenticationRequest authenticationRequest = AuthenticationRequest.builder().
        utcOffsetinSecs(ConfigurationFileHelper.getInstance().getUtcOffsetinSecs()).
        lanID(ConfigurationFileHelper.getInstance().getLanID()).
        applicationKey(ConfigurationFileHelper.getInstance().getApplicationKey()).
        sSOId(ConfigurationFileHelper.getInstance().getSSOId()).
        streamingAppVersion(ConfigurationFileHelper.getInstance().getStreamingAppVersion()).
        systemIP(ipAddress.toString().split("/")[1]).
        systemName(hostName)
        .build();

    streamingApiHelper = new StreamingApiHelper();
    Response response = streamingApiHelper.authenticateStreaming(authenticationRequest);
    GeneralResponse generalResponse = response.getBody().as(GeneralResponse.class);
    authToken = generalResponse.getResponseResult();
    Assert.assertEquals(generalResponse.getResponseStatus(), "Success");
  }


  public HashMap<Object, Object> createFaceStreamingRequestMap(String authToken, String ipAddress, String hostName, String timeStamp, File filePath) {

    FaceStreamingRequest faceStreamingRequest = FaceStreamingRequest.builder().lanId(ConfigurationFileHelper.getInstance().getLanID())
        .token(authToken)
        .systemIp(String.valueOf(ipAddress))
        .systemName(hostName)
        .timeStamp(timeStamp)
        .faceAuthMode(0)
        .streamingAppVersion("2.4.0.1")
        .thickClient("false")
        .blurType("NoBlur")
        .blurBackgroundType("FaceAuthUnblur")
        .blurKernelSize("101")
        .timeZoneOffset("19800")
        .secondaryPersonBlurType("BbNoFaceAuth")
        .file(filePath)
        .build();
    HashMap<Object, Object> formData = new HashMap<>();
    formData.put("file", faceStreamingRequest.getFile());
    formData.put("LanId", faceStreamingRequest.getLanId());
    formData.put("Token", faceStreamingRequest.getToken());
    formData.put("SystemIP", faceStreamingRequest.getSystemIp());
    formData.put("SystemName", faceStreamingRequest.getSystemName());
    formData.put("Timestamp", faceStreamingRequest.getTimeStamp());
    formData.put("StreaminAppVersion", faceStreamingRequest.getStreamingAppVersion());
    formData.put("ThickClient", faceStreamingRequest.getThickClient());
    formData.put("BlurType", faceStreamingRequest.getBlurType());
    formData.put("BlurBackgroundType", faceStreamingRequest.getBlurBackgroundType());
    formData.put("BLUR_KERNEL_SIZE", faceStreamingRequest.getBlurKernelSize());
    formData.put("SecondaryPersonBlurType", faceStreamingRequest.getSecondaryPersonBlurType());
    formData.put("TimeZoneOffset", faceStreamingRequest.getTimeZoneOffset());

    return formData;
  }


  public HashMap<Object, Object> createFaceStreamingRequestMapWithAdditionalParams(
      String authToken, String ipAddress, String hostName, String timeStamp, File filePath, HashMap<Object, Object> additionalParams) {

    HashMap<Object, Object> formData;
    formData = createFaceStreamingRequestMap(authToken, ipAddress, hostName, timeStamp, filePath);
    formData.putAll(additionalParams);
    return formData;
  }

  public HashMap<Object, Object> createFaceStreamingRequestMapWithSpecificUser(
      String authToken, String ipAddress, String hostName, String timeStamp, File filePath, HashMap<Object, Object> additionalParams) {

    HashMap<Object, Object> formData;
    formData = createFaceStreamingRequestMap(authToken, ipAddress, hostName, timeStamp, filePath);
    formData.putAll(additionalParams);
    return formData;
  }


  public void postBaseLineImageToStreaming() throws InterruptedException {
    String objectKey = BASE_LINE_IMAGE.getAbsolutePath().substring(BASE_LINE_IMAGE.getAbsolutePath().indexOf("Endpoint"));
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey.replaceAll("\\\\", "/"),
          BASE_LINE_IMAGE.getAbsolutePath());
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
    HashMap<Object, Object> faceStreamingRequestMap = createFaceStreamingRequestMap(
        authToken, ipAddress.toString().split("/")[1], hostName,
        convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss"), BASE_LINE_IMAGE);
    streamingApiHelper.postImageToStreaming(authToken, faceStreamingRequestMap);
    Thread.sleep(3000);
  }

  public void postBaseLineImageToStreamingWithAuthentication() throws InterruptedException {
    String objectKey = BASE_LINE_IMAGE.getAbsolutePath().substring(BASE_LINE_IMAGE.getAbsolutePath().indexOf("Endpoint"));
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey.replaceAll("\\\\", "/"),
          BASE_LINE_IMAGE.getAbsolutePath());
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
    HashMap<Object, Object> faceStreamingRequestMap = createFaceStreamingRequestMap(
        authToken, ipAddress.toString().split("/")[1], hostName,
        convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss"), BASE_LINE_IMAGE);
    streamingApiHelper.postImageToStreamingWithAuthentication(authToken, faceStreamingRequestMap);
    Thread.sleep(3000);
  }


  public String sendImageToStreamingAndReturnImageData(File imageFilePath) throws InterruptedException {
    HashMap<Object, Object> faceStreamingRequestMap = createFaceStreamingRequestMap(
        authToken, ipAddress.toString().split("/")[1], hostName,
        convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss"), imageFilePath);
    Response response = streamingApiHelper.postImageToStreaming(authToken, faceStreamingRequestMap);
    GeneralResponse generalResponse = response.getBody().as(GeneralResponse.class);
    Thread.sleep(3000);
    return generalResponse.getData();
  }


  public String sendImageToStreamingAndReturnImageDataWithAdditionalParameters(
      File imageFilePath, HashMap<Object, Object> additionalParams) throws InterruptedException {
    HashMap<Object, Object> faceStreamingRequestMap = createFaceStreamingRequestMapWithAdditionalParams(
        authToken, ipAddress.toString().split("/")[1], hostName,
        convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss"), imageFilePath, additionalParams);
    Response response = streamingApiHelper.postImageToStreaming(authToken, faceStreamingRequestMap);
    GeneralResponse generalResponse = response.getBody().as(GeneralResponse.class);
    Thread.sleep(3000);
    return generalResponse.getData();
  }


  public String imageToBase64Converter(String filePath) {
    String base64 = "";
    File file = new File(filePath);
    try (FileInputStream fis = new FileInputStream(file);
         ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
      byte[] buf = new byte[1024];
      for (int readNum; (readNum = fis.read(buf)) != -1; ) {
        bos.write(buf, 0, readNum);
      }
      byte[] bytes = bos.toByteArray();
      base64 = Base64.getEncoder().encodeToString(bytes);
    } catch (IOException e) {
      log.error(e.getMessage());
    }
    return base64;
  }

  public ResponseResult sendImageToFaceAuth(
      String imageFilePath, String authMode, String blurType) {
    streamingApiHelper = new StreamingApiHelper();
    String base64Str = imageToBase64Converter(imageFilePath);
    String timeStamp = convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss");
    FaceAuthRequest faceAuthRequest = FaceAuthRequest.builder().sSOId(ConfigurationFileHelper.getInstance().getSSOId()).faceAuthMode(authMode).blurImage("")
        .clearImage(base64Str).blurKernelSize(101).blurType(blurType).secondaryPersonBlurType("BbNoFaceAuth").clientTimeStamp(timeStamp)
        .systemIP(ipAddress.toString().split("/")[1]).systemName(hostName).
        streamingAppVersion(ConfigurationFileHelper.getInstance().getStreamingAppVersion()).build();
    Response response = streamingApiHelper.postImageToFaceAuthWithAuthentication(faceAuthRequest, authToken);
    GeneralResponse generalResponse = response.getBody().as(GeneralResponse.class);
    String responseResult = generalResponse.getResponseResult();
    return ConversionUtil.deserializedResponse(responseResult, ResponseResult.class);
  }

  public ResponseResult sendImageToFaceAuthold(
      String imageFilePath, String authMode, String blurType) {
    streamingApiHelper = new StreamingApiHelper();
    String base64Str = imageToBase64Converter(imageFilePath);
    String timeStamp = convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss");
    FaceAuthRequest faceAuthRequest = FaceAuthRequest.builder().sSOId(ConfigurationFileHelper.getInstance().getSSOId()).faceAuthMode(authMode).blurImage("")
        .clearImage(base64Str).blurKernelSize(101).blurType(blurType).secondaryPersonBlurType("BbNoFaceAuth").clientTimeStamp(timeStamp)
        .systemIP(ipAddress.toString().split("/")[1]).systemName(hostName).
        streamingAppVersion(ConfigurationFileHelper.getInstance().getStreamingAppVersion()).build();
    Response response = streamingApiHelper.postImageToFaceAuth(faceAuthRequest);
    GeneralResponse generalResponse = response.getBody().as(GeneralResponse.class);
    String responseResult = generalResponse.getResponseResult();
    return ConversionUtil.deserializedResponse(responseResult, ResponseResult.class);
  }

  public ResponseResult sendImageToFaceAuth(
      String imageFilePath, String authMode, String blurType, String ssoId) throws InterruptedException {
    streamingApiHelper = new StreamingApiHelper();
    String base64Str = imageToBase64Converter(imageFilePath);
    String timeStamp = convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss");
    FaceAuthRequest faceAuthRequest = FaceAuthRequest.builder().sSOId(ssoId).faceAuthMode(authMode).blurImage("")
        .clearImage(base64Str).blurKernelSize(101).blurType(blurType).secondaryPersonBlurType("BbNoFaceAuth").clientTimeStamp(timeStamp)
        .systemIP(ipAddress.toString().split("/")[1]).systemName(hostName).
        streamingAppVersion(ConfigurationFileHelper.getInstance().getStreamingAppVersion()).build();
    Response response = streamingApiHelper.postImageToFaceAuth(faceAuthRequest);
    //Added loop to handle API latency issue
    for (int i = 0; i < 3; i++) {
      if (response.getStatusCode() == 400 || response.getStatusCode() == 404) {
        Thread.sleep(4000);
        response = streamingApiHelper.postImageToFaceAuth(faceAuthRequest);
      } else
        break;
    }
    GeneralResponse generalResponse = response.getBody().as(GeneralResponse.class);
    String responseResult = generalResponse.getResponseResult();
    return ConversionUtil.deserializedResponse(responseResult, ResponseResult.class);
  }

  public ResponseResult sendImageToFaceAuthWithAuthToken(
      String imageFilePath, String authMode, String blurType, String ssoId, String authTokenValue) throws InterruptedException {
    streamingApiHelper = new StreamingApiHelper();
    String base64Str = imageToBase64Converter(imageFilePath);
    //  log.info("base64Encoded data: " + base64Str);
    String timeStamp = convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss");
    FaceAuthRequest faceAuthRequest = FaceAuthRequest.builder().sSOId(ssoId).faceAuthMode(authMode).blurImage("")
        .clearImage(base64Str).blurKernelSize(101).blurType(blurType).secondaryPersonBlurType("BbNoFaceAuth").clientTimeStamp(timeStamp)
        .systemIP(ipAddress.toString().split("/")[1]).systemName(hostName).
        streamingAppVersion(ConfigurationFileHelper.getInstance().getStreamingAppVersion()).build();
    Response response = streamingApiHelper.postImageToFaceAuthWithAuthentication(faceAuthRequest, authTokenValue);
    //Added loop to handle API latency issue
    for (int i = 0; i < 3; i++) {
      if (response.getStatusCode() == 400 || response.getStatusCode() == 404) {
        Thread.sleep(4000);
        response = streamingApiHelper.postImageToFaceAuthWithAuthentication(faceAuthRequest, authTokenValue);
      } else
        break;
    }
    GeneralResponse generalResponse = response.getBody().as(GeneralResponse.class);
    String responseResult = generalResponse.getResponseResult();
    return ConversionUtil.deserializedResponse(responseResult, ResponseResult.class);
  }

  public String GenerateAuthToken() throws Exception {
    String jwt_token;
    File dir = new File("test-output/.auth");
    if (!dir.exists())
      dir.mkdirs();
    String ssoPass = Base64Helper.decodePassword(ConfigurationFileHelper.getInstance().getSsoPass());
    try (Playwright playwright = Playwright.create()) {
      Browser browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(true));
      BrowserContext context = browser.newContext();
      Page page = browser.newPage();
      page.navigate(ConfigurationFileHelper.getInstance().getCentralBaseUrl() + "/admin-ui/");
      page.waitForLoadState(LoadState.NETWORKIDLE);
      page.getByPlaceholder("Concentrix email address").fill(ConfigurationFileHelper.getInstance().getSSOId());
      page.getByPlaceholder("Password").fill(ssoPass);
      page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Sign in")).click();
      page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("ACKNOWLEDGE")).click();
      page.waitForLoadState(LoadState.NETWORKIDLE);
      page.waitForURL(ConfigurationFileHelper.getInstance().getCentralBaseUrl() + "/admin-ui/opsdelivery-dashboard");
      String localStorage = (String) page.evaluate("JSON.stringify(localStorage)");
      log.info(localStorage);
      ObjectMapper objectMapper = new ObjectMapper();
      JsonNode jsonTree = objectMapper.readTree(localStorage);
      jwt_token = jsonTree.get("JWT_TOKEN").asText();
      log.info("jwt token : " + jwt_token);
      FileWriter fileWriter = new FileWriter(dir + "//user.json");
      fileWriter.write(localStorage);
      fileWriter.close();
      log.info("auth file saved");
      context.close();
    }
    return jwt_token;
  }

  public FeedbackRequest createDefaultFeedbackRequest() {
    return FeedbackRequest.builder().empId(ConfigurationFileHelper.getInstance().getEmployeeId())
        .ssoId(ConfigurationFileHelper.getInstance().getLanID())
        .lanId(ConfigurationFileHelper.getInstance().getLanID())
        .account(ConfigurationFileHelper.getInstance().getAccount())
        .secureCXClientVersion(ConfigurationFileHelper.getInstance().getStreamingAppVersion())
        .submitDate(convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss"))
        .ipAddress(ipAddress.toString().split("/")[1])
        .computerName(hostName)
        .domainName(ConfigurationFileHelper.getInstance().getDomainName())
        .applicationName(ConfigurationFileHelper.getInstance().getApplicationName())
        .experience("")
        .feedbackType("")
        .feedbackComments("")
        .moduleName("Windows OS").build();
  }

  public BulkUpsertRequest createDefaultBulkUpsertRequest(String createdOnTime, String startTime, String endTime, boolean isShortDuration) {
    BulkUpsertConfigurations bulkUpsertConfigurations = BulkUpsertConfigurations.builder().
        id(Integer.parseInt(ConfigurationFileHelper.getInstance().getDisableMonitoringId())).
        employeeId(ConfigurationFileHelper.getInstance().
            getEmployeeId()).
        firstName(ConfigurationFileHelper.getInstance().getDisableMonitoringFirstName()).
        lastName(ConfigurationFileHelper.getInstance().getDisableMonitoringLastName()).
        meetingName("Test " + createdOnTime).
        createdOn(createdOnTime).
        startDate(startTime).
        endDate(endTime).
        employeeSSOId(ConfigurationFileHelper.getInstance().getSSOId()).
        supervisorSSOId(ConfigurationFileHelper.getInstance().getSupervisorSSOId()).
        enrollmentFlag(ConfigurationFileHelper.getInstance().getDisableMonitoringEnrollmentFlag()).
        secureCXEnable(ConfigurationFileHelper.getInstance().getDisableMonitoringSecureCXEnabled()).
        supervisorId(ConfigurationFileHelper.getInstance().getSupervisorId()).
        status(ConfigurationFileHelper.getInstance().getDisableMonitoringInitialStatus()).
        rowChecked(false).build();
    if (isShortDuration) {
      bulkUpsertConfigurations.setIsFullDayDisable(false);
      bulkUpsertConfigurations.setIsShortDuration(true);
      bulkUpsertConfigurations.setAction(ConfigurationFileHelper.getInstance().getDisableMonitoringShortDisableAction());
    } else {
      bulkUpsertConfigurations.setIsFullDayDisable(true);
      bulkUpsertConfigurations.setIsShortDuration(false);
      bulkUpsertConfigurations.setAction(ConfigurationFileHelper.getInstance().getDisableMonitoringFullDayDisableAction());
    }
    BulkUpsertConfigurations[] bulkUpsertConfigurationsList = new BulkUpsertConfigurations[1];
    bulkUpsertConfigurationsList[0] = bulkUpsertConfigurations;
    return BulkUpsertRequest.builder().loggedInEmployeeId(ConfigurationFileHelper.getInstance().getEmployeeId()).bulkUpsertConfigurations(bulkUpsertConfigurationsList).build();
  }

  public ApproveAgentMonitoringRequest createDefaultApproveMonitoringRequest(String action) {
    String comments = "";
    if (action.equalsIgnoreCase(ConfigurationFileHelper.getInstance().getDisableMonitoringApproveAction()))
      comments = ConfigurationFileHelper.getInstance().getDisableMonitoringApproveComments();
    else if (action.equalsIgnoreCase(ConfigurationFileHelper.getInstance().getDisableMonitoringRejectAction()))
      comments = ConfigurationFileHelper.getInstance().DisableMonitoringRejectComments();
    return ApproveAgentMonitoringRequest.builder().
        id(Integer.parseInt(ConfigurationFileHelper.getInstance().getDisableMonitoringId())).approvedById(ConfigurationFileHelper.getInstance().getSupervisorId()).status(action).comments(comments).employeeId(ConfigurationFileHelper.getInstance().getEmployeeId()).build();
  }

  @AfterSuite
  public void deleteImagesFromFolder() {
    Arrays.stream(new File(imageFolder).listFiles((f, p) -> p.endsWith("jpg") || p.endsWith("jpeg"))).forEach(File::delete);
  }
}
