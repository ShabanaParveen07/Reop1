package com.concentrix.listeners;

import com.concentrix.BaseTests.ConcentrixBaseTest;
import org.testng.ISuite;
import org.testng.ISuiteListener;

public class SuiteListener implements ISuiteListener {

  String bearerAuthToken;

  @Override
  public void onStart(ISuite suite) {
    ConcentrixBaseTest baseTest = new ConcentrixBaseTest();
    try {
      bearerAuthToken = baseTest.GenerateAuthToken();
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
    suite.setAttribute("bearerAuthToken", bearerAuthToken);
  }
}
