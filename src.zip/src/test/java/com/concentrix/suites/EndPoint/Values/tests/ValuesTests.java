package com.concentrix.suites.EndPoint.Values.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.BaseTests.ConcentrixBaseTest;
import com.concentrix.automation.helper.streaming.StreamingApiHelper;
import com.concentrix.listeners.RetryAnalyzer;
import io.restassured.response.Response;
import org.json.JSONArray;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class ValuesTests extends ConcentrixBaseTest {

  StreamingApiHelper streamingApiHelper;

  JSONArray results;

  @BeforeClass(alwaysRun = true)
  public void beforeClass() {
    streamingApiHelper = new StreamingApiHelper();
  }

  @XrayTest(key = "ORN-6092", summary = "TC_Values", description = "Check Values Returned is a List from Values API", labels = "E2E")
  @Test(description = "Check Values Returned is a List from Values API", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Values() {
    Response response = streamingApiHelper.getValues();
    results = new JSONArray(response.getBody().asString());
    Assert.assertTrue(results.length() > 0);
  }

  @XrayTest(key = "ORN-8541", summary = "TC_Endpoint_Values_with_Authentication", description = "Check Values Returned is a List from Values API", labels = "E2E")
  @Test(description = "Check Values Returned is a List from Values API with Authentication", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Values_with_Authentication() {
    Response response = streamingApiHelper.getValuesWithAuthentication(authToken);
    results = new JSONArray(response.getBody().asString());
    Assert.assertTrue(results.length() > 0);
  }
}
