package com.concentrix.suites.EndPoint.Violations.validations;

import com.concentrix.automation.service.streaming.pojo.response.GetLastImageProcessedStatusResponse;
import com.concentrix.BaseTests.ConcentrixBaseTest;
import io.restassured.response.Response;
import org.testng.Assert;

import static com.concentrix.automation.service.streaming.constants.EndPointConstants.*;

public class ViolationsValidations {

    public void validateResponseForViolations(
            ConcentrixBaseTest.CreateViolationScenarios testDescription, Response response,
            GetLastImageProcessedStatusResponse getLastImageProcessedStatusResponse) {

        Assert.assertEquals(response.getStatusCode(), responseOK);
        Assert.assertNotNull(getLastImageProcessedStatusResponse.getImageBagID());
        Assert.assertNotNull(getLastImageProcessedStatusResponse.getImageCacheKey());
        Assert.assertNotNull(getLastImageProcessedStatusResponse.getProcessedOn());
        switch(testDescription) {

            case BLOCKED_CAMERA:
                Assert.assertEquals(getLastImageProcessedStatusResponse.getFaceAuthMode(), 0);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getStatus(), statusY);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultDescription(), blockedCameraResultDescription);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultDescription1(), blockedCameraResultId+":"+blockedCameraResultDescription);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultId(), blockedCameraResultId);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getActions()[0].getActionType(), screenGreyOutText);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getActions()[0].getActionData().getAlertMessage(),
                        BLOCKED_CAMERA_SCREEN_GREY_OUT_ERROR);

                Assert.assertEquals(getLastImageProcessedStatusResponse.getActionsNewFormat()[0].getActionType(), screenGreyOutText);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getActionsNewFormat()[0].getActionData().getAlertMessage(),
                        BLOCKED_CAMERA_SCREEN_GREY_OUT_ERROR_NEW);
                break;

            case CELL_PHONE_ONLY_ONCE:
                Assert.assertEquals(getLastImageProcessedStatusResponse.getFaceAuthMode(), 99);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getStatus(), statusY);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultDescription(), cellPhoneResultDescription);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultDescription1(), cellPhonePREResultId+":"+cellPhoneResultDescription);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultId(), cellPhonePREResultId);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getActions()[0].getActionType(), showAlertText);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getActions()[0].getActionData().getAlertMessage(),
                        CELLPHONE_ALERT_MESSAGE);

                Assert.assertEquals(getLastImageProcessedStatusResponse.getActionsNewFormat()[0].getActionType(), showAlertText);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getActionsNewFormat()[0].getActionData().getAlertMessage(),
                        CELL_PHONE_ALERT_MESSAGE_NEW);
                break;

            case CELL_PHONE_CONSECUTIVELY:
                Assert.assertEquals(getLastImageProcessedStatusResponse.getFaceAuthMode(), 0);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getStatus(), statusF);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getActions()[0].getActionType(), screenGreyOutText);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getActions()[0].getActionData().getAlertMessage(),
                        CELLPHONE_GREY_OUT_ERROR_MESSAGE);

                Assert.assertEquals(getLastImageProcessedStatusResponse.getActionsNewFormat()[0].getActionType(), screenGreyOutText);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getActionsNewFormat()[0].getActionData().getAlertMessage(),
                        CELLPHONE_GREY_OUT_ERROR_MESSAGE_NEW);
                break;

            case NO_FACES_FOUND:
                Assert.assertEquals(getLastImageProcessedStatusResponse.getFaceAuthMode(), 0);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getStatus(), statusY);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultDescription(), noFacesFoundResultDescription);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultDescription1(), noFacesFoundResultId+":"+noFacesFoundResultDescription);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultId(), noFacesFoundResultId);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getActions().length, 0);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getActionsNewFormat().length, 0);
                break;

            case NO_FACES_FOUND_CONSECUTIVELY:
                Assert.assertEquals(getLastImageProcessedStatusResponse.getFaceAuthMode(), 0);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getStatus(), statusF);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getActions()[0].getActionType(), screenLockOutText);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getActions()[0].getActionData().getAlertMessage(),
                        NO_FACES_FOUND_LOCK_OUT_ERROR_MESSAGE);

                Assert.assertEquals(getLastImageProcessedStatusResponse.getActionsNewFormat()[0].getActionType(), screenLockOutText);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getActionsNewFormat()[0].getActionData().getAlertMessage(),
                        LOCK_OUT_ERROR_MESSAGE_NEW);
                break;

            case MULTIPLE_PERSONS:
                Assert.assertEquals(getLastImageProcessedStatusResponse.getFaceAuthMode(), 99);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getStatus(), statusY);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultDescription(), multiplePersonsResultDescription);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultDescription1(), multiplePersonsResultId+":"+multiplePersonsResultDescription);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultId(), multiplePersonsResultId);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getActions()[0].getActionType(), showAlertText);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getActions()[0].getActionData().getAlertMessage(),
                        MULTIPLE_PERSONS_ALERT_MESSAGE);

                Assert.assertEquals(getLastImageProcessedStatusResponse.getActionsNewFormat()[0].getActionType(), showAlertText);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getActionsNewFormat()[0].getActionData().getAlertMessage(),
                        MULTIPLE_PERSONS_ALERT_MESSAGE_NEW);
                break;

            case MULTIPLE_PERSONS_CONSECUTIVELY:
                Assert.assertEquals(getLastImageProcessedStatusResponse.getFaceAuthMode(), 0);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getStatus(), statusF);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getActions()[0].getActionType(), screenLockOutText);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getActions()[0].getActionData().getAlertMessage(),
                        MULTIPLE_PERSONS_LOCK_OUT_ERROR_MESSAGE);

                Assert.assertEquals(getLastImageProcessedStatusResponse.getActionsNewFormat()[0].getActionType(), screenLockOutText);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getActionsNewFormat()[0].getActionData().getAlertMessage(),
                        MULTIPLE_PERSONS_LOCK_OUT_ERROR_MESSAGE_NEW);

        }

    }

}
