package com.concentrix.suites.EndPoint.LogClientEvent.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.BaseTests.ConcentrixBaseTest;
import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.helper.DBConnectionHelper;
import com.concentrix.automation.helper.DateHelper;
import com.concentrix.automation.helper.streaming.StreamingApiHelper;
import com.concentrix.automation.service.streaming.pojo.request.ClientEventData;
import com.concentrix.automation.service.streaming.pojo.request.ClientEventRequest;
import com.concentrix.automation.service.streaming.pojo.response.StandardResponse;
import com.concentrix.listeners.RetryAnalyzer;
import com.concentrix.suites.EndPoint.LogClientEvent.validations.LogClientEventDBValidations;
import com.concentrix.suites.EndPoint.LogClientEvent.validations.LogClientEventResponseValidations;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.sql.ResultSet;


public class LogClientEventTests extends ConcentrixBaseTest {
  StreamingApiHelper streamingApiHelper;

  StandardResponse response;

  String STREAMING_AGENT_EVENT_LOG_QUERY;

  String envName;

  ResultSet rs;

  LogClientEventDBValidations logClientEventDBValidations;

  LogClientEventResponseValidations logClientEventResponseValidations;

  private DBConnectionHelper dbConnectionHelper;

  @BeforeClass(alwaysRun = true)
  public void beforeClass() {

    streamingApiHelper = new StreamingApiHelper();
    envName = System.getProperty("env");
    if (envName == null)
      envName = "qa";
    STREAMING_AGENT_EVENT_LOG_QUERY = "SELECT * from fb_biometrics_" + envName + ".StreamingAgentEventLog where AgentSSOId=" + "'" + ConfigurationFileHelper.getInstance().getLanID() + "'" + " order by LogTimeStamp desc";
  }

  @BeforeMethod(alwaysRun = true)
  public void beforeMethod() {
    dbConnectionHelper = DBConnectionHelper.getInstance();
    logClientEventDBValidations = new LogClientEventDBValidations();
    logClientEventResponseValidations = new LogClientEventResponseValidations();
  }

  @XrayTest(key = "ORN-6120", summary = "TC_Client_Event_Lock", description = "Check if Lock Event is getting posted", labels = "E2E")
  @Test(description = "Check if Lock Event is getting posted", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Client_Event_Lock() {
    ClientEventData clientEventData = ClientEventData.builder().ssoId(ConfigurationFileHelper.getInstance().getSSOId()).eventType(ClientEventAuditScenarios.LOCK.getLabel()).clientTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).build();
    ClientEventRequest clientEventRequest = ClientEventRequest.builder().data(clientEventData).clientInfo("Win3.1.1.3").build();
    response = streamingApiHelper.postClientEvent(clientEventRequest).as(StandardResponse.class);
    logClientEventResponseValidations.validatePostClientEventResponse(response);
    rs = dbConnectionHelper.executeQuery(STREAMING_AGENT_EVENT_LOG_QUERY);
    logClientEventDBValidations.validateClientEventEntry(clientEventRequest, rs);
  }

  @XrayTest(key = "ORN-8793", summary = "TC_Endpoint_Client_Event_Lock_with_Authentication", description = "Check if Lock Event is getting posted", labels = "E2E")
  @Test(description = "Check if Lock Event is getting posted with authentication", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Client_Event_Lock_with_Authentication() {
    ClientEventData clientEventData = ClientEventData.builder().ssoId(ConfigurationFileHelper.getInstance().getSSOId()).eventType(ClientEventAuditScenarios.LOCK.getLabel()).clientTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).build();
    ClientEventRequest clientEventRequest = ClientEventRequest.builder().data(clientEventData).clientInfo("Win3.1.1.3").build();
    response = streamingApiHelper.postClientEventWithAuthentication(clientEventRequest, authToken).as(StandardResponse.class);
    logClientEventResponseValidations.validatePostClientEventResponse(response);
    rs = dbConnectionHelper.executeQuery(STREAMING_AGENT_EVENT_LOG_QUERY);
    logClientEventDBValidations.validateClientEventEntry(clientEventRequest, rs);
  }

  @XrayTest(key = "ORN-6121", summary = "TC_Client_Event_UnLock", description = "Check if UnLock Event is getting posted", labels = "E2E")
  @Test(description = "Check if UnLock Event is getting posted", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Client_Event_UnLock() {
    ClientEventData clientEventData = ClientEventData.builder().ssoId(ConfigurationFileHelper.getInstance().getSSOId()).eventType(ClientEventAuditScenarios.UNLOCK.getLabel()).clientTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).build();
    ClientEventRequest clientEventRequest = ClientEventRequest.builder().data(clientEventData).clientInfo("Win3.1.1.3").build();
    response = streamingApiHelper.postClientEvent(clientEventRequest).as(StandardResponse.class);
    logClientEventResponseValidations.validatePostClientEventResponse(response);
    rs = dbConnectionHelper.executeQuery(STREAMING_AGENT_EVENT_LOG_QUERY);
    logClientEventDBValidations.validateClientEventEntry(clientEventRequest, rs);
  }

  @XrayTest(key = "ORN-8794", summary = "TC_Endpoint_Client_Event_UnLock_with_authentication", description = "Check if UnLock Event is getting posted", labels = "E2E")
  @Test(description = "Check if UnLock Event is getting posted with authentication", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Client_Event_UnLock_with_Authentication() {
    ClientEventData clientEventData = ClientEventData.builder().ssoId(ConfigurationFileHelper.getInstance().getSSOId()).eventType(ClientEventAuditScenarios.UNLOCK.getLabel()).clientTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).build();
    ClientEventRequest clientEventRequest = ClientEventRequest.builder().data(clientEventData).clientInfo("Win3.1.1.3").build();
    response = streamingApiHelper.postClientEventWithAuthentication(clientEventRequest, authToken).as(StandardResponse.class);
    logClientEventResponseValidations.validatePostClientEventResponse(response);
    rs = dbConnectionHelper.executeQuery(STREAMING_AGENT_EVENT_LOG_QUERY);
    logClientEventDBValidations.validateClientEventEntry(clientEventRequest, rs);
  }

  @XrayTest(key = "ORN-6122", summary = "TC_Client_Event_CameraConnected", description = "Check if Camera Connected Event is getting posted", labels = "E2E")
  @Test(description = "Check if Camera Connected Event is getting posted", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Client_Event_CameraConnected() {
    ClientEventData clientEventData = ClientEventData.builder().ssoId(ConfigurationFileHelper.getInstance().getSSOId()).eventType(ClientEventAuditScenarios.CAMERA_CONNECTED.getLabel()).clientTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).build();
    ClientEventRequest clientEventRequest = ClientEventRequest.builder().data(clientEventData).clientInfo("Win3.1.1.3").build();
    response = streamingApiHelper.postClientEvent(clientEventRequest).as(StandardResponse.class);
    logClientEventResponseValidations.validatePostClientEventResponse(response);
    rs = dbConnectionHelper.executeQuery(STREAMING_AGENT_EVENT_LOG_QUERY);
    logClientEventDBValidations.validateClientEventEntry(clientEventRequest, rs);
  }

  @XrayTest(key = "ORN-8795", summary = "TC_Endpoint_Client_Event_CameraConnected_with_authentication", description = "Check if Camera Connected Event is getting posted", labels = "E2E")
  @Test(description = "Check if Camera Connected Event is getting posted with authentication", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Client_Event_CameraConnected_with_authentication() {
    ClientEventData clientEventData = ClientEventData.builder().ssoId(ConfigurationFileHelper.getInstance().getSSOId()).eventType(ClientEventAuditScenarios.CAMERA_CONNECTED.getLabel()).clientTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).build();
    ClientEventRequest clientEventRequest = ClientEventRequest.builder().data(clientEventData).clientInfo("Win3.1.1.3").build();
    response = streamingApiHelper.postClientEventWithAuthentication(clientEventRequest, authToken).as(StandardResponse.class);
    logClientEventResponseValidations.validatePostClientEventResponse(response);
    rs = dbConnectionHelper.executeQuery(STREAMING_AGENT_EVENT_LOG_QUERY);
    logClientEventDBValidations.validateClientEventEntry(clientEventRequest, rs);
  }

  @XrayTest(key = "ORN-6123", summary = "TC_Client_Event_CameraDisConnected", description = "Check if Camera Disconnected Event is getting posted", labels = "E2E")
  @Test(description = "Check if Camera Disconnected Event is getting posted", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Client_Event_CameraDisConnected() {
    ClientEventData clientEventData = ClientEventData.builder().ssoId(ConfigurationFileHelper.getInstance().getSSOId()).eventType(ClientEventAuditScenarios.CAMERA_DISCONNECTED.getLabel()).clientTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).build();
    ClientEventRequest clientEventRequest = ClientEventRequest.builder().data(clientEventData).clientInfo("Win3.1.1.3").build();
    response = streamingApiHelper.postClientEvent(clientEventRequest).as(StandardResponse.class);
    logClientEventResponseValidations.validatePostClientEventResponse(response);
    rs = dbConnectionHelper.executeQuery(STREAMING_AGENT_EVENT_LOG_QUERY);
    logClientEventDBValidations.validateClientEventEntry(clientEventRequest, rs);
  }

  @XrayTest(key = "ORN-8796", summary = "TC_Endpoint_Client_Event_CameraDisConnected_with_authentication", description = "Check if Camera Disconnected Event is getting posted", labels = "E2E")
  @Test(description = "Check if Camera Disconnected Event is getting posted with authentication", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Client_Event_CameraDisConnected_with_authentication() {
    ClientEventData clientEventData = ClientEventData.builder().ssoId(ConfigurationFileHelper.getInstance().getSSOId()).eventType(ClientEventAuditScenarios.CAMERA_DISCONNECTED.getLabel()).clientTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).build();
    ClientEventRequest clientEventRequest = ClientEventRequest.builder().data(clientEventData).clientInfo("Win3.1.1.3").build();
    response = streamingApiHelper.postClientEventWithAuthentication(clientEventRequest, authToken).as(StandardResponse.class);
    logClientEventResponseValidations.validatePostClientEventResponse(response);
    rs = dbConnectionHelper.executeQuery(STREAMING_AGENT_EVENT_LOG_QUERY);
    logClientEventDBValidations.validateClientEventEntry(clientEventRequest, rs);
  }

  @XrayTest(key = "ORN-6124", summary = "TC_Client_Event_FacialAuthenticationPassed", description = "Check if FacialAuthenticationPassed Event is getting posted", labels = "E2E")
  @Test(description = "Check if FacialAuthenticationPassed Event is getting posted", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Client_Event_FacialAuthenticationPassed() {
    ClientEventData clientEventData = ClientEventData.builder().ssoId(ConfigurationFileHelper.getInstance().getSSOId()).eventType(ClientEventAuditScenarios.FACIAL_AUTHENTICATION_PASSED.getLabel()).clientTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).build();
    ClientEventRequest clientEventRequest = ClientEventRequest.builder().data(clientEventData).clientInfo("Win3.1.1.3").build();
    response = streamingApiHelper.postClientEvent(clientEventRequest).as(StandardResponse.class);
    logClientEventResponseValidations.validatePostClientEventResponse(response);
    rs = dbConnectionHelper.executeQuery(STREAMING_AGENT_EVENT_LOG_QUERY);
    logClientEventDBValidations.validateClientEventEntry(clientEventRequest, rs);
  }

  @XrayTest(key = "ORN-8797 ", summary = "TC_Endpoint_Client_Event_FacialAuthenticationPassed_with_authentication", description = "Check if FacialAuthenticationPassed Event is getting posted", labels = "E2E")
  @Test(description = "Check if FacialAuthenticationPassed Event is getting posted with authentication", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Client_Event_FacialAuthenticationPassed_With_Authentication() {
    ClientEventData clientEventData = ClientEventData.builder().ssoId(ConfigurationFileHelper.getInstance().getSSOId()).eventType(ClientEventAuditScenarios.FACIAL_AUTHENTICATION_PASSED.getLabel()).clientTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).build();
    ClientEventRequest clientEventRequest = ClientEventRequest.builder().data(clientEventData).clientInfo("Win3.1.1.3").build();
    response = streamingApiHelper.postClientEventWithAuthentication(clientEventRequest, authToken).as(StandardResponse.class);
    logClientEventResponseValidations.validatePostClientEventResponse(response);
    rs = dbConnectionHelper.executeQuery(STREAMING_AGENT_EVENT_LOG_QUERY);
    logClientEventDBValidations.validateClientEventEntry(clientEventRequest, rs);
  }

  @XrayTest(key = "ORN-6125", summary = "TC_Client_Event_FacialAuthenticationFailed", description = "Check if FacialAuthenticationFailed Event is getting posted", labels = "E2E")
  @Test(description = "Check if FacialAuthenticationFailed Event is getting posted", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Client_Event_FacialAuthenticationFailed() {
    ClientEventData clientEventData = ClientEventData.builder().ssoId(ConfigurationFileHelper.getInstance().getSSOId()).eventType(ClientEventAuditScenarios.FACIAL_AUTHENTICATION_FAILED.getLabel()).clientTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).build();
    ClientEventRequest clientEventRequest = ClientEventRequest.builder().data(clientEventData).clientInfo("Win3.1.1.3").build();
    response = streamingApiHelper.postClientEvent(clientEventRequest).as(StandardResponse.class);
    logClientEventResponseValidations.validatePostClientEventResponse(response);
    rs = dbConnectionHelper.executeQuery(STREAMING_AGENT_EVENT_LOG_QUERY);
    logClientEventDBValidations.validateClientEventEntry(clientEventRequest, rs);
  }

  @XrayTest(key = "ORN-8798", summary = "TC_Endpoint_Client_Event_FacialAuthenticationFailed_with_authentication", description = "Check if FacialAuthenticationFailed Event is getting posted", labels = "E2E")
  @Test(description = "Check if FacialAuthenticationFailed Event is getting posted with authentication", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Client_Event_FacialAuthenticationFailed_with_authentication() {
    ClientEventData clientEventData = ClientEventData.builder().ssoId(ConfigurationFileHelper.getInstance().getSSOId()).eventType(ClientEventAuditScenarios.FACIAL_AUTHENTICATION_FAILED.getLabel()).clientTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).build();
    ClientEventRequest clientEventRequest = ClientEventRequest.builder().data(clientEventData).clientInfo("Win3.1.1.3").build();
    response = streamingApiHelper.postClientEventWithAuthentication(clientEventRequest, authToken).as(StandardResponse.class);
    logClientEventResponseValidations.validatePostClientEventResponse(response);
    rs = dbConnectionHelper.executeQuery(STREAMING_AGENT_EVENT_LOG_QUERY);
    logClientEventDBValidations.validateClientEventEntry(clientEventRequest, rs);
  }

  @XrayTest(key = "ORN-6126", summary = "TC_Client_Event_FacialAuthenticationPassedOnResume", description = "Check if FacialAuthenticationPassedOnResume Event is getting posted", labels = "E2E")
  @Test(description = "Check if FacialAuthenticationPassedOnResume Event is getting posted", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Client_Event_FacialAuthenticationPassedOnResume() {
    ClientEventData clientEventData = ClientEventData.builder().ssoId(ConfigurationFileHelper.getInstance().getSSOId()).eventType(ClientEventAuditScenarios.FACIAL_AUTHENTICATION_PASSED_ON_RESUME.getLabel()).clientTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).build();
    ClientEventRequest clientEventRequest = ClientEventRequest.builder().data(clientEventData).clientInfo("Win3.1.1.3").build();
    response = streamingApiHelper.postClientEvent(clientEventRequest).as(StandardResponse.class);
    logClientEventResponseValidations.validatePostClientEventResponse(response);
    rs = dbConnectionHelper.executeQuery(STREAMING_AGENT_EVENT_LOG_QUERY);
    logClientEventDBValidations.validateClientEventEntry(clientEventRequest, rs);
  }

  @XrayTest(key = "ORN-8799", summary = "TC_Endpoint_Client_Event_FacialAuthenticationPassedOnResume_with_authentication", description = "Check if FacialAuthenticationPassedOnResume Event is getting posted", labels = "E2E")
  @Test(description = "Check if FacialAuthenticationPassedOnResume Event is getting posted with authentication", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Client_Event_FacialAuthenticationPassedOnResume_with_Authentication() {
    ClientEventData clientEventData = ClientEventData.builder().ssoId(ConfigurationFileHelper.getInstance().getSSOId()).eventType(ClientEventAuditScenarios.FACIAL_AUTHENTICATION_PASSED_ON_RESUME.getLabel()).clientTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).build();
    ClientEventRequest clientEventRequest = ClientEventRequest.builder().data(clientEventData).clientInfo("Win3.1.1.3").build();
    response = streamingApiHelper.postClientEventWithAuthentication(clientEventRequest, authToken).as(StandardResponse.class);
    logClientEventResponseValidations.validatePostClientEventResponse(response);
    rs = dbConnectionHelper.executeQuery(STREAMING_AGENT_EVENT_LOG_QUERY);
    logClientEventDBValidations.validateClientEventEntry(clientEventRequest, rs);
  }

  @XrayTest(key = "ORN-6127", summary = "TC_Client_Event_FacialAuthenticationFailedOnResume", description = "Check if FacialAuthenticationFailedOnResume Event is getting posted", labels = "E2E")
  @Test(description = "Check if FacialAuthenticationFailedOnResume Event is getting posted", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Client_Event_FacialAuthenticationFailedOnResume() {
    ClientEventData clientEventData = ClientEventData.builder().ssoId(ConfigurationFileHelper.getInstance().getSSOId()).eventType(ClientEventAuditScenarios.FACIAL_AUTHENTICATION_FAILED_ON_RESUME.getLabel()).clientTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).build();
    ClientEventRequest clientEventRequest = ClientEventRequest.builder().data(clientEventData).clientInfo("Win3.1.1.3").build();
    response = streamingApiHelper.postClientEvent(clientEventRequest).as(StandardResponse.class);
    logClientEventResponseValidations.validatePostClientEventResponse(response);
    rs = dbConnectionHelper.executeQuery(STREAMING_AGENT_EVENT_LOG_QUERY);
    logClientEventDBValidations.validateClientEventEntry(clientEventRequest, rs);
  }

  @XrayTest(key = "ORN-8800", summary = "TC_Endpoint_Client_Event_FacialAuthenticationFailedOnResume_with_authentication", description = "Check if FacialAuthenticationFailedOnResume Event is getting posted", labels = "E2E")
  @Test(description = "Check if FacialAuthenticationFailedOnResume Event is getting posted with authentication", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Client_Event_FacialAuthenticationFailedOnResume_with_Authentication() {
    ClientEventData clientEventData = ClientEventData.builder().ssoId(ConfigurationFileHelper.getInstance().getSSOId()).eventType(ClientEventAuditScenarios.FACIAL_AUTHENTICATION_FAILED_ON_RESUME.getLabel()).clientTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).build();
    ClientEventRequest clientEventRequest = ClientEventRequest.builder().data(clientEventData).clientInfo("Win3.1.1.3").build();
    response = streamingApiHelper.postClientEventWithAuthentication(clientEventRequest, authToken).as(StandardResponse.class);
    logClientEventResponseValidations.validatePostClientEventResponse(response);
    rs = dbConnectionHelper.executeQuery(STREAMING_AGENT_EVENT_LOG_QUERY);
    logClientEventDBValidations.validateClientEventEntry(clientEventRequest, rs);
  }

  @XrayTest(key = "ORN-6128", summary = "TC_Client_Event_FacialAuthenticationDuringSessionFailed", description = "Check if FacialAuthenticationDuringSessionFailed Event is getting posted", labels = "E2E")
  @Test(description = "Check if FacialAuthenticationDuringSessionFailed Event is getting posted", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Client_Event_FacialAuthenticationDuringSessionFailed() {
    ClientEventData clientEventData = ClientEventData.builder().ssoId(ConfigurationFileHelper.getInstance().getSSOId()).eventType(ClientEventAuditScenarios.FACIAL_AUTHENTICATION_DURING_SESSION_FAILED.getLabel()).clientTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).build();
    ClientEventRequest clientEventRequest = ClientEventRequest.builder().data(clientEventData).clientInfo("Win3.1.1.3").build();
    response = streamingApiHelper.postClientEvent(clientEventRequest).as(StandardResponse.class);
    logClientEventResponseValidations.validatePostClientEventResponse(response);
    rs = dbConnectionHelper.executeQuery(STREAMING_AGENT_EVENT_LOG_QUERY);
    logClientEventDBValidations.validateClientEventEntry(clientEventRequest, rs);
  }

  @XrayTest(key = "ORN-8801", summary = "TC_Endpoint_Client_Event_FacialAuthenticationDuringSessionFailed_with_authentication", description = "Check if FacialAuthenticationDuringSessionFailed Event is getting posted", labels = "E2E")
  @Test(description = "Check if FacialAuthenticationDuringSessionFailed Event is getting posted with authentication", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Client_Event_FacialAuthenticationDuringSessionFailed_With_Authentication() {
    ClientEventData clientEventData = ClientEventData.builder().ssoId(ConfigurationFileHelper.getInstance().getSSOId()).eventType(ClientEventAuditScenarios.FACIAL_AUTHENTICATION_DURING_SESSION_FAILED.getLabel()).clientTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).build();
    ClientEventRequest clientEventRequest = ClientEventRequest.builder().data(clientEventData).clientInfo("Win3.1.1.3").build();
    response = streamingApiHelper.postClientEventWithAuthentication(clientEventRequest, authToken).as(StandardResponse.class);
    logClientEventResponseValidations.validatePostClientEventResponse(response);
    rs = dbConnectionHelper.executeQuery(STREAMING_AGENT_EVENT_LOG_QUERY);
    logClientEventDBValidations.validateClientEventEntry(clientEventRequest, rs);
  }

  @XrayTest(key = "ORN-6129", summary = "TC_Client_Event_FacialAuthenticationDuringSessionPassed", description = "Check if FacialAuthenticationDuringSessionPassed Event is getting posted", labels = "E2E")
  @Test(description = "Check if FacialAuthenticationDuringSessionPassed Event is getting posted", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Client_Event_FacialAuthenticationDuringSessionPassed() {
    ClientEventData clientEventData = ClientEventData.builder().ssoId(ConfigurationFileHelper.getInstance().getSSOId()).eventType(ClientEventAuditScenarios.FACIAL_AUTHENTICATION_DURING_SESSION_PASSED.getLabel()).clientTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).build();
    ClientEventRequest clientEventRequest = ClientEventRequest.builder().data(clientEventData).clientInfo("Win3.1.1.3").build();
    response = streamingApiHelper.postClientEvent(clientEventRequest).as(StandardResponse.class);
    logClientEventResponseValidations.validatePostClientEventResponse(response);
    rs = dbConnectionHelper.executeQuery(STREAMING_AGENT_EVENT_LOG_QUERY);
    logClientEventDBValidations.validateClientEventEntry(clientEventRequest, rs);
  }

  @XrayTest(key = "ORN-8802", summary = "TC_Client_Event_FacialAuthenticationDuringSessionPassed_with_authentication", description = "Check if FacialAuthenticationDuringSessionPassed Event is getting posted", labels = "E2E")
  @Test(description = "Check if FacialAuthenticationDuringSessionPassed Event is getting posted with authentication", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Client_Event_FacialAuthenticationDuringSessionPassed_with_Authentication() {
    ClientEventData clientEventData = ClientEventData.builder().ssoId(ConfigurationFileHelper.getInstance().getSSOId()).eventType(ClientEventAuditScenarios.FACIAL_AUTHENTICATION_DURING_SESSION_PASSED.getLabel()).clientTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).build();
    ClientEventRequest clientEventRequest = ClientEventRequest.builder().data(clientEventData).clientInfo("Win3.1.1.3").build();
    response = streamingApiHelper.postClientEventWithAuthentication(clientEventRequest, authToken).as(StandardResponse.class);
    logClientEventResponseValidations.validatePostClientEventResponse(response);
    rs = dbConnectionHelper.executeQuery(STREAMING_AGENT_EVENT_LOG_QUERY);
    logClientEventDBValidations.validateClientEventEntry(clientEventRequest, rs);
  }

  @XrayTest(key = "ORN-6130", summary = "TC_Client_Event_PreviewByUser", description = "Check if PreviewByUser Event is getting posted", labels = "E2E")
  @Test(description = "Check if PreviewByUser Event is getting posted", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Client_Event_PreviewByUser() {
    ClientEventData clientEventData = ClientEventData.builder().ssoId(ConfigurationFileHelper.getInstance().getSSOId()).eventType(ClientEventAuditScenarios.PREVIEW_BY_USER.getLabel()).clientTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).build();
    ClientEventRequest clientEventRequest = ClientEventRequest.builder().data(clientEventData).clientInfo("Win3.1.1.3").build();
    response = streamingApiHelper.postClientEvent(clientEventRequest).as(StandardResponse.class);
    logClientEventResponseValidations.validatePostClientEventResponse(response);
    rs = dbConnectionHelper.executeQuery(STREAMING_AGENT_EVENT_LOG_QUERY);
    logClientEventDBValidations.validateClientEventEntry(clientEventRequest, rs);
  }

  @XrayTest(key = "ORN-8803", summary = "TC_Endpoint_Client_Event_PreviewByUser_with_authentication", description = "Check if PreviewByUser Event is getting posted", labels = "E2E")
  @Test(description = "Check if PreviewByUser Event is getting posted with authentication", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Client_Event_PreviewByUser_with_Authentication() {
    ClientEventData clientEventData = ClientEventData.builder().ssoId(ConfigurationFileHelper.getInstance().getSSOId()).eventType(ClientEventAuditScenarios.PREVIEW_BY_USER.getLabel()).clientTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).build();
    ClientEventRequest clientEventRequest = ClientEventRequest.builder().data(clientEventData).clientInfo("Win3.1.1.3").build();
    response = streamingApiHelper.postClientEventWithAuthentication(clientEventRequest, authToken).as(StandardResponse.class);
    logClientEventResponseValidations.validatePostClientEventResponse(response);
    rs = dbConnectionHelper.executeQuery(STREAMING_AGENT_EVENT_LOG_QUERY);
    logClientEventDBValidations.validateClientEventEntry(clientEventRequest, rs);
  }
}
