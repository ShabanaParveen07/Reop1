package com.concentrix.suites.EndPoint.Authentication.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.BaseTests.ConcentrixBaseTest;
import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.service.streaming.pojo.response.GetLastImageProcessedStatusResponse;
import com.concentrix.listeners.RetryAnalyzer;
import com.concentrix.suites.EndPoint.Authentication.validations.AuthenticationValidations;
import io.restassured.response.Response;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.HashMap;

import static com.concentrix.automation.service.streaming.constants.EndPointConstants.*;
import static com.concentrix.automation.service.streaming.constants.EndPointConstants.OTHER_PERSON_IMAGE;

public class AuthenticationResumeTests extends ConcentrixBaseTest{

    String imageData ;


    Response response;

    AuthenticationValidations authenticationValidations;

    GetLastImageProcessedStatusResponse getLastImageProcessedStatusResponse;

    @BeforeMethod
    public void postBaseLineImage() throws InterruptedException {

        authenticationValidations = new AuthenticationValidations();
        postBaseLineImageToStreaming();
    }

    @XrayTest(key = "ORN-4090", summary = "TC_Endpoint_Authentication_Resume_NoBlur_Success", description = "Authenticate to Streaming While Resume with Valid Person and Blur Type as No Blur", labels = "E2E")
    @Test(description = "Authenticate to Streaming While Resume with Valid Person and Blur Type as No Blur", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Resume_NoBlur_Success() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_RESUME);
        additionalParams.put("BlurType", "NoBlur");

        // Post a BaseLine Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(BASE_LINE_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationResumeScenariosWithBlurType(
                ConcentrixBaseTest.AuthenticationScenariosWithBlurType.NO_BLUR_SUCCESS, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-4091", summary = "TC_Endpoint_Authentication_Resume_NoBlur_Cell_Phone", description = "Authenticate to Streaming while Resume with Valid Person with Cell Phone and Blur Type as No Blur", labels = "E2E")
    @Test(description = "Authenticate to Streaming while Resume with Valid Person with Cell Phone and Blur Type as No Blur", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Resume_NoBlur_Cell_Phone() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_RESUME);
        additionalParams.put("BlurType", "NoBlur");

        // Post a BaseLine Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(CELL_PHONE_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationResumeScenariosWithBlurType(
                ConcentrixBaseTest.AuthenticationScenariosWithBlurType.NO_BLUR_CELL_PHONE, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-4093", summary = "TC_Endpoint_Authentication_Resume_NoBlur_Multiple_Persons", description = "Authenticate to Streaming while Resume with Multiple Persons and Blur Type as No Blur", labels = "E2E")
    @Test(description = "Authenticate to Streaming while Resume with Multiple Persons and Blur Type as No Blur", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Resume_NoBlur_Multiple_Persons() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_RESUME);
        additionalParams.put("BlurType", "NoBlur");

        // Post a BaseLine Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(MULTIPLE_PERSONS_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationResumeScenariosWithBlurType(
                ConcentrixBaseTest.AuthenticationScenariosWithBlurType.NO_BLUR_CELL_PHONE, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-4094", summary = "TC_Endpoint_Authentication_Resume_NoBlur_No_Faces_Found", description = "Authenticate to Streaming while Resume with No Faces and Blur Type as No Blur", labels = "E2E")
    @Test(description = "Authenticate to Streaming while Resume with No Faces and Blur Type as No Blur", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Resume_NoBlur_No_Faces_Found() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_RESUME);
        additionalParams.put("BlurType", "NoBlur");

        // Post a BaseLine Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(NO_FACES_FOUND_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationResumeScenariosWithBlurType(
                ConcentrixBaseTest.AuthenticationScenariosWithBlurType.NO_BLUR_NO_FACES_FOUND, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-4095", summary = "TC_Endpoint_Authentication_Resume_NoBlur_Blocked_Camera", description = "Authenticate to Streaming with Blocked Camera and Blur Type as No Blur", labels = "E2E")
    @Test(description = "Authenticate to Streaming with Blocked Camera and Blur Type as No Blur", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Resume_NoBlur_Blocked_Camera() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_RESUME);
        additionalParams.put("BlurType", "NoBlur");

        // Post a BaseLine Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(BLOCKED_CAMERA_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationResumeScenariosWithBlurType(
                ConcentrixBaseTest.AuthenticationScenariosWithBlurType.NO_BLUR_BLOCKED_CAMERA, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-4096", summary = "TC_Endpoint_Authentication_Resume_NoBlur_Other_Person", description = "Authenticate to Streaming while Resume with Other Person and Blur Type as No Blur", labels = "E2E")
    @Test(description = "Authenticate to Streaming while Resume with Other Person and Blur Type as No Blur", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Resume_NoBlur_Other_Person() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_RESUME);
        additionalParams.put("BlurType", "NoBlur");

        // Post a Other Person Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(OTHER_PERSON_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationResumeScenariosWithBlurType(
                ConcentrixBaseTest.AuthenticationScenariosWithBlurType.NO_BLUR_OTHER_PERSON, response, getLastImageProcessedStatusResponse);

        // Post a Other Person Image again
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(OTHER_PERSON_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationResumeScenariosWithBlurType(
                ConcentrixBaseTest.AuthenticationScenariosWithBlurType.NO_BLUR_OTHER_PERSON_CONSECUTIVELY, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-4099", summary = "TC_Endpoint_Authentication_Resume_Secondary_Person_Blur_Success", description = "Authenticate to Streaming While Resume with Valid Person and Blur Type as Secondary Person Blur", labels = "E2E")
    @Test(description = "Authenticate to Streaming While Resume with Valid Person and Blur Type as Secondary Person Blur", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Resume_Secondary_Person_Blur_Success() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_RESUME);
        additionalParams.put("BlurType", "SecondaryPersonBlur");

        // Post a BaseLine Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(BASE_LINE_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationResumeScenariosWithBlurType(
                ConcentrixBaseTest.AuthenticationScenariosWithBlurType.SECONDARY_PERSON_BLUR_SUCCESS, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-4102", summary = "TC_Endpoint_Authentication_Resume_Secondary_Person_Blur_No_Faces_Found", description = "Authenticate to Streaming While Resume with No Faces and Blur Type as Secondary Person Blur", labels = "E2E")
    @Test(description = "Authenticate to Streaming While Resume with No Faces and Blur Type as Secondary Person Blur", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Resume_Secondary_Person_Blur_No_Faces_Found() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_RESUME);
        additionalParams.put("BlurType", "SecondaryPersonBlur");

        // Post a BaseLine Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(NO_FACES_FOUND_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationResumeScenariosWithBlurType(
                ConcentrixBaseTest.AuthenticationScenariosWithBlurType.SECONDARY_PERSON_BLUR_NO_FACES_FOUND, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-4101", summary = "TC_Endpoint_Authentication_Resume_Secondary_Person_Blur_Multiple_Persons", description = "Authenticate to Streaming While Resume with Multiple Persons and Blur Type as Secondary Person Blur", labels = "E2E")
    @Test(description = "Authenticate to Streaming While Resume with Multiple Persons and Blur Type as Secondary Person Blur", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Resume_Secondary_Person_Blur_Multiple_Persons() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_RESUME);
        additionalParams.put("BlurType", "SecondaryPersonBlur");

        // Post a BaseLine Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(MULTIPLE_PERSONS_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationResumeScenariosWithBlurType(
                ConcentrixBaseTest.AuthenticationScenariosWithBlurType.SECONDARY_PERSON_BLUR_MULTIPLE_PERSONS, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-4103", summary = "TC_Endpoint_Authentication_Resume_Secondary_Person_Blur_Blocked_Camera", description = "Authenticate to Streaming While Resume with Blocked Camera and Blur Type as Secondary Person Blur", labels = "E2E")
    @Test(description = "Authenticate to Streaming While Resume with Blocked Camera and Blur Type as Secondary Person Blur", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Resume_Secondary_Person_Blur_Blocked_Camera() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_RESUME);
        additionalParams.put("BlurType", "SecondaryPersonBlur");

        // Post a BaseLine Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(BLOCKED_CAMERA_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationResumeScenariosWithBlurType(
                ConcentrixBaseTest.AuthenticationScenariosWithBlurType.SECONDARY_PERSON_BLUR_BLOCKED_CAMERA, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-4100", summary = "TC_Endpoint_Authentication_Resume_Secondary_Person_Blur_Cell_Phone", description = "Authenticate to Streaming While Resume with Cell Phone and Blur Type as Secondary Person Blur", labels = "E2E")
    @Test(description = "Authenticate to Streaming While Resume with Cell Phone and Blur Type as Secondary Person Blur", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Resume_Secondary_Person_Blur_Cell_Phone() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_RESUME);
        additionalParams.put("BlurType", "SecondaryPersonBlur");

        // Post a BaseLine Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(CELL_PHONE_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationResumeScenariosWithBlurType(
                ConcentrixBaseTest.AuthenticationScenariosWithBlurType.SECONDARY_PERSON_BLUR_CELL_PHONE, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-4104", summary = "TC_Endpoint_Authentication_Resume_Secondary_Person_Blur_Other_Person", description = "Authenticate to Streaming While Resume with Other Person and Blur Type as Secondary Person Blur", labels = "E2E")
    @Test(description = "Authenticate to Streaming While Resume with Other Person and Blur Type as Secondary Person Blur", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Resume_Secondary_Person_Blur_Other_Person() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_RESUME);
        additionalParams.put("BlurType", "SecondaryPersonBlur");

        // Post a Other Person Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(OTHER_PERSON_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationResumeScenariosWithBlurType(
                ConcentrixBaseTest.AuthenticationScenariosWithBlurType.SECONDARY_PERSON_BLUR_OTHER_PERSON, response, getLastImageProcessedStatusResponse);

        // Post a Other Person Image again
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(OTHER_PERSON_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationResumeScenariosWithBlurType(
                ConcentrixBaseTest.AuthenticationScenariosWithBlurType.SECONDARY_PERSON_BLUR_OTHER_PERSON_CONSECUTIVELY, response, getLastImageProcessedStatusResponse);
    }
    
    @XrayTest(key = "ORN-4354", summary = "TC_Endpoint_Authentication_Resume_Blur_Background_Success", description = "Authenticate to Streaming While Resume with Valid Person and Blur Type as Blur Background", labels = "E2E")
    @Test(description = "Authenticate to Streaming While Resume with Valid Person and Blur Type as Blur Background", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Resume_Blur_Background_Success() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_RESUME);
        additionalParams.put("BlurType", "BlurBackground");

        // Post a BaseLine Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(BASE_LINE_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationResumeScenariosWithBlurType(
                ConcentrixBaseTest.AuthenticationScenariosWithBlurType.BLUR_BACKGROUND_SUCCESS, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-4358", summary = "TC_Endpoint_Authentication_Resume_Blur_Background_Cell_Phone", description = "Authenticate to Streaming while Resume with Valid Person with Cell Phone and Blur Type as Blur Background", labels = "E2E")
    @Test(description = "Authenticate to Streaming while Resume with Valid Person with Cell Phone and Blur Type as Blur Background", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Resume_Blur_Background_Cell_Phone() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_RESUME);
        additionalParams.put("BlurType", "BlurBackground");

        // Post a BaseLine Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(CELL_PHONE_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationResumeScenariosWithBlurType(
                ConcentrixBaseTest.AuthenticationScenariosWithBlurType.BLUR_BACKGROUND_CELL_PHONE, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-4356", summary = "TC_Endpoint_Authentication_Resume_Blur_Background_Multiple_Persons", description = "Authenticate to Streaming while Resume with Multiple Persons and Blur Type as Blur Background", labels = "E2E")
    @Test(description = "Authenticate to Streaming while Resume with Multiple Persons and Blur Type as Blur Background", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Resume_Blur_Background_Multiple_Persons() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_RESUME);
        additionalParams.put("BlurType", "BlurBackground");

        // Post a BaseLine Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(MULTIPLE_PERSONS_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationResumeScenariosWithBlurType(
                ConcentrixBaseTest.AuthenticationScenariosWithBlurType.BLUR_BACKGROUND_CELL_PHONE, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-4355", summary = "TC_Endpoint_Authentication_Resume_Blur_Background_No_Faces_Found", description = "Authenticate to Streaming while Resume with No Faces and Blur Type as Blur Background", labels = "E2E")
    @Test(description = "Authenticate to Streaming while Resume with No Faces and Blur Type as Blur Background", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Resume_Blur_Background_No_Faces_Found() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_RESUME);
        additionalParams.put("BlurType", "BlurBackground");

        // Post a BaseLine Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(NO_FACES_FOUND_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationResumeScenariosWithBlurType(
                ConcentrixBaseTest.AuthenticationScenariosWithBlurType.BLUR_BACKGROUND_NO_FACES_FOUND, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-4353", summary = "TC_Endpoint_Authentication_Resume_Blur_Background_Blocked_Camera", description = "Authenticate to Streaming with Blocked Camera and Blur Type as Blur Background", labels = "E2E")
    @Test(description = "Authenticate to Streaming with Blocked Camera and Blur Type as Blur Background", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Resume_Blur_Background_Blocked_Camera() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_RESUME);
        additionalParams.put("BlurType", "BlurBackground");

        // Post a BaseLine Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(BLOCKED_CAMERA_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationResumeScenariosWithBlurType(
                ConcentrixBaseTest.AuthenticationScenariosWithBlurType.BLUR_BACKGROUND_BLOCKED_CAMERA, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-4357", summary = "TC_Endpoint_Authentication_Resume_Blur_Background_Other_Person", description = "Authenticate to Streaming while Resume with Other Person and Blur Type as Blur Background", labels = "E2E")
    @Test(description = "Authenticate to Streaming while Resume with Other Person and Blur Type as Blur Background", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Resume_Blur_Background_Other_Person() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_RESUME);
        additionalParams.put("BlurType", "BlurBackground");

        // Post a Other Person Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(OTHER_PERSON_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationResumeScenariosWithBlurType(
                ConcentrixBaseTest.AuthenticationScenariosWithBlurType.BLUR_BACKGROUND_OTHER_PERSON, response, getLastImageProcessedStatusResponse);

        // Post a Other Person Image again
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(OTHER_PERSON_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationResumeScenariosWithBlurType(
                ConcentrixBaseTest.AuthenticationScenariosWithBlurType.BLUR_BACKGROUND_OTHER_PERSON_CONSECUTIVELY, response, getLastImageProcessedStatusResponse);
    } 
}
