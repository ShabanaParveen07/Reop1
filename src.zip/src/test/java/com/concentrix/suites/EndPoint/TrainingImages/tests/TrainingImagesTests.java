package com.concentrix.suites.EndPoint.TrainingImages.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.BaseTests.ConcentrixBaseTest;
import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.helper.streaming.StreamingApiHelper;
import com.concentrix.automation.rest.ConversionUtil;
import com.concentrix.automation.service.streaming.pojo.response.TrainingImageResponse;
import com.concentrix.listeners.RetryAnalyzer;
import io.restassured.response.Response;
import org.json.JSONArray;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class TrainingImagesTests extends ConcentrixBaseTest {
  StreamingApiHelper streamingApiHelper;

  JSONArray imagesArray;

  Response response;

  @BeforeClass(alwaysRun = true)
  public void beforeClass() {
    streamingApiHelper = new StreamingApiHelper();
  }

  @XrayTest(key = "ORN-5720", summary = "TC_Get_Training_Images_Valid_LanID", description = "Fetch the Training Images of an Agent with Valid LandID", labels = "E2E")
  @Test(description = "Fetch the Training Images of an Agent with Valid LandID", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Get_Training_Images_Valid_LanID() throws IOException {
    response = streamingApiHelper.getTrainingImagesByLanId(ConfigurationFileHelper.getInstance().getLanID());
    imagesArray = new JSONArray(response.getBody().asString());
    List<String> expectedImageProfiles = new ArrayList<>();
    List<String> actualImageProfiles = new ArrayList<>();
    expectedImageProfiles.add("L");
    expectedImageProfiles.add("R");
    expectedImageProfiles.add("F");
    for (int i = 0; i < imagesArray.length(); i++) {
      TrainingImageResponse trainingImageResponse = ConversionUtil.deserializedResponse(imagesArray.get(i).toString(), TrainingImageResponse.class);
      Assert.assertNotNull(trainingImageResponse.getImageBagId());
      Assert.assertEquals(trainingImageResponse.getLanId(), ConfigurationFileHelper.getInstance().getLanID());
      Assert.assertEquals(trainingImageResponse.getEmpId(), ConfigurationFileHelper.getInstance().getEmployeeId());
      Assert.assertNotNull(trainingImageResponse.getImageFile());
      Assert.assertNotNull(trainingImageResponse.getEnrollmentFlag());
      Assert.assertEquals(trainingImageResponse.getImageSource(), "facetraining");
      actualImageProfiles.add(trainingImageResponse.getImageProfile());
    }
    Assert.assertTrue(expectedImageProfiles.containsAll(expectedImageProfiles));
    Assert.assertTrue(actualImageProfiles.containsAll(actualImageProfiles));
  }

  @XrayTest(key = "ORN-8560", summary = "TC_EndPoint_Get_Training_Images_Valid_LanID_with_Authentication", description = "Fetch the Training Images of an Agent with Valid LandID", labels = "E2E")
  @Test(description = "Fetch the Training Images of an Agent with Valid LandID with Authentication", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Get_Training_Images_Valid_LanID_With_Authentiation() throws IOException {
    response = streamingApiHelper.getTrainingImagesByLanIdWithAuthentication(ConfigurationFileHelper.getInstance().getLanID(), authToken);
    imagesArray = new JSONArray(response.getBody().asString());
    List<String> expectedImageProfiles = new ArrayList<>();
    List<String> actualImageProfiles = new ArrayList<>();
    expectedImageProfiles.add("L");
    expectedImageProfiles.add("R");
    expectedImageProfiles.add("F");
    for (int i = 0; i < imagesArray.length(); i++) {
      TrainingImageResponse trainingImageResponse = ConversionUtil.deserializedResponse(imagesArray.get(i).toString(), TrainingImageResponse.class);
      Assert.assertNotNull(trainingImageResponse.getImageBagId());
      Assert.assertEquals(trainingImageResponse.getLanId(), ConfigurationFileHelper.getInstance().getLanID());
      Assert.assertEquals(trainingImageResponse.getEmpId(), ConfigurationFileHelper.getInstance().getEmployeeId());
      Assert.assertNotNull(trainingImageResponse.getImageFile());
      Assert.assertNotNull(trainingImageResponse.getEnrollmentFlag());
      Assert.assertEquals(trainingImageResponse.getImageSource(), "facetraining");
      actualImageProfiles.add(trainingImageResponse.getImageProfile());
    }
    Assert.assertTrue(expectedImageProfiles.containsAll(expectedImageProfiles));
    Assert.assertTrue(actualImageProfiles.containsAll(actualImageProfiles));
  }

  @XrayTest(key = "ORN-5721", summary = "TC_Get_Training_Images_InValid_LanID", description = "Fetch the Training Images of an Agent with InValid LandID", labels = "E2E")
  @Test(description = "Fetch the Training Images of an Agent with InValid LandID", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Get_Training_Images_InValid_LanID() throws IOException {
    response = streamingApiHelper.getTrainingImagesByLanId(ConfigurationFileHelper.getInstance().getLanID() + ".com");
    imagesArray = new JSONArray(response.getBody().asString());
    Assert.assertEquals(imagesArray.length(), 0);
  }

  @XrayTest(key = "ORN-8561", summary = "TC_Endpoint_Get_Training_Images_InValid_LanID_with_Authentication", description = "Fetch the Training Images of an Agent with InValid LandID", labels = "E2E")
  @Test(description = "Fetch the Training Images of an Agent with InValid LandID with Authentication", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Get_Training_Images_InValid_LanID_With_Authentication() throws IOException {
    response = streamingApiHelper.getTrainingImagesByLanIdWithAuthentication(ConfigurationFileHelper.getInstance().getLanID() + ".com", authToken);
    imagesArray = new JSONArray(response.getBody().asString());
    Assert.assertEquals(imagesArray.length(), 0);
  }
}
