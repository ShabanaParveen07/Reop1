package com.concentrix.suites.EndPoint.StreamingAgentErrorLog.validations;


import com.concentrix.automation.service.streaming.pojo.request.StreamingAgentErrorLogRequest;
import org.testng.Assert;

import java.sql.ResultSet;
import java.sql.SQLException;

public class AddStreamingAgentErrorLogDBValidations {

  public void validateAddStreamingAgentErrorLogDBEntry(StreamingAgentErrorLogRequest streamingAgentErrorLogRequest, ResultSet rs) {
    int count = 0;
    while (true) {
      try {
        if (!rs.next() || count > 0) break;
      } catch (SQLException e) {
        throw new RuntimeException(e);
      }
      try {
        Assert.assertNotNull(rs.getString("id"));
        Assert.assertEquals(streamingAgentErrorLogRequest.getAgentSSOId(), rs.getString("AgentSSOId"));
        Assert.assertEquals(streamingAgentErrorLogRequest.getErrorType(), rs.getString("ErrorType"));
        Assert.assertEquals(streamingAgentErrorLogRequest.getErrorMessage(), rs.getString("ErrorMessage"));
        count++;
      } catch (SQLException e) {
        throw new RuntimeException(e);
      }
    }
  }
}
