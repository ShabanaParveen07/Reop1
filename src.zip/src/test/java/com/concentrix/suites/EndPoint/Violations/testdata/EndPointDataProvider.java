package com.concentrix.suites.EndPoint.Violations.testdata;

import com.concentrix.BaseTests.ConcentrixBaseTest;
import org.testng.annotations.DataProvider;

import static com.concentrix.automation.service.streaming.constants.EndPointConstants.BLOCKED_CAMERA_IMAGE;
import static com.concentrix.automation.service.streaming.constants.EndPointConstants.CELL_PHONE_IMAGE;

public class EndPointDataProvider {


    @DataProvider(name = "createViolations")
    public static Object[][] createViolations() {
        return new Object[][] {
                {ConcentrixBaseTest.CreateViolationScenarios.BLOCKED_CAMERA,BLOCKED_CAMERA_IMAGE},
                {ConcentrixBaseTest.CreateViolationScenarios.CELL_PHONE_ONLY_ONCE,CELL_PHONE_IMAGE},
                {ConcentrixBaseTest.CreateViolationScenarios.CELL_PHONE_CONSECUTIVELY,CELL_PHONE_IMAGE}
        };

    }
}
