package com.concentrix.suites.EndPoint.OTPCode.validations;

import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.service.streaming.pojo.request.AddEmployeeOTPCodeRequest;
import org.testng.Assert;

import java.sql.ResultSet;
import java.sql.SQLException;

public class AddEmployeeOTPCodeDBValidations {

  public void validateAddEmployeeOTPCodeEntry(AddEmployeeOTPCodeRequest addEmployeeOTPCodeRequest, ResultSet rs) {
    int count = 0;
    while (true) {
      try {
        if (!rs.next() || count > 0) break;
      } catch (SQLException e) {
        throw new RuntimeException(e);
      }
      try {
        if (!addEmployeeOTPCodeRequest.getIsLoginSuccess()) {
          Assert.assertNotEquals(addEmployeeOTPCodeRequest.getOtpCode(), rs.getString("otpcode"));
        } else {
          Assert.assertEquals(addEmployeeOTPCodeRequest.getOtpCode(), rs.getString("otpcode"));
          Assert.assertNotNull(rs.getDate("useddate"));
          Assert.assertEquals(ConfigurationFileHelper.getInstance().getEmployeeId(), rs.getString("employeeid"));
          if (!addEmployeeOTPCodeRequest.getIsSupervisorOTP())
            Assert.assertEquals(rs.getInt("isSupervisorOTP"), 0);
          else
            Assert.assertEquals(rs.getInt("isSupervisorOTP"), 1);
        }
        count++;
      } catch (SQLException e) {
        throw new RuntimeException(e);
      }
    }
  }
}
