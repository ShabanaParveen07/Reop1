package com.concentrix.suites.EndPoint.DisableMonitoring.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.BaseTests.ConcentrixBaseTest;
import com.concentrix.BaseValidations.EndpointBaseValidations;
import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.helper.DateHelper;
import com.concentrix.automation.helper.corebr.CoreBrApiHelper;
import com.concentrix.automation.helper.streaming.StreamingApiHelper;
import com.concentrix.automation.service.corebr.pojo.request.ApproveAgentMonitoringRequest;
import com.concentrix.automation.service.corebr.pojo.request.BulkUpsertRequest;
import com.concentrix.automation.service.streaming.pojo.response.StandardResponse;
import com.concentrix.listeners.RetryAnalyzer;
import io.restassured.response.Response;
import lombok.extern.log4j.Log4j;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.concentrix.listeners.SuiteListener;

@Log4j
@Listeners(SuiteListener.class)
public class DisableMonitoringE2ETests extends ConcentrixBaseTest {

  String bearerAuth;
  String createdOnTime;
  String newStartTime;
  String newEndTime;
  StreamingApiHelper streamingApiHelper;
  CoreBrApiHelper coreBrApiHelper;
  Response response;
  EndpointBaseValidations endpointBaseValidations;

  @BeforeClass(alwaysRun = true)
  public void beforeClass(ITestContext context) {
    bearerAuth = (String) context.getSuite().getAttribute("bearerAuthToken");
  }

  @BeforeMethod(alwaysRun = true)
  public void beforeMethod() {
    streamingApiHelper = new StreamingApiHelper();
    coreBrApiHelper = new CoreBrApiHelper();
    endpointBaseValidations = new EndpointBaseValidations();
  }

  @XrayTest(key = "ORN-6491", summary = "TC_Endpoint_Accept_DM_ShortDuration", description = "Create a Short Disable DM Request, Approve it and check the DM Configurations", labels = "E2E")
  @Test(priority = 0, description = "Create a Short Disable DM Request, Approve it and check the DM Configurations", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Accept_DM_ShortDuration() {

    createdOnTime = DateHelper.convertLocalTimeToUTCAndModify("yyyy-MM-dd HH:mm:ss", 10000);
    newStartTime = DateHelper.convertLocalTimeToUTCAndModify("yyyy-MM-dd HH:mm:ss", 50000);
    newEndTime = DateHelper.convertLocalTimeToUTCAndModify("yyyy-MM-dd HH:mm:ss", 110000);

    // Call Bulk Upsert API to create DM Request
    BulkUpsertRequest bulkUpsertRequest = createDefaultBulkUpsertRequest(createdOnTime, newStartTime, newEndTime, true);
    response = coreBrApiHelper.configureDisableMonitoring(bulkUpsertRequest, bearerAuth);
    endpointBaseValidations.assertStandardResponse(response);

    //Call Approve Monitoring Request to Approve the DM Request
    ApproveAgentMonitoringRequest approveAgentMonitoringRequest = createDefaultApproveMonitoringRequest(ConfigurationFileHelper.getInstance().getDisableMonitoringApproveAction());
    response = coreBrApiHelper.approveAgentMonitoring(bearerAuth, approveAgentMonitoringRequest);
    endpointBaseValidations.assertStandardResponse(response);

    //Call Get Disable Monitoring Configurations API to Get the DM Configurations for the respective Agent
    response = streamingApiHelper.getDisableMonitoringConfiguration(ConfigurationFileHelper.getInstance().getSSOId(), authToken);
    endpointBaseValidations.assertStandardResponse(response);
    StandardResponse getDisableMonitoringConfigurationsResponseBody = response.as(StandardResponse.class);
    Assert.assertEquals(getDisableMonitoringConfigurationsResponseBody.getData().getStartDate(), newStartTime.replace(" ", "T"));
    Assert.assertEquals(getDisableMonitoringConfigurationsResponseBody.getData().getEndDate(), newEndTime.replace(" ", "T"));
    Assert.assertEquals(getDisableMonitoringConfigurationsResponseBody.getData().getSsoId(), bulkUpsertRequest.getBulkUpsertConfigurations()[0].getEmployeeSSOId());
    Assert.assertTrue(getDisableMonitoringConfigurationsResponseBody.getData().getIsShortDuration());
    Assert.assertEquals(getDisableMonitoringConfigurationsResponseBody.getData().getId(), bulkUpsertRequest.getBulkUpsertConfigurations()[0].getId());
    Assert.assertEquals(getDisableMonitoringConfigurationsResponseBody.getData().getMeetingName(), bulkUpsertRequest.getBulkUpsertConfigurations()[0].getMeetingName());
  }

  @XrayTest(key = "ORN-6495", summary = "TC_Endpoint_Reject_DM_ShortDuration", description = "Create a Short Disable DM Request, Reject it and check the DM Configurations", labels = "E2E")
  @Test(priority = 1, description = "Create a Short Disable DM Request, Reject it and check the DM Configurations", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Reject_DM_ShortDuration() {

    createdOnTime = DateHelper.convertLocalTimeToUTCAndModify("yyyy-MM-dd HH:mm:ss", 10000);
    newStartTime = DateHelper.convertLocalTimeToUTCAndModify("yyyy-MM-dd HH:mm:ss", 50000);
    newEndTime = DateHelper.convertLocalTimeToUTCAndModify("yyyy-MM-dd HH:mm:ss", 110000);

    // Call Bulk Upsert API to create DM Request
    BulkUpsertRequest bulkUpsertRequest = createDefaultBulkUpsertRequest(createdOnTime, newStartTime, newEndTime, true);
    response = coreBrApiHelper.configureDisableMonitoring(bulkUpsertRequest, bearerAuth);
    endpointBaseValidations.assertStandardResponse(response);

    //Call Approve Monitoring Request to Approve the DM Request
    ApproveAgentMonitoringRequest approveAgentMonitoringRequest = createDefaultApproveMonitoringRequest(ConfigurationFileHelper.getInstance().getDisableMonitoringRejectAction());
    response = coreBrApiHelper.approveAgentMonitoring(bearerAuth, approveAgentMonitoringRequest);
    endpointBaseValidations.assertStandardResponse(response);

    //Call Get Disable Monitoring Configurations API to Get the DM Configurations for the respective Agent
    response = streamingApiHelper.getDisableMonitoringConfiguration(ConfigurationFileHelper.getInstance().getSSOId(), authToken);
    endpointBaseValidations.assertStandardResponse(response);
    StandardResponse getDisableMonitoringConfigurationsResponseBody = response.as(StandardResponse.class);
    Assert.assertNull(getDisableMonitoringConfigurationsResponseBody.getData());
  }

  @XrayTest(key = "ORN-4390", summary = "TC_Endpoint_Expire_DM_ShortDuration", description = "Create a Short Disable DM Request, Let it Expire and check the DM Configurations", labels = "E2E")
  @Test(priority = 2, description = "Create a Short Disable DM Request, Let it Expire and check the DM Configurations", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Expire_DM_ShortDuration() throws InterruptedException {

    createdOnTime = DateHelper.convertLocalTimeToUTCAndModify("yyyy-MM-dd HH:mm:ss", 5000);
    newStartTime = DateHelper.convertLocalTimeToUTCAndModify("yyyy-MM-dd HH:mm:ss", 6000);
    newEndTime = DateHelper.convertLocalTimeToUTCAndModify("yyyy-MM-dd HH:mm:ss", 7000);

    // Call Bulk Upsert API to create DM Request
    BulkUpsertRequest bulkUpsertRequest = createDefaultBulkUpsertRequest(createdOnTime, newStartTime, newEndTime, true);
    response = coreBrApiHelper.configureDisableMonitoring(bulkUpsertRequest, bearerAuth);
    endpointBaseValidations.assertStandardResponse(response);

    Thread.sleep(7000);

    //Call Get Disable Monitoring Configurations API to Get the DM Configurations for the respective Agent
    response = streamingApiHelper.getDisableMonitoringConfiguration(ConfigurationFileHelper.getInstance().getSSOId(), authToken);
    endpointBaseValidations.assertStandardResponse(response);
    StandardResponse getDisableMonitoringConfigurationsResponseBody = response.as(StandardResponse.class);
    Assert.assertNull(getDisableMonitoringConfigurationsResponseBody.getData());
  }

  @XrayTest(key = "ORN-6496", summary = "TC_Endpoint_Reject_DM_FullDay", description = "Create a Full Day Disable DM Request, Reject it and check the DM Configurations", labels = "E2E")
  @Test(priority = 3, description = "Create a Full Day Disable DM Request, Reject it and check the DM Configurations", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Reject_DM_FullDay() {

    createdOnTime = DateHelper.convertLocalTimeToUTCAndModify("yyyy-MM-dd HH:mm:ss", 10000);
    newStartTime = DateHelper.convertLocalTimeToUTCAndModify("yyyy-MM-dd HH:mm:ss", -20000);
    newEndTime = DateHelper.convertLocalTimeToUTCAndModify("yyyy-MM-dd HH:mm:ss", -20000);

    // Call Bulk Upsert API to create DM Request
    BulkUpsertRequest bulkUpsertRequest = createDefaultBulkUpsertRequest(createdOnTime, newStartTime, null, false);
    response = coreBrApiHelper.configureDisableMonitoring(bulkUpsertRequest, bearerAuth);
    endpointBaseValidations.assertStandardResponse(response);

    //Call Approve Monitoring Request to Reject the DM Request
    ApproveAgentMonitoringRequest approveAgentMonitoringRequest = createDefaultApproveMonitoringRequest(ConfigurationFileHelper.getInstance().getDisableMonitoringRejectAction());
    response = coreBrApiHelper.approveAgentMonitoring(bearerAuth, approveAgentMonitoringRequest);
    endpointBaseValidations.assertStandardResponse(response);

    //Call Get Disable Monitoring Configurations API to Get the DM Configurations for the respective Agent
    response = streamingApiHelper.getDisableMonitoringConfiguration(ConfigurationFileHelper.getInstance().getSSOId(), authToken);
    endpointBaseValidations.assertStandardResponse(response);
    StandardResponse getDisableMonitoringConfigurationsResponseBody = response.as(StandardResponse.class);
    Assert.assertNull(getDisableMonitoringConfigurationsResponseBody.getData());
  }

  @XrayTest(key = "ORN-6497", summary = "TC_Endpoint_Expire_DM_FullDay", description = "Create a Full Day Disable DM Request, Let it Expire and check the DM Configurations", labels = "E2E")
  @Test(priority = 4, description = "Create a Full Day Disable DM Request, Let it Expire and check the DM Configurations", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Expire_DM_FullDay() throws InterruptedException {

    createdOnTime = DateHelper.convertLocalTimeToUTCAndModify("yyyy-MM-dd HH:mm:ss", 10000);
    newStartTime = DateHelper.convertLocalTimeToUTCAndModify("yyyy-MM-dd HH:mm:ss", -20000);
    newEndTime = DateHelper.convertLocalTimeToUTCAndModify("yyyy-MM-dd HH:mm:ss", -20000);

    // Call Bulk Upsert API to create DM Request
    BulkUpsertRequest bulkUpsertRequest = createDefaultBulkUpsertRequest(createdOnTime, newStartTime, null, false);
    response = coreBrApiHelper.configureDisableMonitoring(bulkUpsertRequest, bearerAuth);
    endpointBaseValidations.assertStandardResponse(response);

    Thread.sleep(10000);

    //Call Get Disable Monitoring Configurations API to Get the DM Configurations for the respective Agent
    response = streamingApiHelper.getDisableMonitoringConfiguration(ConfigurationFileHelper.getInstance().getSSOId(), authToken);
    endpointBaseValidations.assertStandardResponse(response);
    StandardResponse getDisableMonitoringConfigurationsResponseBody = response.as(StandardResponse.class);
    Assert.assertNull(getDisableMonitoringConfigurationsResponseBody.getData());
  }


  @XrayTest(key = "ORN-6493", summary = "TC_Endpoint_Accept_DM_FullDay", description = "Create a Full Day Disable DM Request, Approve it and check the DM Configurations", labels = "E2E")
  @Test(priority = 5, description = "Create a Full Day Disable DM Request, Approve it and check the DM Configurations", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Accept_DM_FullDay() {

    createdOnTime = DateHelper.convertLocalTimeToUTCAndModify("yyyy-MM-dd HH:mm:ss", 10000);
    newStartTime = DateHelper.convertLocalTimeToUTCAndModify("yyyy-MM-dd HH:mm:ss", -20000);
    newEndTime = DateHelper.convertLocalTimeToUTCAndModify("yyyy-MM-dd HH:mm:ss", 86380000);

    // Call Bulk Upsert API to create DM Request
    BulkUpsertRequest bulkUpsertRequest = createDefaultBulkUpsertRequest(createdOnTime, newStartTime, null, false);
    response = coreBrApiHelper.configureDisableMonitoring(bulkUpsertRequest, bearerAuth);
    endpointBaseValidations.assertStandardResponse(response);

    //Call Approve Monitoring Request to Reject the DM Request
    ApproveAgentMonitoringRequest approveAgentMonitoringRequest = createDefaultApproveMonitoringRequest(ConfigurationFileHelper.getInstance().getDisableMonitoringApproveAction());
    response = coreBrApiHelper.approveAgentMonitoring(bearerAuth, approveAgentMonitoringRequest);
    endpointBaseValidations.assertStandardResponse(response);

    //Call Get Disable Monitoring Configurations API to Get the DM Configurations for the respective Agent
    response = streamingApiHelper.getDisableMonitoringConfiguration(ConfigurationFileHelper.getInstance().getSSOId(), authToken);
    endpointBaseValidations.assertStandardResponse(response);
    StandardResponse getDisableMonitoringConfigurationsResponseBody = response.as(StandardResponse.class);
    Assert.assertEquals(getDisableMonitoringConfigurationsResponseBody.getData().getStartDate(), newStartTime.replace(" ", "T"));
    Assert.assertEquals(getDisableMonitoringConfigurationsResponseBody.getData().getEndDate(), newEndTime.replace(" ", "T"));
    Assert.assertEquals(getDisableMonitoringConfigurationsResponseBody.getData().getSsoId(), bulkUpsertRequest.getBulkUpsertConfigurations()[0].getEmployeeSSOId());
    Assert.assertFalse(getDisableMonitoringConfigurationsResponseBody.getData().getIsShortDuration());
    Assert.assertEquals(getDisableMonitoringConfigurationsResponseBody.getData().getId(), bulkUpsertRequest.getBulkUpsertConfigurations()[0].getId());
    Assert.assertEquals(getDisableMonitoringConfigurationsResponseBody.getData().getMeetingName(), bulkUpsertRequest.getBulkUpsertConfigurations()[0].getMeetingName());
  }

}
