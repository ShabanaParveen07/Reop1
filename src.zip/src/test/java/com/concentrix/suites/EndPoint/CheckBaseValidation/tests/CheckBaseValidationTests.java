package com.concentrix.suites.EndPoint.CheckBaseValidation.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.BaseTests.ConcentrixBaseTest;
import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.helper.streaming.StreamingApiHelper;
import com.concentrix.automation.service.streaming.pojo.response.GeneralResponse;
import com.concentrix.listeners.RetryAnalyzer;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class CheckBaseValidationTests extends ConcentrixBaseTest {

  StreamingApiHelper streamingApiHelper;

  GeneralResponse response;

  @BeforeClass(alwaysRun = true)
  public void beforeClass(ITestContext context) {
    streamingApiHelper = new StreamingApiHelper();
  }

  @XrayTest(key = "ORN-5718", summary = "TC_Check_Base_Validation_Valid_LanId", description = "Check Base Validation of an Agent with Valid LandID", labels = "E2E")
  @Test(description = "Check Base Validation of an Agent with Valid LandID", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Check_Base_Validation_Valid_LanId() {
    response = streamingApiHelper.getCheckBaseValidation(ConfigurationFileHelper.getInstance().getLanID()).as(GeneralResponse.class);
    Assert.assertEquals(response.getResponseResult(), "E-You can proceed to capture images");
    Assert.assertEquals(response.getResponseStatus(), "Success");
    Assert.assertNull(response.getData());
    Assert.assertEquals(response.getResponseResult1(), "Success:You can proceed to capture images");
  }

  @XrayTest(key = "ORN-8538", summary = "TC_Endpoint_Check_Base_Validation_Valid_LanId_with_Authentication", description = "Check Base Validation of an Agent with Valid LandID", labels = "E2E")
  @Test(description = "Check Base Validation of an Agent with Valid LandID with token based API", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Check_New_Base_Validation_Valid_LanId() {
    response = streamingApiHelper.getCheckBaseValidationWithAuthentication(ConfigurationFileHelper.getInstance().getLanID(), authToken).as(GeneralResponse.class);
    Assert.assertEquals(response.getResponseResult(), "E-You can proceed to capture images");
    Assert.assertEquals(response.getResponseStatus(), "Success");
    Assert.assertNull(response.getData());
    Assert.assertEquals(response.getResponseResult1(), "Success:You can proceed to capture images");
  }

  @XrayTest(key = "ORN-5719", summary = "TC_Check_Base_Validation_InValid_LanId", description = "Check Base Validation of an Agent with InValid LandID", labels = "E2E")
  @Test(description = "Check Base Validation of an Agent with InValid LandID", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Check_Base_Validation_InValid_LanId() {
    response = streamingApiHelper.getCheckBaseValidation(ConfigurationFileHelper.getInstance().getLanID() + ".com").as(GeneralResponse.class);
    Assert.assertEquals(response.getResponseResult(), "Monitoring is disabled");
    Assert.assertEquals(response.getResponseStatus(), "Fail");
    Assert.assertNull(response.getData());
    Assert.assertEquals(response.getResponseResult1(), "responseMonitoringdisabled:Monitoring is disabled");
  }

  @XrayTest(key = "ORN-8539", summary = "TC_Endpoint_Check_Base_Validation_InValid_LanId_with-Authentication", description = "Check Base Validation of an Agent with InValid LandID", labels = "E2E")
  @Test(description = "Check Base Validation of an Agent with InValid LandID", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Check_New_Base_Validation_InValid_LanId() {
    response = streamingApiHelper.getCheckBaseValidationWithAuthentication(ConfigurationFileHelper.getInstance().getLanID() + ".com", authToken).as(GeneralResponse.class);
    Assert.assertEquals(response.getResponseResult(), "Monitoring is disabled");
    Assert.assertEquals(response.getResponseStatus(), "Fail");
    Assert.assertNull(response.getData());
    Assert.assertEquals(response.getResponseResult1(), "responseMonitoringdisabled:Monitoring is disabled");
  }
}
