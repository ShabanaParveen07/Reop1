package com.concentrix.suites.EndPoint.Feedback.validations;

import com.concentrix.automation.service.streaming.pojo.request.FeedbackRequest;
import lombok.extern.log4j.Log4j;
import org.testng.Assert;

import java.sql.ResultSet;
import java.sql.SQLException;
@Log4j
public class FeedbackDBValidations {

    public void validateFeedbackDBEntry(FeedbackRequest feedbackRequest, ResultSet rs){
        try {
            Assert.assertEquals(feedbackRequest.getEmpId(), rs.getString("EmpId"));
            Assert.assertEquals(feedbackRequest.getSsoId(), rs.getString("SsoId"));
            Assert.assertEquals(feedbackRequest.getLanId(), rs.getString("LanId"));
            Assert.assertEquals(feedbackRequest.getAccount(), rs.getString("Account"));
            Assert.assertEquals(feedbackRequest.getSecureCXClientVersion(), rs.getString("SecurecxClientVersion"));
            Assert.assertNotNull(feedbackRequest.getSubmitDate());
            Assert.assertNotNull(feedbackRequest.getIpAddress());
            Assert.assertNotNull(feedbackRequest.getComputerName());
            Assert.assertEquals(feedbackRequest.getDomainName(), rs.getString("DomainName"));
            Assert.assertEquals(feedbackRequest.getApplicationName(), rs.getString("ApplicationName"));
            Assert.assertEquals(feedbackRequest.getExperience(), rs.getString("Experience"));
            Assert.assertEquals(feedbackRequest.getFeedbackType(), rs.getString("FeedbackType"));
            Assert.assertEquals(feedbackRequest.getFeedbackComments(), rs.getString("FeedbackComments"));
            Assert.assertEquals(feedbackRequest.getModuleName(), rs.getString("ModuleName"));
        } catch(SQLException sql) {
            log.error(sql.getMessage());
        }

    }
}
