package com.concentrix.suites.EndPoint.Feedback.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.BaseTests.ConcentrixBaseTest;
import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.helper.DBConnectionHelper;
import com.concentrix.automation.helper.streaming.StreamingApiHelper;
import com.concentrix.automation.service.streaming.pojo.request.FeedbackRequest;
import com.concentrix.automation.service.streaming.pojo.response.StandardResponse;
import com.concentrix.listeners.RetryAnalyzer;
import com.concentrix.suites.EndPoint.Feedback.validations.FeedbackDBValidations;
import com.concentrix.suites.EndPoint.Feedback.validations.FeedbackValidations;
import io.restassured.response.Response;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.sql.ResultSet;


public class FeedbackTests extends ConcentrixBaseTest {

  StreamingApiHelper streamingApiHelper;
  FeedbackValidations feedbackValidations;

  FeedbackDBValidations feedbackDBValidations;

  String envName;

  ResultSet rs;

  private DBConnectionHelper dbConnectionHelper;

  String FEEDBACK_SQL_QUERY;

  @BeforeClass(alwaysRun = true)
  public void beforeClass() {
    streamingApiHelper = new StreamingApiHelper();
  }

  @BeforeMethod(alwaysRun = true)
  public void beforeMethod() {
    envName = System.getProperty("env");
    if (envName == null)
      envName = "qa";
    feedbackValidations = new FeedbackValidations();
    dbConnectionHelper = DBConnectionHelper.getInstance();
    feedbackDBValidations = new FeedbackDBValidations();
    FEEDBACK_SQL_QUERY = "SELECT * from fb_enrollment_" + envName + ".Feedback where lanid=" + "'" + ConfigurationFileHelper.getInstance().getLanID() + "'" + " order by SubmitDate desc";
  }

  @XrayTest(key = "ORN-5312", summary = "TC_Endpoint_Feedback_I_Found_A_Bug", description = "Send Feedback About SecureCX Application with Feedback type as I found a bug", labels = "E2E")
  @Test(description = "Send Feedback About SecureCX Application with Feedback type as I found a bug", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Feedback_I_Found_A_Bug() {
    FeedbackRequest feedbackRequest = createDefaultFeedbackRequest();
    feedbackRequest.setFeedbackType("I found a bug");
    feedbackRequest.setFeedbackComments("Found a Bug");
    feedbackRequest.setExperience("3");
    Response response = streamingApiHelper.postFeedback(feedbackRequest);
    StandardResponse feedbackResponse = response.getBody().as(StandardResponse.class);
    feedbackValidations.validateFeedbackResponse(FeedbackScenarios.FEEDBACK_TYPE_I_FOUND_A_BUG, feedbackResponse);
    rs = dbConnectionHelper.executeQuery(FEEDBACK_SQL_QUERY);
    feedbackDBValidations.validateFeedbackDBEntry(feedbackRequest, rs);
  }

  @XrayTest(key = "ORN-8820", summary = "TC_Endpoint_Feedback_I_Found_A_Bug_with_authentication", description = "Send Feedback About SecureCX Application with Feedback type as I found a bug", labels = "E2E")
  @Test(description = "Send Feedback About SecureCX Application with Feedback type as I found a bug with authentication", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Feedback_I_Found_A_Bug_with_Authentication() {
    FeedbackRequest feedbackRequest = createDefaultFeedbackRequest();
    feedbackRequest.setFeedbackType("I found a bug");
    feedbackRequest.setFeedbackComments("Found a Bug");
    feedbackRequest.setExperience("3");
    Response response = streamingApiHelper.postFeedbackWithAuthentication(feedbackRequest, authToken);
    StandardResponse feedbackResponse = response.getBody().as(StandardResponse.class);
    feedbackValidations.validateFeedbackResponse(FeedbackScenarios.FEEDBACK_TYPE_I_FOUND_A_BUG, feedbackResponse);
    rs = dbConnectionHelper.executeQuery(FEEDBACK_SQL_QUERY);
    feedbackDBValidations.validateFeedbackDBEntry(feedbackRequest, rs);
  }

  @XrayTest(key = "ORN-5313", summary = "TC_Endpoint_Feedback_I_Have_A_Suggestion", description = "Send Feedback About SecureCX Application with Feedback type as I have a Suggestion", labels = "E2E")
  @Test(description = "Send Feedback About SecureCX Application with Feedback type as I have a Suggestion", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Feedback_I_Have_A_Suggestion() {
    FeedbackRequest feedbackRequest = createDefaultFeedbackRequest();
    feedbackRequest.setFeedbackType("I have a suggestion");
    feedbackRequest.setFeedbackComments("UI can be improved");
    feedbackRequest.setExperience("5");
    Response response = streamingApiHelper.postFeedback(feedbackRequest);
    StandardResponse feedbackResponse = response.getBody().as(StandardResponse.class);
    feedbackValidations.validateFeedbackResponse(FeedbackScenarios.FEEDBACK_TYPE_I_HAVE_A_SUGGESTION, feedbackResponse);
    rs = dbConnectionHelper.executeQuery(FEEDBACK_SQL_QUERY);
    feedbackDBValidations.validateFeedbackDBEntry(feedbackRequest, rs);
  }

  @XrayTest(key = "ORN-8821", summary = "TC_Endpoint_Feedback_I_Have_A_Suggestion_with_authentication", description = "Send Feedback About SecureCX Application with Feedback type as I have a Suggestion", labels = "E2E")
  @Test(description = "Send Feedback About SecureCX Application with Feedback type as I have a Suggestion with authentication", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Feedback_I_Have_A_Suggestion_with_Authentication() {
    FeedbackRequest feedbackRequest = createDefaultFeedbackRequest();
    feedbackRequest.setFeedbackType("I have a suggestion");
    feedbackRequest.setFeedbackComments("UI can be improved");
    feedbackRequest.setExperience("5");
    Response response = streamingApiHelper.postFeedbackWithAuthentication(feedbackRequest, authToken);
    StandardResponse feedbackResponse = response.getBody().as(StandardResponse.class);
    feedbackValidations.validateFeedbackResponse(FeedbackScenarios.FEEDBACK_TYPE_I_HAVE_A_SUGGESTION, feedbackResponse);
    rs = dbConnectionHelper.executeQuery(FEEDBACK_SQL_QUERY);
    feedbackDBValidations.validateFeedbackDBEntry(feedbackRequest, rs);
  }

  @XrayTest(key = "ORN-5314", summary = "TC_Endpoint_Feedback_Other", description = "Send Feedback About SecureCX Application with Feedback type as Other", labels = "E2E")
  @Test(description = "Send Feedback About SecureCX Application with Feedback type as Other", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Feedback_Other() {
    FeedbackRequest feedbackRequest = createDefaultFeedbackRequest();
    feedbackRequest.setFeedbackType("Other");
    feedbackRequest.setFeedbackComments("Anything");
    feedbackRequest.setExperience("1");
    Response response = streamingApiHelper.postFeedback(feedbackRequest);
    StandardResponse feedbackResponse = response.getBody().as(StandardResponse.class);
    feedbackValidations.validateFeedbackResponse(FeedbackScenarios.FEEDBACK_TYPE_OTHER, feedbackResponse);
    rs = dbConnectionHelper.executeQuery(FEEDBACK_SQL_QUERY);
    feedbackDBValidations.validateFeedbackDBEntry(feedbackRequest, rs);
  }

  @XrayTest(key = "ORN-8822", summary = "TC_Endpoint_Feedback_Other_with_authentication", description = "Send Feedback About SecureCX Application with Feedback type as Other", labels = "E2E")
  @Test(description = "Send Feedback About SecureCX Application with Feedback type as Other with authentication", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Feedback_Other_with_Authentication() {
    FeedbackRequest feedbackRequest = createDefaultFeedbackRequest();
    feedbackRequest.setFeedbackType("Other");
    feedbackRequest.setFeedbackComments("Anything");
    feedbackRequest.setExperience("1");
    Response response = streamingApiHelper.postFeedbackWithAuthentication(feedbackRequest, authToken);
    StandardResponse feedbackResponse = response.getBody().as(StandardResponse.class);
    feedbackValidations.validateFeedbackResponse(FeedbackScenarios.FEEDBACK_TYPE_OTHER, feedbackResponse);
    rs = dbConnectionHelper.executeQuery(FEEDBACK_SQL_QUERY);
    feedbackDBValidations.validateFeedbackDBEntry(feedbackRequest, rs);
  }

  @XrayTest(key = "ORN-5315", summary = "TC_Endpoint_Feedback_Null", description = "Send Feedback About SecureCX Application with Feedback type as null", labels = "E2E")
  @Test(description = "Send Feedback About SecureCX Application with Feedback type as null", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Feedback_Null() {
    FeedbackRequest feedbackRequest = createDefaultFeedbackRequest();
    feedbackRequest.setFeedbackType(null);
    feedbackRequest.setFeedbackComments("Found a Bug");
    feedbackRequest.setExperience("3");
    Response response = streamingApiHelper.postFeedback(feedbackRequest);
    StandardResponse feedbackResponse = response.getBody().as(StandardResponse.class);
    feedbackValidations.validateFeedbackResponse(FeedbackScenarios.FEEDBACK_TYPE_NULL, feedbackResponse);
    rs = dbConnectionHelper.executeQuery(FEEDBACK_SQL_QUERY);
    feedbackDBValidations.validateFeedbackDBEntry(feedbackRequest, rs);

  }

  @XrayTest(key = "ORN-8823", summary = "TC_Endpoint_Feedback_Null_with_Authentication", description = "Send Feedback About SecureCX Application with Feedback type as null", labels = "E2E")
  @Test(description = "Send Feedback About SecureCX Application with Feedback type as null with authentication", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Feedback_Null_with_Authentication() {
    FeedbackRequest feedbackRequest = createDefaultFeedbackRequest();
    feedbackRequest.setFeedbackType(null);
    feedbackRequest.setFeedbackComments("Found a Bug");
    feedbackRequest.setExperience("3");
    Response response = streamingApiHelper.postFeedbackWithAuthentication(feedbackRequest, authToken);
    StandardResponse feedbackResponse = response.getBody().as(StandardResponse.class);
    feedbackValidations.validateFeedbackResponse(FeedbackScenarios.FEEDBACK_TYPE_NULL, feedbackResponse);
    rs = dbConnectionHelper.executeQuery(FEEDBACK_SQL_QUERY);
    feedbackDBValidations.validateFeedbackDBEntry(feedbackRequest, rs);

  }
}
