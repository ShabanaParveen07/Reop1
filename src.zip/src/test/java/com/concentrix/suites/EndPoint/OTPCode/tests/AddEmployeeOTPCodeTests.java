package com.concentrix.suites.EndPoint.OTPCode.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.BaseTests.ConcentrixBaseTest;
import com.concentrix.BaseValidations.EndpointBaseValidations;
import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.helper.DBConnectionHelper;
import com.concentrix.automation.helper.streaming.StreamingApiHelper;
import com.concentrix.automation.service.streaming.pojo.request.AddEmployeeOTPCodeRequest;
import com.concentrix.listeners.RetryAnalyzer;
import com.concentrix.suites.EndPoint.OTPCode.validations.AddEmployeeOTPCodeDBValidations;
import lombok.extern.log4j.Log4j;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.sql.ResultSet;
import java.util.Random;

@Log4j
public class AddEmployeeOTPCodeTests extends ConcentrixBaseTest {

  StreamingApiHelper streamingApiHelper;

  String envName;

  ResultSet rs;

  private DBConnectionHelper dbConnectionHelper;

  String ADD_OTP_QUERY;

  String otp;

  Random rand;

  EndpointBaseValidations baseValidations;

  AddEmployeeOTPCodeDBValidations addEmployeeOTPCodeDBValidations;

  @BeforeClass(alwaysRun = true)
  public void beforeClass() {
    streamingApiHelper = new StreamingApiHelper();
  }

  @BeforeMethod(alwaysRun = true)
  public void beforeMethod() {
    Random rand = new Random();
    otp = String.valueOf(rand.nextInt(999999));
    dbConnectionHelper = DBConnectionHelper.getInstance();
    baseValidations = new EndpointBaseValidations();
    addEmployeeOTPCodeDBValidations = new AddEmployeeOTPCodeDBValidations();
    envName = System.getProperty("env");
    if (envName == null)
      envName = "qa";
    ADD_OTP_QUERY = "SELECT * from fb_enrollment_" + envName + ".EmployeeOTPCodes order by useddate desc";
  }

  @XrayTest(key = "ORN-6826", summary = "TC_Endpoint_Add_OTP_Code_Login_Success", description = "Send an OTP Code with Is Login Success as True", labels = "E2E")
  @Test(description = "Send an OTP Code with Is Login Success as True", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Add_OTP_Code_Login_Success() throws InterruptedException {
    AddEmployeeOTPCodeRequest addEmployeeOTPCodeRequest = AddEmployeeOTPCodeRequest.builder().
        lanId(ConfigurationFileHelper.getInstance().getLanID()).
        otpCode(otp).
        isLoginSuccess(true).
        isOTPExpired(false).
        isSupervisorOTP(false).build();
    baseValidations.assertStandardResponse(streamingApiHelper.addEmployeeOTPCode(addEmployeeOTPCodeRequest));
    Thread.sleep(2000);
    rs = dbConnectionHelper.executeQuery(ADD_OTP_QUERY);
    addEmployeeOTPCodeDBValidations.validateAddEmployeeOTPCodeEntry(addEmployeeOTPCodeRequest, rs);
  }

  @XrayTest(key = "ORN-6827", summary = "TC_Endpoint_Add_OTP_Code_Login_Failure", description = "Send an OTP Code with Is Login Success as False", labels = "E2E")
  @Test(description = "Send an OTP Code with Is Login Success as False", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Add_OTP_Code_Login_Failure() throws InterruptedException {
    AddEmployeeOTPCodeRequest addEmployeeOTPCodeRequest = AddEmployeeOTPCodeRequest.builder().
        lanId(ConfigurationFileHelper.getInstance().getLanID()).
        otpCode(otp).
        isLoginSuccess(false).
        isOTPExpired(false).
        isSupervisorOTP(false).build();
    baseValidations.assertStandardResponse(streamingApiHelper.addEmployeeOTPCode(addEmployeeOTPCodeRequest));
    Thread.sleep(2000);
    rs = dbConnectionHelper.executeQuery(ADD_OTP_QUERY);
    addEmployeeOTPCodeDBValidations.validateAddEmployeeOTPCodeEntry(addEmployeeOTPCodeRequest, rs);
  }

  @XrayTest(key = "ORN-6828", summary = "TC_Endpoint_Add_OTP_Code_Expired", description = "Send an OTP Code with Is Expired as true", labels = "E2E")
  @Test(description = "Send an OTP Code with Is Expired as true", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Add_OTP_Code_Expired() throws InterruptedException {
    AddEmployeeOTPCodeRequest addEmployeeOTPCodeRequest = AddEmployeeOTPCodeRequest.builder().
        lanId(ConfigurationFileHelper.getInstance().getLanID()).
        otpCode(otp).
        isLoginSuccess(true).
        isOTPExpired(true).
        isSupervisorOTP(false).build();
    baseValidations.assertStandardResponse(streamingApiHelper.addEmployeeOTPCode(addEmployeeOTPCodeRequest));
    Thread.sleep(2000);
    rs = dbConnectionHelper.executeQuery(ADD_OTP_QUERY);
    addEmployeeOTPCodeDBValidations.validateAddEmployeeOTPCodeEntry(addEmployeeOTPCodeRequest, rs);
  }

  @XrayTest(key = "ORN-6829", summary = "TC_Endpoint_Add_OTP_Code_Not_Expired", description = "Send an OTP Code with Is Expired as false", labels = "E2E")
  @Test(description = "Send an OTP Code with Is Expired as false", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Add_OTP_Code_Not_Expired() throws InterruptedException {
    AddEmployeeOTPCodeRequest addEmployeeOTPCodeRequest = AddEmployeeOTPCodeRequest.builder().
        lanId(ConfigurationFileHelper.getInstance().getLanID()).
        otpCode(otp).
        isLoginSuccess(true).
        isOTPExpired(false).
        isSupervisorOTP(false).build();
    baseValidations.assertStandardResponse(streamingApiHelper.addEmployeeOTPCode(addEmployeeOTPCodeRequest));
    Thread.sleep(2000);
    rs = dbConnectionHelper.executeQuery(ADD_OTP_QUERY);
    addEmployeeOTPCodeDBValidations.validateAddEmployeeOTPCodeEntry(addEmployeeOTPCodeRequest, rs);
  }

  @XrayTest(key = "ORN-6830", summary = "TC_Endpoint_Add_OTP_Code_SuperVisorOTP", description = "Send an OTP Code with Is Supervisor OTP as true", labels = "E2E")
  @Test(description = "Send an OTP Code with Is Supervisor OTP as false", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Add_OTP_Code_SuperVisorOTP() throws InterruptedException {
    AddEmployeeOTPCodeRequest addEmployeeOTPCodeRequest = AddEmployeeOTPCodeRequest.builder().
        lanId(ConfigurationFileHelper.getInstance().getLanID()).
        otpCode(otp).
        isLoginSuccess(true).
        isOTPExpired(false).
        isSupervisorOTP(true).build();
    baseValidations.assertStandardResponse(streamingApiHelper.addEmployeeOTPCode(addEmployeeOTPCodeRequest));
    Thread.sleep(2000);
    rs = dbConnectionHelper.executeQuery(ADD_OTP_QUERY);
    addEmployeeOTPCodeDBValidations.validateAddEmployeeOTPCodeEntry(addEmployeeOTPCodeRequest, rs);
  }

  @XrayTest(key = "ORN-6831", summary = "TC_Endpoint_Add_OTP_Code_Not_SuperVisorOTP", description = "Send an OTP Code with Is Supervisor OTP as false", labels = "E2E")
  @Test(description = "Send an OTP Code with Is Supervisor OTP as false", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Add_OTP_Code_Not_SuperVisorOTP() throws InterruptedException {
    AddEmployeeOTPCodeRequest addEmployeeOTPCodeRequest = AddEmployeeOTPCodeRequest.builder().
        lanId(ConfigurationFileHelper.getInstance().getLanID()).
        otpCode(otp).
        isLoginSuccess(true).
        isOTPExpired(false).
        isSupervisorOTP(false).build();
    baseValidations.assertStandardResponse(streamingApiHelper.addEmployeeOTPCode(addEmployeeOTPCodeRequest));
    Thread.sleep(2000);
    rs = dbConnectionHelper.executeQuery(ADD_OTP_QUERY);
    addEmployeeOTPCodeDBValidations.validateAddEmployeeOTPCodeEntry(addEmployeeOTPCodeRequest, rs);
  }

}
