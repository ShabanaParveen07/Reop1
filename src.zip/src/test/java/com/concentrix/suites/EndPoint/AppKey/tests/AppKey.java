package com.concentrix.suites.EndPoint.AppKey.tests;

import com.concentrix.BaseTests.ConcentrixBaseTest;
import com.concentrix.listeners.RetryAnalyzer;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.helper.streaming.StreamingApiHelper;
import com.concentrix.automation.service.streaming.pojo.response.GeneralResponse;

import app.getxray.xray.testng.annotations.XrayTest;
import io.restassured.response.Response;

public class AppKey extends ConcentrixBaseTest {

  StreamingApiHelper streamingApiHelper;

  GeneralResponse responseBody;

  Response response;

  @BeforeClass(alwaysRun = true)
  public void beforeClass() {
    streamingApiHelper = new StreamingApiHelper();
  }

  @XrayTest(key = "ORN-6516", summary = "TC_Get_AppKey_Response", description = "Validate Response for AppKey API", labels = "E2E")
  @Test(description = "Validate Response for AppKey API", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Get_AppKey_Api() {
    response = streamingApiHelper.getAppKey();
    String expectedresult = ConfigurationFileHelper.getInstance().getAppKeyExpectedResult();
    Assert.assertEquals(response.getStatusCode(), Integer.parseInt(ConfigurationFileHelper.getInstance().getStatusCode()));
    Assert.assertEquals(response.asPrettyString(), expectedresult);
  }

  @XrayTest(key = "ORN-8540", summary = "TC_Get_AppKey_Response_With_Authentication", description = "Validate Response for AppKey API", labels = "E2E")
  @Test(description = "Validate Response for AppKey API with Authentication", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Get_AppKey_Api_with_Authentication() {
    response = streamingApiHelper.getAppKeyWithAutherization(authToken);
    String expectedresult = ConfigurationFileHelper.getInstance().getAppKeyExpectedResult();
    Assert.assertEquals(response.getStatusCode(), Integer.parseInt(ConfigurationFileHelper.getInstance().getStatusCode()));
    Assert.assertEquals(response.asPrettyString(), expectedresult);
  }

}
