package com.concentrix.suites.EndPoint.ConnectedClientsHealth.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.helper.streaming.StreamingApiHelper;
import com.concentrix.automation.service.streaming.pojo.response.GeneralResponse;
import com.concentrix.listeners.RetryAnalyzer;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class GetConnectedClientsHealthTests {

  StreamingApiHelper streamingApiHelper;
  Response response;

  @BeforeClass(alwaysRun = true)
  public void beforeClass() {
    streamingApiHelper = new StreamingApiHelper();
  }

  @XrayTest(key = "ORN-7165", summary = "TC_Get_Connected_Clients_Health_Api", description = "Validate Response for Health API", labels = "E2E")
  @Test(description = "Validate Response for Health API", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Get_Connected_Clients_Health_Api() {
    response = streamingApiHelper.getConnectedClientsHealth();
    Assert.assertEquals(response.getStatusCode(), Integer.parseInt(ConfigurationFileHelper.getInstance().getStatusCode()));
    Assert.assertEquals(response.asPrettyString(), "Healthy");
  }
}
