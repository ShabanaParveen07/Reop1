package com.concentrix.suites.EndPoint.LogClientEvent.validations;

import com.concentrix.automation.service.streaming.pojo.request.ClientEventRequest;
import lombok.extern.log4j.Log4j;
import org.testng.Assert;

import java.sql.ResultSet;
import java.sql.SQLException;

@Log4j
public class LogClientEventDBValidations {

    public void validateClientEventEntry(ClientEventRequest clientEventRequest, ResultSet rs){
        try {
            Assert.assertEquals(clientEventRequest.getData().getSsoId(), rs.getString("AgentSSOId"));
            Assert.assertEquals(clientEventRequest.getData().getEventType(), rs.getString("EventType"));
            Assert.assertNotNull(rs.getString("Id"));
            Assert.assertNotNull(rs.getString("LogTimeStamp"));
        } catch(SQLException sql) {
            log.error(sql.getMessage());
        }

    }
}
