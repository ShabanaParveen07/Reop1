package com.concentrix.suites.EndPoint.LogConfigurations.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.BaseValidations.EndpointBaseValidations;
import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.helper.streaming.StreamingApiHelper;
import com.concentrix.automation.service.streaming.pojo.response.StandardResponse;
import com.concentrix.listeners.RetryAnalyzer;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class AgentLogConfigurationTests {

    StreamingApiHelper streamingApiHelper;
    
    Response response;

    EndpointBaseValidations endpointBaseValidations;

    @BeforeClass(alwaysRun = true)
    public void beforeClass() {
        streamingApiHelper = new StreamingApiHelper();
        endpointBaseValidations = new EndpointBaseValidations();
    }

    @XrayTest(key = "ORN-7410", summary = "TC_Get_Agent_Log_Configurations_Valid_LanId", description = "Validate Response when Valid SSO ID is given", labels = "E2E")
    @Test(description = "Validate Response when Valid SSO ID is given", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Get_Agent_Log_Configurations_Valid_LanId() {
        response = streamingApiHelper.getAgentLogConfigurations(ConfigurationFileHelper.getInstance().getLanID());
        endpointBaseValidations.assertStandardResponse(response);
    }

    @XrayTest(key = "ORN-7411", summary = "TC_Get_Agent_Log_Configurations_InvValid_LanId", description = "Validate Response when InValid SSO ID is given", labels = "E2E")
    @Test(description = "Validate Response when InvValid SSO ID is given", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Get_Agent_Log_Configurations_InValid_LanId() {
        response = streamingApiHelper.getAgentLogConfigurations(ConfigurationFileHelper.getInstance().getLanID()+".com");
        Assert.assertEquals(response.statusCode(), Integer.parseInt(ConfigurationFileHelper.getInstance().getStatusCode()));
        StandardResponse standardResponse = response.as(StandardResponse.class);
        Assert.assertFalse(standardResponse.getSuccess());
        Assert.assertEquals(standardResponse.getErrorMessage(), "Cannot find record for Sso Id: " + ConfigurationFileHelper.getInstance().getLanID()+".com");
    }
}
