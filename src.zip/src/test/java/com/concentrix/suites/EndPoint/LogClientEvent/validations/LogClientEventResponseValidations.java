package com.concentrix.suites.EndPoint.LogClientEvent.validations;
import com.concentrix.automation.service.streaming.pojo.response.StandardResponse;
import org.testng.Assert;


public class LogClientEventResponseValidations {

    public void validatePostClientEventResponse(StandardResponse clientEventResponse) {

        Assert.assertNotNull(clientEventResponse.getCorrelationId());
        Assert.assertTrue(clientEventResponse.getSuccess());
    }
}
