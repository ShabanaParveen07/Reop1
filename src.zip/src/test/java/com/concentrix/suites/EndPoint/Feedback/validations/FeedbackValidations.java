package com.concentrix.suites.EndPoint.Feedback.validations;

import com.concentrix.BaseTests.ConcentrixBaseTest;
import com.concentrix.automation.service.streaming.pojo.response.StandardResponse;
import org.testng.Assert;

public class FeedbackValidations {

    public void validateFeedbackResponse(
            ConcentrixBaseTest.FeedbackScenarios testDescription, StandardResponse feedbackResponse) {

        switch (testDescription) {
            case FEEDBACK_TYPE_I_FOUND_A_BUG:
            case FEEDBACK_TYPE_OTHER:
            case FEEDBACK_TYPE_NULL:
            case FEEDBACK_TYPE_I_HAVE_A_SUGGESTION:
                Assert.assertTrue(feedbackResponse.getCorrelationId().length() > 0);
                Assert.assertTrue(feedbackResponse.getSuccess());
                Assert.assertNull(feedbackResponse.getData());
        }

    }
}
