package com.concentrix.suites.EndPoint.Authentication.validations;


import static com.concentrix.automation.service.streaming.constants.EndPointConstants.*;


import org.testng.Assert;

import com.concentrix.BaseTests.ConcentrixBaseTest;
import com.concentrix.automation.service.streaming.pojo.response.GetLastImageProcessedStatusResponse;
import com.concentrix.automation.service.streaming.pojo.response.ResponseResult;

import io.restassured.response.Response;

public class AuthenticationValidations {

    public void validateResponseForAuthenticationScenariosWithBlurType(
            ConcentrixBaseTest.AuthenticationScenariosWithBlurType testDescription, Response response, GetLastImageProcessedStatusResponse getLastImageProcessedStatusResponse) {

        Assert.assertEquals(response.getStatusCode(), responseOK);
        Assert.assertNotNull(getLastImageProcessedStatusResponse.getImageBagID());
        Assert.assertNotNull(getLastImageProcessedStatusResponse.getImageCacheKey());
        Assert.assertNotNull(getLastImageProcessedStatusResponse.getProcessedOn());
        Assert.assertEquals(getLastImageProcessedStatusResponse.getFaceAuthMode(), FACE_AUTH_MODE_STARTUP);
        switch (testDescription) {

            case NO_BLUR_SUCCESS:
            case NO_BLUR_CELL_PHONE:
            case NO_BLUR_MULTIPLE_PERSONS:
            case SECONDARY_PERSON_BLUR_SUCCESS:
            case SECONDARY_PERSON_BLUR_CELL_PHONE:
            case SECONDARY_PERSON_BLUR_MULTIPLE_PERSONS:
            case BLUR_BACKGROUND_CELL_PHONE:
            case BLUR_BACKGROUND_MULTIPLE_PERSONS:
            case BLUR_BACKGROUND_SUCCESS:
                Assert.assertEquals(getLastImageProcessedStatusResponse.getStatus(), statusY);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultDescription(), successDescription);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultDescription1(), successResultId + ":" + successDescription);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultId(), successResultId);
                Assert.assertNull(getLastImageProcessedStatusResponse.getActions());
                Assert.assertNull(getLastImageProcessedStatusResponse.getActionsNewFormat());
                break;

            case SECONDARY_PERSON_BLUR_NO_FACES_FOUND:
            case BLUR_BACKGROUND_NO_FACES_FOUND:
            case NO_BLUR_NO_FACES_FOUND:
                Assert.assertEquals(getLastImageProcessedStatusResponse.getStatus(), statusY);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultDescription(), NO_FACES_FOUND_ON_STARTUP_DESCRIPTION);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultDescription1(), noFacesFoundOnStartUpResultId + ":" + NO_FACES_FOUND_ON_STARTUP_DESCRIPTION);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultId(), noFacesFoundOnStartUpResultId);
                Assert.assertNull(getLastImageProcessedStatusResponse.getActions());
                Assert.assertNull(getLastImageProcessedStatusResponse.getActionsNewFormat());
                break;

            case SECONDARY_PERSON_BLUR_BLOCKED_CAMERA:
            case BLUR_BACKGROUND_BLOCKED_CAMERA:
            case NO_BLUR_BLOCKED_CAMERA:
                Assert.assertEquals(getLastImageProcessedStatusResponse.getStatus(), statusY);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultDescription(), BLOCKED_CAMERA_ON_STARTUP_DESCRIPTION);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultDescription1(), blockedCameraOnStartupResulId + ":");
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultId(), blockedCameraOnStartupResulId);
                Assert.assertNull(getLastImageProcessedStatusResponse.getActions());
                Assert.assertNull(getLastImageProcessedStatusResponse.getActionsNewFormat());
                break;

            case SECONDARY_PERSON_BLUR_OTHER_PERSON:
            case BLUR_BACKGROUND_OTHER_PERSON:
            case NO_BLUR_OTHER_PERSON:
                Assert.assertEquals(getLastImageProcessedStatusResponse.getStatus(), statusY);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultDescription(), AUTHENTICATION_FAILED_ON_STARTUP_RESULT_DESCRIPTION);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultDescription1(), unknownPersonResultId + ":" + unknownPersonDescription);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultId(), unknownPersonResultId);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getActions().length, 0);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getActionsNewFormat().length, 0);
                break;

            case SECONDARY_PERSON_BLUR_OTHER_PERSON_CONSECUTIVELY:
            case BLUR_BACKGROUND_OTHER_PERSON_CONSECUTIVELY:
            case NO_BLUR_OTHER_PERSON_CONSECUTIVELY:
                Assert.assertEquals(getLastImageProcessedStatusResponse.getStatus(), statusY);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultDescription(), AUTHENTICATION_FAILED_ON_STARTUP_RESULT_DESCRIPTION);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultDescription1(), unknownPersonResultId + ":" + unknownPersonDescription);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultId(), unknownPersonResultId);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getActions()[0].getActionType(), screenLockOutText);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getActions()[0].getActionData().getAlertMessage(), UNKNOWN_PERSON_ERROR);

                Assert.assertEquals(getLastImageProcessedStatusResponse.getActionsNewFormat()[0].getActionType(), screenLockOutText);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getActionsNewFormat()[0].getActionData().getAlertMessage(), UNKNOWN_PERSON_ERROR_NEW);

        }
    }

    public void validateResponseForAuthenticationResumeScenariosWithBlurType(
            ConcentrixBaseTest.AuthenticationScenariosWithBlurType testDescription, Response response, GetLastImageProcessedStatusResponse getLastImageProcessedStatusResponse) {

        Assert.assertEquals(response.getStatusCode(), responseOK);
        Assert.assertNotNull(getLastImageProcessedStatusResponse.getImageBagID());
        Assert.assertNotNull(getLastImageProcessedStatusResponse.getImageCacheKey());
        Assert.assertNotNull(getLastImageProcessedStatusResponse.getProcessedOn());
        Assert.assertEquals(getLastImageProcessedStatusResponse.getFaceAuthMode(), FACE_AUTH_MODE_RESUME);
        switch (testDescription) {

            case NO_BLUR_SUCCESS:
            case NO_BLUR_CELL_PHONE:
            case NO_BLUR_MULTIPLE_PERSONS:
            case SECONDARY_PERSON_BLUR_SUCCESS:
            case SECONDARY_PERSON_BLUR_CELL_PHONE:
            case SECONDARY_PERSON_BLUR_MULTIPLE_PERSONS:
            case BLUR_BACKGROUND_CELL_PHONE:
            case BLUR_BACKGROUND_MULTIPLE_PERSONS:
            case BLUR_BACKGROUND_SUCCESS:
                Assert.assertEquals(getLastImageProcessedStatusResponse.getStatus(), statusY);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultDescription(), successDescription);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultDescription1(), successResultId + ":" + successDescription);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultId(), successResultId);
                Assert.assertNull(getLastImageProcessedStatusResponse.getActions());
                Assert.assertNull(getLastImageProcessedStatusResponse.getActionsNewFormat());
                break;

            case SECONDARY_PERSON_BLUR_NO_FACES_FOUND:
            case BLUR_BACKGROUND_NO_FACES_FOUND:
            case NO_BLUR_NO_FACES_FOUND:
                Assert.assertEquals(getLastImageProcessedStatusResponse.getStatus(), statusY);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultDescription(), NO_FACES_FOUND_ON_RESUME_DESCRIPTION);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultDescription1(), noFacesFoundOnResumeResultId + ":" + NO_FACES_FOUND_ON_RESUME_DESCRIPTION);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultId(), noFacesFoundOnResumeResultId);
                Assert.assertNull(getLastImageProcessedStatusResponse.getActions());
                Assert.assertNull(getLastImageProcessedStatusResponse.getActionsNewFormat());
                break;

            case SECONDARY_PERSON_BLUR_BLOCKED_CAMERA:
            case BLUR_BACKGROUND_BLOCKED_CAMERA:
            case NO_BLUR_BLOCKED_CAMERA:
                Assert.assertEquals(getLastImageProcessedStatusResponse.getStatus(), statusY);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultDescription(), BLOCKED_CAMERA_ON_RESUME_DESCRIPTION);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultDescription1(), blockedCameraOnStartupResulId + ":");
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultId(), blockedCameraOnStartupResulId);
                Assert.assertNull(getLastImageProcessedStatusResponse.getActions());
                Assert.assertNull(getLastImageProcessedStatusResponse.getActionsNewFormat());
                break;

            case SECONDARY_PERSON_BLUR_OTHER_PERSON:
            case BLUR_BACKGROUND_OTHER_PERSON:
            case NO_BLUR_OTHER_PERSON:
                Assert.assertEquals(getLastImageProcessedStatusResponse.getStatus(), statusY);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultDescription(), AUTHENTICATION_FAILED_ON_RESUME_RESULT_DESCRIPTION);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultDescription1(), unknownPersonResultId + ":" + unknownPersonDescription);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultId(), unknownPersonResultId);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getActions().length, 0);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getActionsNewFormat().length, 0);
                break;

            case SECONDARY_PERSON_BLUR_OTHER_PERSON_CONSECUTIVELY:
            case BLUR_BACKGROUND_OTHER_PERSON_CONSECUTIVELY:
            case NO_BLUR_OTHER_PERSON_CONSECUTIVELY:
                Assert.assertEquals(getLastImageProcessedStatusResponse.getStatus(), statusY);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultDescription(), AUTHENTICATION_FAILED_ON_RESUME_RESULT_DESCRIPTION);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultDescription1(), unknownPersonResultId + ":" + unknownPersonDescription);
                Assert.assertEquals(
                        getLastImageProcessedStatusResponse.getResultId(), unknownPersonResultId);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getActions()[0].getActionType(), screenLockOutText);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getActions()[0].getActionData().getAlertMessage(), UNKNOWN_PERSON_ERROR);

                Assert.assertEquals(getLastImageProcessedStatusResponse.getActionsNewFormat()[0].getActionType(), screenLockOutText);
                Assert.assertEquals(getLastImageProcessedStatusResponse.getActionsNewFormat()[0].getActionData().getAlertMessage(), UNKNOWN_PERSON_ERROR_NEW);

        }
    }

    public void validateResponseForNewAuthenticationScenariosWithBlurType(
            ConcentrixBaseTest.AuthenticationScenariosWithBlurType testDescription, ResponseResult responseResult, Integer faceAuthMode) {

        Assert.assertNotNull(responseResult.getTime());
        Assert.assertEquals(responseResult.getFaceAuthMode(), faceAuthMode);

        switch (testDescription) {

            case NO_BLUR_SUCCESS:
            case NO_BLUR_CELL_PHONE:
            case NO_BLUR_MULTIPLE_PERSONS:
            case BLUR_BACKGROUND_SUCCESS:
            case BLUR_BACKGROUND_CELL_PHONE:
            case BLUR_BACKGROUND_MULTIPLE_PERSONS:
            case SECONDARY_PERSON_BLUR_SUCCESS:
            case SECONDARY_PERSON_BLUR_CELL_PHONE:
            case SECONDARY_PERSON_BLUR_MULTIPLE_PERSONS:
                Assert.assertEquals(responseResult.getStatus().intValue(), responseOK);
                Assert.assertEquals(responseResult.getMsg(), "SUCCESS");
                Assert.assertTrue(Double.parseDouble(responseResult.getAccuracy()) > minimumAccuracy);
                Assert.assertEquals(responseResult.getRecognition().intValue(), imageRecognized);
                Assert.assertFalse(responseResult.getIsSpoof());
                Assert.assertEquals(responseResult.getResultId(), successResultId);

                break;

            case SECONDARY_PERSON_BLUR_NO_FACES_FOUND:
            case NO_BLUR_NO_FACES_FOUND:
            case BLUR_BACKGROUND_NO_FACES_FOUND:
            case SECONDARY_PERSON_BLUR_BLOCKED_CAMERA:
            case BLUR_BACKGROUND_BLOCKED_CAMERA:
            case NO_BLUR_BLOCKED_CAMERA:
                Assert.assertEquals(responseResult.getStatus().intValue(), responseOK);
                Assert.assertEquals(responseResult.getMsg(), "ERROR");
                Assert.assertEquals(Double.parseDouble(responseResult.getAccuracy()), 0.0);
                Assert.assertEquals(responseResult.getRecognition().intValue(), imageNotRecognized);
                Assert.assertFalse(responseResult.getIsSpoof());
                Assert.assertEquals(responseResult.getResultId(), noFacesFoundOnStartUpResultId);

                break;

            case SECONDARY_PERSON_BLUR_OTHER_PERSON:
            case BLUR_BACKGROUND_OTHER_PERSON:
            case NO_BLUR_OTHER_PERSON:
                Assert.assertEquals(responseResult.getStatus().intValue(), responseOK);
                Assert.assertEquals(responseResult.getMsg(), "SUCCESS");
                Assert.assertTrue(Double.parseDouble(responseResult.getAccuracy()) < minimumAccuracy);
                Assert.assertEquals(responseResult.getRecognition().intValue(), imageNotRecognized);
                Assert.assertFalse(responseResult.getIsSpoof());
                Assert.assertEquals(responseResult.getResultId(), faceAuthMode);
                break;

            case NO_BLUR_SPOOF:
            case BLUR_BACKGROUND_SPOOF:
            case SECONDARY_PERSON_BLUR_SPOOF:
                Assert.assertEquals(responseResult.getStatus().intValue(), responseOK);
                Assert.assertEquals(responseResult.getMsg(), "SUCCESS");
                Assert.assertTrue(Double.parseDouble(responseResult.getAccuracy()) > minimumAccuracy);
                Assert.assertEquals(responseResult.getRecognition().intValue(), imageNotRecognized);
                Assert.assertTrue(responseResult.getIsSpoof());
                Assert.assertEquals(responseResult.getResultId(), unknownPersonResultId);
                break;
        }
    }

    public void validateResponseForNewAuthenticationResumeScenariosWithBlurType(
            ConcentrixBaseTest.AuthenticationScenariosWithBlurType testDescription, ResponseResult responseResult, Integer faceAuthMode) {

        Assert.assertNotNull(responseResult.getTime());
        Assert.assertEquals(responseResult.getFaceAuthMode(), faceAuthMode);

        switch (testDescription) {

            case NO_BLUR_SUCCESS:
            case NO_BLUR_CELL_PHONE:
            case NO_BLUR_MULTIPLE_PERSONS:
            case SECONDARY_PERSON_BLUR_SUCCESS:
            case SECONDARY_PERSON_BLUR_CELL_PHONE:
            case SECONDARY_PERSON_BLUR_MULTIPLE_PERSONS:
            case BLUR_BACKGROUND_SUCCESS:
            case BLUR_BACKGROUND_CELL_PHONE:
            case BLUR_BACKGROUND_MULTIPLE_PERSONS:
                Assert.assertEquals(responseResult.getStatus().intValue(), responseOK);
                Assert.assertEquals(responseResult.getMsg(), "SUCCESS");
                Assert.assertTrue(Double.parseDouble(responseResult.getAccuracy()) > minimumAccuracy);
                Assert.assertEquals(responseResult.getRecognition().intValue(), imageRecognized);
                Assert.assertFalse(responseResult.getIsSpoof());
                Assert.assertEquals(responseResult.getResultId(), successResultId);
                break;

            case NO_BLUR_NO_FACES_FOUND:
            case NO_BLUR_BLOCKED_CAMERA:
            case SECONDARY_PERSON_BLUR_NO_FACES_FOUND:
            case SECONDARY_PERSON_BLUR_BLOCKED_CAMERA:
            case BLUR_BACKGROUND_NO_FACES_FOUND:
            case BLUR_BACKGROUND_BLOCKED_CAMERA:
                Assert.assertEquals(responseResult.getStatus().intValue(), responseOK);
                Assert.assertEquals(responseResult.getMsg(), "ERROR");
                Assert.assertEquals(Double.parseDouble(responseResult.getAccuracy()), 0.0);
                Assert.assertEquals(responseResult.getRecognition().intValue(), imageNotRecognized);
                Assert.assertFalse(responseResult.getIsSpoof());
                Assert.assertEquals(responseResult.getResultId(), RESULT_ID_WITH_NO_FACE_FOUND);

                break;

            case NO_BLUR_OTHER_PERSON:
            case SECONDARY_PERSON_BLUR_OTHER_PERSON:
            case BLUR_BACKGROUND_OTHER_PERSON:
                Assert.assertEquals(responseResult.getStatus().intValue(), responseOK);
                Assert.assertEquals(responseResult.getMsg(), "SUCCESS");
                Assert.assertTrue(Double.parseDouble(responseResult.getAccuracy()) < minimumAccuracy);
                Assert.assertEquals(responseResult.getRecognition().intValue(), imageNotRecognized);
                Assert.assertFalse(responseResult.getIsSpoof());
                Assert.assertEquals(responseResult.getResultId(), faceAuthMode);
                break;

            case NO_BLUR_SPOOF:
            case SECONDARY_PERSON_BLUR_SPOOF:
            case BLUR_BACKGROUND_SPOOF:
                Assert.assertEquals(responseResult.getStatus().intValue(), responseOK);
                Assert.assertEquals(responseResult.getMsg(), "SUCCESS");
                Assert.assertTrue(Double.parseDouble(responseResult.getAccuracy()) > minimumAccuracy);
                Assert.assertEquals(responseResult.getRecognition().intValue(), imageNotRecognized);
                Assert.assertTrue(responseResult.getIsSpoof());
                Assert.assertEquals(responseResult.getResultId(), unknownPersonResultId);
                break;
        }
    }

    public void validateResponseForNewAuthenticationSessionScenariosWithBlurType(
            ConcentrixBaseTest.AuthenticationScenariosWithBlurType testDescription, ResponseResult responseResult, Integer faceAuthMode) {

        Assert.assertNotNull(responseResult.getTime());
        Assert.assertEquals(responseResult.getFaceAuthMode(), faceAuthMode);

        switch (testDescription) {

            case NO_BLUR_SUCCESS:
            case NO_BLUR_CELL_PHONE:
            case NO_BLUR_MULTIPLE_PERSONS:
            case SECONDARY_PERSON_BLUR_SUCCESS:
            case SECONDARY_PERSON_BLUR_CELL_PHONE:
            case SECONDARY_PERSON_BLUR_MULTIPLE_PERSONS:
            case BLUR_BACKGROUND_SUCCESS:
            case BLUR_BACKGROUND_CELL_PHONE:
            case BLUR_BACKGROUND_MULTIPLE_PERSONS:
                Assert.assertEquals(responseResult.getStatus().intValue(), responseOK);
                Assert.assertEquals(responseResult.getMsg(), "SUCCESS");
                Assert.assertTrue(Double.parseDouble(responseResult.getAccuracy()) > minimumAccuracy);
                Assert.assertEquals(responseResult.getRecognition().intValue(), imageRecognized);
                Assert.assertFalse(responseResult.getIsSpoof());
                Assert.assertEquals(responseResult.getResultId(), successResultId);
                break;

            case NO_BLUR_NO_FACES_FOUND:
            case NO_BLUR_BLOCKED_CAMERA:
            case SECONDARY_PERSON_BLUR_NO_FACES_FOUND:
            case SECONDARY_PERSON_BLUR_BLOCKED_CAMERA:
            case BLUR_BACKGROUND_NO_FACES_FOUND:
            case BLUR_BACKGROUND_BLOCKED_CAMERA:
                Assert.assertEquals(responseResult.getStatus().intValue(), responseOK);
                Assert.assertEquals(responseResult.getMsg(), "ERROR");
                Assert.assertEquals(Double.parseDouble(responseResult.getAccuracy()), 0.0);
                Assert.assertEquals(responseResult.getRecognition().intValue(), imageNotRecognized);
                Assert.assertFalse(responseResult.getIsSpoof());
                Assert.assertEquals(responseResult.getResultId(), faceAuthMode);
                break;

            case NO_BLUR_OTHER_PERSON:
            case SECONDARY_PERSON_BLUR_OTHER_PERSON:
            case BLUR_BACKGROUND_OTHER_PERSON:
                Assert.assertEquals(responseResult.getStatus().intValue(), responseOK);
                Assert.assertEquals(responseResult.getMsg(), "SUCCESS");
                Assert.assertTrue(Double.parseDouble(responseResult.getAccuracy()) < minimumAccuracy);
                Assert.assertEquals(responseResult.getRecognition().intValue(), imageNotRecognized);
                Assert.assertFalse(responseResult.getIsSpoof());
                Assert.assertEquals(responseResult.getResultId(), faceAuthMode);
                break;

            case NO_BLUR_SPOOF:
            case SECONDARY_PERSON_BLUR_SPOOF:
            case BLUR_BACKGROUND_SPOOF:
                Assert.assertEquals(responseResult.getStatus().intValue(), responseOK);
                Assert.assertEquals(responseResult.getMsg(), "SUCCESS");
                Assert.assertTrue(Double.parseDouble(responseResult.getAccuracy()) > minimumAccuracy);
                Assert.assertEquals(responseResult.getRecognition().intValue(), imageNotRecognized);
                Assert.assertTrue(responseResult.getIsSpoof());
                Assert.assertEquals(responseResult.getResultId(), unknownPersonResultId);
                break;
        }
    }
}
