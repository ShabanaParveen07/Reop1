package com.concentrix.suites.EndPoint.StreamingAgentErrorLog.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.BaseTests.AdAuthenticateTest;
import com.concentrix.BaseTests.ConcentrixBaseTest;
import com.concentrix.BaseValidations.EndpointBaseValidations;
import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.helper.DBConnectionHelper;
import com.concentrix.automation.helper.DateHelper;
import com.concentrix.automation.helper.streaming.StreamingApiHelper;
import com.concentrix.automation.service.streaming.pojo.request.StreamingAgentErrorLogRequest;
import com.concentrix.listeners.RetryAnalyzer;
import com.concentrix.suites.EndPoint.StreamingAgentErrorLog.validations.AddStreamingAgentErrorLogDBValidations;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.sql.ResultSet;

import static com.concentrix.BaseTests.ConcentrixBaseTest.AgentErrorLogScenarios.*;

public class AddStreamingAgentErrorLogTests extends ConcentrixBaseTest {

  StreamingApiHelper streamingApiHelper;

  String envName;

  ResultSet rs;

  private DBConnectionHelper dbConnectionHelper;

  String AGENT_ERROR_LOG_QUERY;

  EndpointBaseValidations baseValidations;

  AddStreamingAgentErrorLogDBValidations addStreamingAgentErrorLogDBValidations;

  @BeforeClass(alwaysRun = true)
  public void beforeClass() {
    streamingApiHelper = new StreamingApiHelper();
  }

  @BeforeMethod(alwaysRun = true)
  public void beforeMethod() {
    dbConnectionHelper = DBConnectionHelper.getInstance();
    baseValidations = new EndpointBaseValidations();
    addStreamingAgentErrorLogDBValidations = new AddStreamingAgentErrorLogDBValidations();
    envName = System.getProperty("env");
    if (envName == null)
      envName = "qa";
    AGENT_ERROR_LOG_QUERY = "SELECT * from fb_enrollment_" + envName + ".StreamingAgentErrorLog order by LogTimeStamp desc";
  }

  @XrayTest(key = "ORN-6815", summary = "TC_Endpoint_Streaming_Error_Log_NetworkIssue", description = "Send A streaming Error occurrence with error Type as Network Issue", labels = "E2E")
  @Test(description = "Send A streaming Error occurrence with error Type as Network Issue", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Streaming_Error_Log_NetworkIssue() throws InterruptedException {
    StreamingAgentErrorLogRequest streamingAgentErrorLogRequest = StreamingAgentErrorLogRequest.builder().
        logTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).
        agentSSOId(ConfigurationFileHelper.getInstance().getSSOId()).
        errorType(NETWORK_ISSUE.getErrorType()).
        errorMessage(NETWORK_ISSUE.getErrorMessage()).build();
    baseValidations.assertStandardResponse(streamingApiHelper.addStreamingAgentErrorLog(streamingAgentErrorLogRequest));
    Thread.sleep(2000);
    rs = dbConnectionHelper.executeQuery(AGENT_ERROR_LOG_QUERY);
    addStreamingAgentErrorLogDBValidations.validateAddStreamingAgentErrorLogDBEntry(streamingAgentErrorLogRequest, rs);
  }

  @XrayTest(key = "ORN-6818", summary = "TC_Endpoint_Streaming_Error_Log_DataIssue", description = "Send A streaming Error occurrence with error Type as Data Issue", labels = "E2E")
  @Test(description = "Send A streaming Error occurrence with error Type as Data Issue", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Streaming_Error_Log_DataIssue() throws InterruptedException {
    StreamingAgentErrorLogRequest streamingAgentErrorLogRequest = StreamingAgentErrorLogRequest.builder().
        logTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).
        agentSSOId(ConfigurationFileHelper.getInstance().getSSOId()).
        errorType(DATA_ISSUE.getErrorType()).
        errorMessage(DATA_ISSUE.getErrorMessage()).build();
    baseValidations.assertStandardResponse(streamingApiHelper.addStreamingAgentErrorLog(streamingAgentErrorLogRequest));
    Thread.sleep(2000);
    rs = dbConnectionHelper.executeQuery(AGENT_ERROR_LOG_QUERY);
    addStreamingAgentErrorLogDBValidations.validateAddStreamingAgentErrorLogDBEntry(streamingAgentErrorLogRequest, rs);
  }

  @XrayTest(key = "ORN-6819", summary = "TC_Endpoint_Streaming_Error_Log_AppCrash", description = "Send A streaming Error occurrence with error Type as App Crash", labels = "E2E")
  @Test(description = "Send A streaming Error occurrence with error Type as App Crash", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Streaming_Error_Log_AppCrash() throws InterruptedException {
    StreamingAgentErrorLogRequest streamingAgentErrorLogRequest = StreamingAgentErrorLogRequest.builder().
        logTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).
        agentSSOId(ConfigurationFileHelper.getInstance().getSSOId()).
        errorType(APP_CRASH.getErrorType()).
        errorMessage(APP_CRASH.getErrorMessage()).build();
    baseValidations.assertStandardResponse(streamingApiHelper.addStreamingAgentErrorLog(streamingAgentErrorLogRequest));
    Thread.sleep(2000);
    rs = dbConnectionHelper.executeQuery(AGENT_ERROR_LOG_QUERY);
    addStreamingAgentErrorLogDBValidations.validateAddStreamingAgentErrorLogDBEntry(streamingAgentErrorLogRequest, rs);
  }

  @XrayTest(key = "ORN-6820", summary = "TC_Endpoint_Streaming_Error_Log_AccessBlocked", description = "Send A streaming Error occurrence with error Type as Access Blocked", labels = "E2E")
  @Test(description = "Send A streaming Error occurrence with error Type as Access Blocked", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Streaming_Error_Log_AccessBlocked() throws InterruptedException {
    StreamingAgentErrorLogRequest streamingAgentErrorLogRequest = StreamingAgentErrorLogRequest.builder().
        logTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).
        agentSSOId(ConfigurationFileHelper.getInstance().getSSOId()).
        errorType(ACCESS_BLOCKED.getErrorType()).
        errorMessage(ACCESS_BLOCKED.getErrorMessage()).build();
    baseValidations.assertStandardResponse(streamingApiHelper.addStreamingAgentErrorLog(streamingAgentErrorLogRequest));
    Thread.sleep(2000);
    rs = dbConnectionHelper.executeQuery(AGENT_ERROR_LOG_QUERY);
    addStreamingAgentErrorLogDBValidations.validateAddStreamingAgentErrorLogDBEntry(streamingAgentErrorLogRequest, rs);
  }

  @XrayTest(key = "ORN-6821", summary = "TC_Endpoint_Streaming_Error_Log_CameraError", description = "Send A streaming Error occurrence with error Type as Camera Error", labels = "E2E")
  @Test(description = "Send A streaming Error occurrence with error Type as Camera Error", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Streaming_Error_Log_CameraError() throws InterruptedException {
    StreamingAgentErrorLogRequest streamingAgentErrorLogRequest = StreamingAgentErrorLogRequest.builder().
        logTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).
        agentSSOId(ConfigurationFileHelper.getInstance().getSSOId()).
        errorType(CAMERA_ERROR.getErrorType()).
        errorMessage(CAMERA_ERROR.getErrorMessage()).build();
    baseValidations.assertStandardResponse(streamingApiHelper.addStreamingAgentErrorLog(streamingAgentErrorLogRequest));
    Thread.sleep(2000);
    rs = dbConnectionHelper.executeQuery(AGENT_ERROR_LOG_QUERY);
    addStreamingAgentErrorLogDBValidations.validateAddStreamingAgentErrorLogDBEntry(streamingAgentErrorLogRequest, rs);
  }

  @XrayTest(key = "ORN-6822", summary = "TC_Endpoint_Streaming_Error_Log_USBCamera", description = "Send A streaming Error occurrence with error Type as USB Camera", labels = "E2E")
  @Test(description = "Send A streaming Error occurrence with error Type as USB Camera", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Streaming_Error_Log_USBCamera() throws InterruptedException {
    StreamingAgentErrorLogRequest streamingAgentErrorLogRequest = StreamingAgentErrorLogRequest.builder().
        logTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).
        agentSSOId(ConfigurationFileHelper.getInstance().getSSOId()).
        errorType(USB_CAMERA.getErrorType()).
        errorMessage(USB_CAMERA.getErrorMessage()).build();
    baseValidations.assertStandardResponse(streamingApiHelper.addStreamingAgentErrorLog(streamingAgentErrorLogRequest));
    Thread.sleep(2000);
    rs = dbConnectionHelper.executeQuery(AGENT_ERROR_LOG_QUERY);
    addStreamingAgentErrorLogDBValidations.validateAddStreamingAgentErrorLogDBEntry(streamingAgentErrorLogRequest, rs);
  }

  @XrayTest(key = "ORN-12628", summary = "TC_Endpoint_AddStreaming_Agent_Log_AdAuthentication", description = "Automate AddStreamingAgentLogAPI with ADAuthentication", labels = "E2E")
  @Test(description = "Automate AddStreamingAgentLogAPI with ADAuthentication", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_AddStreaming_Agent_Log_AdAuthentication() throws InterruptedException {
    StreamingAgentErrorLogRequest streamingAgentErrorLogRequest = StreamingAgentErrorLogRequest.builder().
        logTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).
        agentSSOId(ConfigurationFileHelper.getInstance().getSSOId()).
        errorType(USB_CAMERA.getErrorType()).
        errorMessage(USB_CAMERA.getErrorMessage()).build();
    String adToken = AdAuthenticateTest.getAuthToken();
    baseValidations.assertStandardResponse(streamingApiHelper.addStreamingAgentErrorLogWithAdAuthentication(streamingAgentErrorLogRequest, adToken));
    Thread.sleep(2000);
    rs = dbConnectionHelper.executeQuery(AGENT_ERROR_LOG_QUERY);
    addStreamingAgentErrorLogDBValidations.validateAddStreamingAgentErrorLogDBEntry(streamingAgentErrorLogRequest, rs);
  }
}