package com.concentrix.suites.EndPoint.Authentication.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.BaseTests.ConcentrixBaseTest;
import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.service.streaming.pojo.response.GetLastImageProcessedStatusResponse;
import com.concentrix.listeners.RetryAnalyzer;
import com.concentrix.suites.EndPoint.Authentication.validations.AuthenticationValidations;
import io.restassured.response.Response;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.util.HashMap;

import static com.concentrix.automation.service.streaming.constants.EndPointConstants.*;

@Listeners({ app.getxray.xray.testng.listeners.XrayListener.class })
public class AuthenticationTests extends ConcentrixBaseTest {

    String imageData ;


    Response response;

    AuthenticationValidations authenticationValidations;

    GetLastImageProcessedStatusResponse getLastImageProcessedStatusResponse;

    @BeforeMethod
    public void postBaseLineImage() throws InterruptedException {

        authenticationValidations = new AuthenticationValidations();
        postBaseLineImageToStreaming();
    }

    @XrayTest(key = "ORN-3941", summary = "TC_Endpoint_Authentication_Startup_NoBlur_Success", description = "Authenticate to Streaming with Valid Person and Blur Type as No Blur", labels = "E2E")
    @Test(description = "Authenticate to Streaming with Valid Person and Blur Type as No Blur", retryAnalyzer = RetryAnalyzer.class)
	public void TC_Endpoint_Authentication_Startup_NoBlur_Success() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_STARTUP);
        additionalParams.put("BlurType", "NoBlur");

        // Post a BaseLine Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(BASE_LINE_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationScenariosWithBlurType(
                AuthenticationScenariosWithBlurType.NO_BLUR_SUCCESS, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-4061", summary = "TC_Endpoint_Authentication_Startup_NoBlur_Cell_Phone", description = "Authenticate to Streaming with Valid Person with Cell Phone and Blur Type as No Blur", labels = "E2E")
    @Test(description = "Authenticate to Streaming with Valid Person with Cell Phone and Blur Type as No Blur", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Startup_NoBlur_Cell_Phone() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_STARTUP);
        additionalParams.put("BlurType", "NoBlur");

        // Post a BaseLine Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(CELL_PHONE_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationScenariosWithBlurType(
                AuthenticationScenariosWithBlurType.NO_BLUR_CELL_PHONE, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-4062", summary = "TC_Endpoint_Authentication_Startup_NoBlur_Multiple_Persons", description = "Authenticate to Streaming with Multiple Persons and Blur Type as No Blur", labels = "E2E")
    @Test(description = "Authenticate to Streaming with Multiple Persons and Blur Type as No Blur", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Startup_NoBlur_Multiple_Persons() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_STARTUP);
        additionalParams.put("BlurType", "NoBlur");

        // Post a BaseLine Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(MULTIPLE_PERSONS_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationScenariosWithBlurType(
                AuthenticationScenariosWithBlurType.NO_BLUR_CELL_PHONE, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-4063", summary = "TC_Endpoint_Authentication_Startup_NoBlur_No_Faces_Found", description = "Authenticate to Streaming with No Faces and Blur Type as No Blur", labels = "E2E")
    @Test(description = "Authenticate to Streaming with No Faces and Blur Type as No Blur", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Startup_NoBlur_No_Faces_Found() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_STARTUP);
        additionalParams.put("BlurType", "NoBlur");

        // Post a BaseLine Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(NO_FACES_FOUND_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationScenariosWithBlurType(
                AuthenticationScenariosWithBlurType.NO_BLUR_NO_FACES_FOUND, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-4064", summary = "TC_Endpoint_Authentication_Startup_NoBlur_Blocked_Camera", description = "Authenticate to Streaming with Blocked Camera and Blur Type as No Blur", labels = "E2E")
    @Test(description = "Authenticate to Streaming with Blocked Camera and Blur Type as No Blur", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Startup_NoBlur_Blocked_Camera() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_STARTUP);
        additionalParams.put("BlurType", "NoBlur");

        // Post a BaseLine Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(BLOCKED_CAMERA_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationScenariosWithBlurType(
                AuthenticationScenariosWithBlurType.NO_BLUR_BLOCKED_CAMERA, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-4065", summary = "TC_Endpoint_Authentication_Startup_NoBlur_Other_Person", description = "Authenticate to Streaming with Other Person and Blur Type as No Blur", labels = "E2E")
    @Test(description = "Authenticate to Streaming with Other Person and Blur Type as No Blur", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Startup_NoBlur_Other_Person() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_STARTUP);
        additionalParams.put("BlurType", "NoBlur");

        // Post a Other Person Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(OTHER_PERSON_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationScenariosWithBlurType(
                AuthenticationScenariosWithBlurType.NO_BLUR_OTHER_PERSON, response, getLastImageProcessedStatusResponse);

        // Post a Other Person Image again
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(OTHER_PERSON_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationScenariosWithBlurType(
                AuthenticationScenariosWithBlurType.NO_BLUR_OTHER_PERSON_CONSECUTIVELY, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-3942", summary = "TC_Endpoint_Authentication_Startup_Secondary_Person_Blur_Success", description = "Authenticate to Streaming with Valid Person and Blur Type as Secondary Person Blur", labels = "E2E")
    @Test(description = "Authenticate to Streaming with Valid Person and Blur Type as Secondary Person Blur", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Startup_Secondary_Person_Blur_Success() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_STARTUP);
        additionalParams.put("BlurType", "SecondaryPersonBlur");

        // Post a BaseLine Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(BASE_LINE_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationScenariosWithBlurType(
                AuthenticationScenariosWithBlurType.SECONDARY_PERSON_BLUR_SUCCESS, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-4070", summary = "TC_Endpoint_Authentication_Startup_Secondary_Person_Blur_No_Faces_Found", description = "Authenticate to Streaming with No Faces and Blur Type as Secondary Person Blur", labels = "E2E")
    @Test(description = "Authenticate to Streaming with No Faces and Blur Type as Secondary Person Blur", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Startup_Secondary_Person_Blur_No_Faces_Found() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_STARTUP);
        additionalParams.put("BlurType", "SecondaryPersonBlur");

        // Post a BaseLine Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(NO_FACES_FOUND_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationScenariosWithBlurType(
                AuthenticationScenariosWithBlurType.SECONDARY_PERSON_BLUR_NO_FACES_FOUND, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-4069", summary = "TC_Endpoint_Authentication_Startup_Secondary_Person_Blur_Multiple_Persons", description = "Authenticate to Streaming with Multiple Persons and Blur Type as Secondary Person Blur", labels = "E2E")
    @Test(description = "Authenticate to Streaming with Multiple Persons and Blur Type as Secondary Person Blur", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Startup_Secondary_Person_Blur_Multiple_Persons() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_STARTUP);
        additionalParams.put("BlurType", "SecondaryPersonBlur");

        // Post a BaseLine Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(MULTIPLE_PERSONS_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationScenariosWithBlurType(
                AuthenticationScenariosWithBlurType.SECONDARY_PERSON_BLUR_MULTIPLE_PERSONS, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-4071", summary = "TC_Endpoint_Authentication_Startup_Secondary_Person_Blur_Blocked_Camera", description = "Authenticate to Streaming with Blocked Camera and Blur Type as Secondary Person Blur", labels = "E2E")
    @Test(description = "Authenticate to Streaming with Blocked Camera and Blur Type as Secondary Person Blur", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Startup_Secondary_Person_Blur_Blocked_Camera() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_STARTUP);
        additionalParams.put("BlurType", "SecondaryPersonBlur");

        // Post a BaseLine Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(BLOCKED_CAMERA_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationScenariosWithBlurType(
                AuthenticationScenariosWithBlurType.SECONDARY_PERSON_BLUR_BLOCKED_CAMERA, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-4067", summary = "TC_Endpoint_Authentication_Startup_Secondary_Person_Blur_Cell_Phone", description = "Authenticate to Streaming with Cell Phone and Blur Type as Secondary Person Blur", labels = "E2E")
    @Test(description = "Authenticate to Streaming with Cell Phone and Blur Type as Secondary Person Blur", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Startup_Secondary_Person_Blur_Cell_Phone() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_STARTUP);
        additionalParams.put("BlurType", "SecondaryPersonBlur");

        // Post a BaseLine Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(CELL_PHONE_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationScenariosWithBlurType(
                AuthenticationScenariosWithBlurType.SECONDARY_PERSON_BLUR_CELL_PHONE, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-4072", summary = "TC_Endpoint_Authentication_Startup_Secondary_Person_Blur_Other_Person", description = "Authenticate to Streaming with Other Person and Blur Type as Secondary Person Blur", labels = "E2E")
    @Test(description = "Authenticate to Streaming with Other Person and Blur Type as Secondary Person Blur", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Startup_Secondary_Person_Blur_Other_Person() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_STARTUP);
        additionalParams.put("BlurType", "SecondaryPersonBlur");

        // Post a Other Person Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(OTHER_PERSON_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationScenariosWithBlurType(
                AuthenticationScenariosWithBlurType.SECONDARY_PERSON_BLUR_OTHER_PERSON, response, getLastImageProcessedStatusResponse);

        // Post a Other Person Image again
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(OTHER_PERSON_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationScenariosWithBlurType(
                AuthenticationScenariosWithBlurType.SECONDARY_PERSON_BLUR_OTHER_PERSON_CONSECUTIVELY, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-3943", summary = "TC_Endpoint_Authentication_Startup_Blur_Background_Success", description = "Authenticate to Streaming with Valid Person and Blur Type as Blur Background", labels = "E2E")
    @Test(description = "Authenticate to Streaming with Valid Person and Blur Type as Blur Background", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Startup_Blur_Background_Success() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_STARTUP);
        additionalParams.put("BlurType", "BlurBackground");

        // Post a BaseLine Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(BASE_LINE_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationScenariosWithBlurType(
                AuthenticationScenariosWithBlurType.BLUR_BACKGROUND_SUCCESS, response, getLastImageProcessedStatusResponse);
    }
    
    @XrayTest(key = "ORN-4199", summary = "TC_Endpoint_Authentication_Startup_Blur_Background_Cell_Phone", description = "Authenticate to Streaming with Cell Phone and Blur Type as Blur Background", labels = "E2E")
    @Test(description = "Authenticate to Streaming with Cell Phone and Blur Type as Blur Background", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Startup_Blur_Background_Cell_Phone() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_STARTUP);
        additionalParams.put("BlurType", "BlurBackground");

        // Post a Cell Phone Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(CELL_PHONE_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationScenariosWithBlurType(
                AuthenticationScenariosWithBlurType.BLUR_BACKGROUND_CELL_PHONE, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-4200", summary = "TC_Endpoint_Authentication_Startup_Blur_Background_Multiple_Persons", description = "Authenticate to Streaming with Multiple Persons and Blur Type as Blur Background", labels = "E2E")
    @Test(description = "Authenticate to Streaming with Multiple Persons and Blur Type as Blur Background", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Startup_Blur_Background_Multiple_Persons() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_STARTUP);
        additionalParams.put("BlurType", "BlurBackground");

        // Post a Multiple Persons Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(MULTIPLE_PERSONS_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationScenariosWithBlurType(
                AuthenticationScenariosWithBlurType.BLUR_BACKGROUND_MULTIPLE_PERSONS, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-4201", summary = "TC_Endpoint_Authentication_Startup_Blur_Background_No_Faces_Found", description = "Authenticate to Streaming with No Faces and Blur Type as Blur Background", labels = "E2E")
    @Test(description = "Authenticate to Streaming with No Faces and Blur Type as Blur Background", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Startup_Blur_Background_No_Faces_Found() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_STARTUP);
        additionalParams.put("BlurType", "BlurBackground");

        // Post a Image with No Faces
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(NO_FACES_FOUND_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationScenariosWithBlurType(
                AuthenticationScenariosWithBlurType.BLUR_BACKGROUND_NO_FACES_FOUND, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-4202", summary = "TC_Endpoint_Authentication_Startup_Blur_Background_Blocked_Camera", description = "Authenticate to Streaming with Blocked Camera and Blur Type as Blur Background", labels = "E2E")
    @Test(description = "Authenticate to Streaming with Blocked Camera and Blur Type as Blur Background", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Startup_Blur_Background_Blocked_Camera() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_STARTUP);
        additionalParams.put("BlurType", "BlurBackground");

        // Post a Image with Blocked Camera
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(BLOCKED_CAMERA_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationScenariosWithBlurType(
                AuthenticationScenariosWithBlurType.BLUR_BACKGROUND_BLOCKED_CAMERA, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-4203", summary = "TC_Endpoint_Authentication_Startup_Blur_Background_Other_Person", description = "Authenticate to Streaming with Other Person and Blur Type as Blur Background", labels = "E2E")
    @Test(description = "Authenticate to Streaming with Other Person and Blur Type as Blur Background", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_Authentication_Startup_Blur_Background_Other_Person() throws InterruptedException {

        //Customise the request with Additional Parameters
        HashMap<Object, Object> additionalParams = new HashMap<>();
        additionalParams.put("FaceAuthMode", FACE_AUTH_MODE_STARTUP);
        additionalParams.put("BlurType", "BlurBackground");

        // Post a Other Person Image
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(OTHER_PERSON_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationScenariosWithBlurType(
                AuthenticationScenariosWithBlurType.BLUR_BACKGROUND_OTHER_PERSON, response, getLastImageProcessedStatusResponse);

        // Post a Other Person Image again
        imageData = sendImageToStreamingAndReturnImageDataWithAdditionalParameters(OTHER_PERSON_IMAGE, additionalParams);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        authenticationValidations.validateResponseForAuthenticationScenariosWithBlurType(
                AuthenticationScenariosWithBlurType.BLUR_BACKGROUND_OTHER_PERSON_CONSECUTIVELY, response, getLastImageProcessedStatusResponse);
    }

    
}


