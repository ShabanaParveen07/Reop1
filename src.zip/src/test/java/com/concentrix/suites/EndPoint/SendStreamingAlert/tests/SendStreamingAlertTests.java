package com.concentrix.suites.EndPoint.SendStreamingAlert.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.BaseTests.ConcentrixBaseTest;
import com.concentrix.BaseValidations.EndpointBaseValidations;
import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.helper.DateHelper;
import com.concentrix.automation.helper.streaming.StreamingApiHelper;
import com.concentrix.automation.service.streaming.pojo.request.ClientEventData;
import com.concentrix.automation.service.streaming.pojo.request.SendStreamingAlertRequest;
import com.concentrix.listeners.RetryAnalyzer;
import lombok.extern.log4j.Log4j;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

@Log4j
public class SendStreamingAlertTests extends ConcentrixBaseTest {

  StreamingApiHelper streamingApiHelper;

  EndpointBaseValidations baseValidations;


  @BeforeClass(alwaysRun = true)
  public void beforeClass() {
    streamingApiHelper = new StreamingApiHelper();
  }

  @BeforeMethod(alwaysRun = true)
  public void beforeMethod() {
    baseValidations = new EndpointBaseValidations();
  }

  @XrayTest(key = "ORN-6802", summary = "TC_Endpoint_Send_Streaming_Alert_Camera_Not_Attached", description = "Send Streaming alert for Camera Not Attached", labels = "E2E")
  @Test(description = "Send Streaming alert for Camera Not Attached", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Send_Streaming_Alert_Camera_Not_Attached() {
    ClientEventData clientEventData = ClientEventData.builder().ssoId(ConfigurationFileHelper.getInstance().getSSOId()).
        streamingAlertType("Camera Not Attached").
        streamingAppVersion(ConfigurationFileHelper.getInstance().getStreamingAppVersion()).
        clientTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).build();
    SendStreamingAlertRequest sendStreamingAlertRequest = SendStreamingAlertRequest.builder().data(clientEventData).
        clientInfo("Win" + ConfigurationFileHelper.getInstance().getStreamingAppVersion()).build();
    baseValidations.assertStandardResponse(streamingApiHelper.sendStreamingAlert(sendStreamingAlertRequest));
  }

  @XrayTest(key = "ORN-8818", summary = "TC_Endpoint_Send_Streaming_Alert_Camera_Not_Attached_With_Authentication", description = "Send Streaming alert for Camera Not Attached", labels = "E2E")
  @Test(description = "Send Streaming alert for Camera Not Attached with Authentication", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Send_Streaming_Alert_Camera_Not_Attached_with_Authentication() {
    ClientEventData clientEventData = ClientEventData.builder().ssoId(ConfigurationFileHelper.getInstance().getSSOId()).
        streamingAlertType("Camera Not Attached").
        streamingAppVersion(ConfigurationFileHelper.getInstance().getStreamingAppVersion()).
        clientTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).build();
    SendStreamingAlertRequest sendStreamingAlertRequest = SendStreamingAlertRequest.builder().data(clientEventData).
        clientInfo("Win" + ConfigurationFileHelper.getInstance().getStreamingAppVersion()).build();
    baseValidations.assertStandardResponse(streamingApiHelper.sendStreamingAlertWithAuthentication(sendStreamingAlertRequest, authToken));
  }

  @XrayTest(key = "ORN-6803", summary = "TC_Endpoint_Send_Streaming_Alert_Camera_Not_In_Use", description = "Send Streaming alert for Camera In Use", labels = "E2E")
  @Test(description = "Send Streaming alert for Camera In Use", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Send_Streaming_Alert_Camera_Not_In_Use() {
    ClientEventData clientEventData = ClientEventData.builder().ssoId(ConfigurationFileHelper.getInstance().getSSOId()).
        streamingAlertType("Camera In Use").
        streamingAppVersion(ConfigurationFileHelper.getInstance().getStreamingAppVersion()).
        clientTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).build();
    SendStreamingAlertRequest sendStreamingAlertRequest = SendStreamingAlertRequest.builder().data(clientEventData).
        clientInfo("Win" + ConfigurationFileHelper.getInstance().getStreamingAppVersion()).build();
    baseValidations.assertStandardResponse(streamingApiHelper.sendStreamingAlert(sendStreamingAlertRequest));
  }

  @XrayTest(key = "ORN-8819", summary = "TC_Endpoint_Send_Streaming_Alert_Camera_Not_In_Use_With_Authentication", description = "Send Streaming alert for Camera In Use", labels = "E2E")
  @Test(description = "Send Streaming alert for Camera In Use", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Send_Streaming_Alert_Camera_Not_In_Use_with_Authentication() {
    ClientEventData clientEventData = ClientEventData.builder().ssoId(ConfigurationFileHelper.getInstance().getSSOId()).
        streamingAlertType("Camera In Use").
        streamingAppVersion(ConfigurationFileHelper.getInstance().getStreamingAppVersion()).
        clientTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).build();
    SendStreamingAlertRequest sendStreamingAlertRequest = SendStreamingAlertRequest.builder().data(clientEventData).
        clientInfo("Win" + ConfigurationFileHelper.getInstance().getStreamingAppVersion()).build();
    baseValidations.assertStandardResponse(streamingApiHelper.sendStreamingAlertWithAuthentication(sendStreamingAlertRequest, authToken));
  }
  @XrayTest(key = "ORN-12467", summary = "TC_Endpoint_Send_Streaming_Alert_AppQuit_With_Authentication", description = "Send Streaming alert for App Quit", labels = "E2E")
  @Test(description = "Send Streaming alert for App Quit", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Send_Streaming_Alert_App_Quit_with_Authentication() {
    ClientEventData clientEventData = ClientEventData.builder().ssoId(ConfigurationFileHelper.getInstance().getSSOId()).
            streamingAlertType("AppQuit").
            streamingAppVersion(ConfigurationFileHelper.getInstance().getStreamingAppVersion()).
            clientTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).build();
    SendStreamingAlertRequest sendStreamingAlertRequest = SendStreamingAlertRequest.builder().data(clientEventData).
            clientInfo("Win" + ConfigurationFileHelper.getInstance().getStreamingAppVersion()).build();
    baseValidations.assertStandardResponse(streamingApiHelper.sendStreamingAlertWithAuthentication(sendStreamingAlertRequest, authToken));
  }
  @XrayTest(key = "ORN-12468", summary = "TC_Endpoint_Send_Streaming_Alert_AppQuit", description = "Send Streaming alert for App Quit", labels = "E2E")
  @Test(description = "Send Streaming alert for App Quit", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_Send_Streaming_Alert_AppQuit() {
    ClientEventData clientEventData = ClientEventData.builder().ssoId(ConfigurationFileHelper.getInstance().getSSOId()).
            streamingAlertType("AppQuit").
            streamingAppVersion(ConfigurationFileHelper.getInstance().getStreamingAppVersion()).
            clientTimeStamp(DateHelper.convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss")).build();
    SendStreamingAlertRequest sendStreamingAlertRequest = SendStreamingAlertRequest.builder().data(clientEventData).
            clientInfo("Win" + ConfigurationFileHelper.getInstance().getStreamingAppVersion()).build();
    baseValidations.assertStandardResponse(streamingApiHelper.sendStreamingAlert(sendStreamingAlertRequest));
  }
}
