package com.concentrix.suites.EndPoint.OTPCode.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.BaseValidations.EndpointBaseValidations;
import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.helper.streaming.StreamingApiHelper;
import com.concentrix.automation.service.streaming.pojo.response.StandardResponse;
import com.concentrix.listeners.RetryAnalyzer;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Random;

public class SupervisorOTPTests {

    StreamingApiHelper streamingApiHelper;

    StandardResponse responseBody;

    Response response;

    String otp;

    EndpointBaseValidations endpointBaseValidations;

    @BeforeClass(alwaysRun = true)
    public void beforeClass() {
        streamingApiHelper = new StreamingApiHelper();
        endpointBaseValidations = new EndpointBaseValidations();
        Random rand = new Random();
        otp = String.valueOf(rand.nextInt(999999));
    }

    @XrayTest(key = "ORN-7406", summary = "TC_Post_Supervisor_OTP_Valid_LanId", description = "Validate Response when Valid SSO ID is given", labels = "E2E")
    @Test(description = "Validate Response when Valid SSO ID is given", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Post_Supervisor_OTP_Valid_LanId() {
        response = streamingApiHelper.postSupervisorOTP(ConfigurationFileHelper.getInstance().getLanID(), otp, String.valueOf(5) );
        responseBody = response.as(StandardResponse.class);
        endpointBaseValidations.assertStandardResponse(response);
        Assert.assertNull(responseBody.getError());
    }

    @XrayTest(key = "ORN-7408", summary = "TC_Post_Supervisor_OTP_InValid_LanId", description = "Validate Response when InValid SSO ID is given", labels = "E2E")
    @Test(description = "Validate Response when InValid SSO ID is given", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Post_Supervisor_OTP_InValid_LanId() {
        response = streamingApiHelper.postSupervisorOTP(ConfigurationFileHelper.getInstance().getLanID()+"com", otp, String.valueOf(5) );
        responseBody = response.as(StandardResponse.class);
        Assert.assertNotNull(responseBody.getCorrelationId());
        Assert.assertFalse(responseBody.getSuccess());
        Assert.assertEquals(responseBody.getError(), "Send email failed");
    }
}
