package com.concentrix.suites.EndPoint.EmployeeSSOID;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.helper.streaming.StreamingApiHelper;
import com.concentrix.automation.service.streaming.pojo.response.GeneralResponse;
import com.concentrix.listeners.RetryAnalyzer;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class GetEmployeeSSOIDTests {

  StreamingApiHelper streamingApiHelper;

  GeneralResponse responseBody;

  Response response;

  @BeforeClass(alwaysRun = true)
  public void beforeClass() {
    streamingApiHelper = new StreamingApiHelper();
  }

  @XrayTest(key = "ORN-6501", summary = "TC_Get_Employee_SSO_ID_Valid_LanId", description = "Validate Response when Valid SSO ID is given", labels = "E2E")
  @Test(description = "Validate Response when Valid SSO ID is given", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Get_Employee_SSO_ID_Valid_LanId() {
    response = streamingApiHelper.getEmployeeSSOID(ConfigurationFileHelper.getInstance().getLanID());
    responseBody = response.as(GeneralResponse.class);
    Assert.assertEquals(responseBody.getResponseResult(), "SSO id for {empssoid} found.");
    Assert.assertEquals(responseBody.getResponseStatus(), "Success");
    Assert.assertEquals(responseBody.getData(), ConfigurationFileHelper.getInstance().getLanID());
    Assert.assertEquals(responseBody.getResponseResult1(), "SSOIdFound:SSO id for {empssoid} found.");
  }

  @XrayTest(key = "ORN-6502", summary = "TC_Get_Employee_SSO_ID_InValid_LanId", description = "Validate Response when InValid SSO ID is given", labels = "E2E")
  @Test(description = "Validate Response when InValid SSO ID is given", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Get_Employee_SSO_ID_InValid_LanId() {
    response = streamingApiHelper.getEmployeeSSOID(ConfigurationFileHelper.getInstance().getLanID()+".com");
    responseBody = response.as(GeneralResponse.class);
    Assert.assertEquals(responseBody.getResponseResult(), "SSO id for {domainlanid} NOT found.");
    Assert.assertEquals(responseBody.getResponseStatus(), "Fail");
    Assert.assertNull(responseBody.getData());
    Assert.assertEquals(responseBody.getResponseResult1(), "domainlanidNotFound:SSO id for {domainlanid} NOT found.");
  }

}
