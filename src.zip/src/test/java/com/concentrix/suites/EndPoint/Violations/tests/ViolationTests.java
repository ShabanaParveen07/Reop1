package com.concentrix.suites.EndPoint.Violations.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.BaseTests.ConcentrixBaseTest;
import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.helper.GCSHelper;
import com.concentrix.automation.service.streaming.pojo.response.GetLastImageProcessedStatusResponse;
import com.concentrix.listeners.RetryAnalyzer;
import com.concentrix.suites.EndPoint.Violations.validations.ViolationsValidations;
import io.restassured.response.Response;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import java.io.IOException;
import java.util.HashMap;

import static com.concentrix.automation.service.streaming.constants.EndPointConstants.*;

@Listeners({ app.getxray.xray.testng.listeners.XrayListener.class })
public class ViolationTests extends ConcentrixBaseTest {

    String imageData ;


    Response response;

    HashMap<Object, Object> faceStreamingRequestMap;


    ViolationsValidations violationsValidations;

    GetLastImageProcessedStatusResponse getLastImageProcessedStatusResponse;

    String objectKey;

    @BeforeMethod
    public void postBaseLineImage() throws InterruptedException {

        violationsValidations = new ViolationsValidations();
        postBaseLineImageToStreaming();
    }

    @XrayTest(key = "ORN-3638", summary = "TC_Endpoint_BlockedCameraViolation_Once", description = "Create a Blocked Camera Violation and and Assert the Response", labels = "E2E")
    @Test(description = "Create a Blocked Camera Violation and and Assert the Response", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_BlockedCameraViolation_Once() throws InterruptedException, IOException {

        objectKey = BLOCKED_CAMERA_IMAGE.getAbsolutePath().substring(BLOCKED_CAMERA_IMAGE.getAbsolutePath().indexOf("Endpoint"));
        GCSHelper.downloadObject(
                ConfigurationFileHelper.getInstance().getProjectId(),
                ConfigurationFileHelper.getInstance().getBucketName(),
                objectKey.replaceAll("\\\\", "/"),
                BLOCKED_CAMERA_IMAGE.getAbsolutePath());

        // Post Image with Blocked Camera
        imageData = sendImageToStreamingAndReturnImageData(BLOCKED_CAMERA_IMAGE);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        violationsValidations.validateResponseForViolations(
                CreateViolationScenarios.BLOCKED_CAMERA, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-3675", summary = "TC_EndPoint_CellPhoneViolation_Once", description = "Create a Cell Phone Violation once and and Assert the Response", labels = "E2E")
    @Test(description = "Create a Cell Phone Violation once and and Assert the Response", retryAnalyzer = RetryAnalyzer.class)
    public void TC_EndPoint_CellPhoneViolation_Once() throws InterruptedException, IOException {

        objectKey = CELL_PHONE_IMAGE.getAbsolutePath().substring(CELL_PHONE_IMAGE.getAbsolutePath().indexOf("Endpoint"));
        GCSHelper.downloadObject(
                ConfigurationFileHelper.getInstance().getProjectId(),
                ConfigurationFileHelper.getInstance().getBucketName(),
                objectKey.replaceAll("\\\\", "/"),
                CELL_PHONE_IMAGE.getAbsolutePath());

        // Post Image with a Cell Phone
        imageData = sendImageToStreamingAndReturnImageData(CELL_PHONE_IMAGE);


        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        violationsValidations.validateResponseForViolations(
                CreateViolationScenarios.CELL_PHONE_ONLY_ONCE, response, getLastImageProcessedStatusResponse);

    }

    @XrayTest(key = "ORN-3676", summary = "TC_EndPoint_CellPhoneViolation_Consecutively", description = "Create a Cell Phone Violation twice and and Assert the Response", labels = "E2E")
    @Test(description = "Create a Cell Phone Violation twice and and Assert the Response", retryAnalyzer = RetryAnalyzer.class)
    public void TC_EndPoint_CellPhoneViolation_Consecutively() throws InterruptedException, IOException {

        objectKey = CELL_PHONE_IMAGE.getAbsolutePath().substring(CELL_PHONE_IMAGE.getAbsolutePath().indexOf("Endpoint"));
        GCSHelper.downloadObject(
                ConfigurationFileHelper.getInstance().getProjectId(),
                ConfigurationFileHelper.getInstance().getBucketName(),
                objectKey.replaceAll("\\\\", "/"),
                CELL_PHONE_IMAGE.getAbsolutePath());

        // Post Image with Cell Phone For the First Time
        imageData = sendImageToStreamingAndReturnImageData(CELL_PHONE_IMAGE);

        // Post Image with Cell Phone For first time
        streamingApiHelper.postImageToStreaming(authToken, faceStreamingRequestMap);
        Thread.sleep(5000);
        // Get Status and Validate Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        violationsValidations.validateResponseForViolations(
                CreateViolationScenarios.CELL_PHONE_ONLY_ONCE, response, getLastImageProcessedStatusResponse);

        // Post Image with Cell Phone For the Second Time
        imageData = sendImageToStreamingAndReturnImageData(CELL_PHONE_IMAGE);

        // Get Status and Validate Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                        GetLastImageProcessedStatusResponse.class);
        violationsValidations.validateResponseForViolations(
                CreateViolationScenarios.CELL_PHONE_CONSECUTIVELY, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-3682", summary = "TC_EndPoint_NoFacesFoundViolation_Once", description = "Create a No Faces Found Violation and Assert the Response", labels = "E2E")
    @Test(description = "Create a No Faces Found Violation and Assert the Response", retryAnalyzer = RetryAnalyzer.class)
    public void TC_EndPoint_NoFacesFoundViolation_Once() throws InterruptedException, IOException {

        objectKey = NO_FACES_FOUND_IMAGE.getAbsolutePath().substring(NO_FACES_FOUND_IMAGE.getAbsolutePath().indexOf("Endpoint"));
        GCSHelper.downloadObject(
                ConfigurationFileHelper.getInstance().getProjectId(),
                ConfigurationFileHelper.getInstance().getBucketName(),
                objectKey.replaceAll("\\\\", "/"),
                NO_FACES_FOUND_IMAGE.getAbsolutePath());

        // Post Image with No Faces
        imageData = sendImageToStreamingAndReturnImageData(NO_FACES_FOUND_IMAGE);
        Thread.sleep(3000);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        violationsValidations.validateResponseForViolations(
                CreateViolationScenarios.NO_FACES_FOUND, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-3683", summary = "TC_EndPoint_NoFacesFoundViolation_Consecutively", description = "Create a No Faces Found Violation and Assert the Response", labels = "E2E")
    @Test(description = "Create a No Faces Found Violation and Assert the Response", retryAnalyzer = RetryAnalyzer.class)
    public void TC_EndPoint_NoFacesFoundViolation_Consecutivelyy() throws InterruptedException, IOException {

        objectKey = NO_FACES_FOUND_IMAGE.getAbsolutePath().substring(NO_FACES_FOUND_IMAGE.getAbsolutePath().indexOf("Endpoint"));
        GCSHelper.downloadObject(
                ConfigurationFileHelper.getInstance().getProjectId(),
                ConfigurationFileHelper.getInstance().getBucketName(),
                objectKey.replaceAll("\\\\", "/"),
                NO_FACES_FOUND_IMAGE.getAbsolutePath());

        // Post Image with No Faces For the First
        imageData = sendImageToStreamingAndReturnImageData(NO_FACES_FOUND_IMAGE);
        Thread.sleep(3000);


        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        violationsValidations.validateResponseForViolations(
                CreateViolationScenarios.NO_FACES_FOUND, response, getLastImageProcessedStatusResponse);


        // Post No Faces Image For 2nd time
        imageData = sendImageToStreamingAndReturnImageData(NO_FACES_FOUND_IMAGE);
        Thread.sleep(3000);

        //Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        System.out.println(response.getBody().asString());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        violationsValidations.validateResponseForViolations(
                CreateViolationScenarios.NO_FACES_FOUND_CONSECUTIVELY, response, getLastImageProcessedStatusResponse);

    }

    @XrayTest(key = "ORN-3684", summary = "TC_Endpoint_MultiplePersonViolation_Once", description = "Create a Multiple Faces Found Violation and Assert the Response", labels = "E2E")
    @Test(description = "Create a Multiple Faces Found Violation and Assert the Response", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_MultiplePersonViolation_Once() throws InterruptedException, IOException {

        objectKey = MULTIPLE_PERSONS_IMAGE.getAbsolutePath().substring(MULTIPLE_PERSONS_IMAGE.getAbsolutePath().indexOf("Endpoint"));
        GCSHelper.downloadObject(
                ConfigurationFileHelper.getInstance().getProjectId(),
                ConfigurationFileHelper.getInstance().getBucketName(),
                objectKey.replaceAll("\\\\", "/"),
                MULTIPLE_PERSONS_IMAGE.getAbsolutePath());

        // Post Image with No Faces
        imageData = sendImageToStreamingAndReturnImageData(MULTIPLE_PERSONS_IMAGE);
        Thread.sleep(3000);

        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        violationsValidations.validateResponseForViolations(
                CreateViolationScenarios.MULTIPLE_PERSONS, response, getLastImageProcessedStatusResponse);
    }

    @XrayTest(key = "ORN-3686", summary = "TC_Endpoint_MultiplePersonViolation_Consecutively", description = "Create a Multiple Faces Found Violation Consecutively and Assert the Response", labels = "E2E")
    @Test(description = "Create a Multiple Faces Found Violation Consecutively and Assert the Response", retryAnalyzer = RetryAnalyzer.class)
    public void TC_Endpoint_MultiplePersonViolation_Consecutively() throws InterruptedException, IOException {

        objectKey = MULTIPLE_PERSONS_IMAGE.getAbsolutePath().substring(MULTIPLE_PERSONS_IMAGE.getAbsolutePath().indexOf("Endpoint"));
        GCSHelper.downloadObject(
                ConfigurationFileHelper.getInstance().getProjectId(),
                ConfigurationFileHelper.getInstance().getBucketName(),
                objectKey.replaceAll("\\\\", "/"),
                MULTIPLE_PERSONS_IMAGE.getAbsolutePath());

        // Post Image with No Faces For the First
        imageData = sendImageToStreamingAndReturnImageData(MULTIPLE_PERSONS_IMAGE);
        Thread.sleep(3000);


        // Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        violationsValidations.validateResponseForViolations(
                CreateViolationScenarios.MULTIPLE_PERSONS, response, getLastImageProcessedStatusResponse);


        // Post No Faces Image For 2nd time
        imageData = sendImageToStreamingAndReturnImageData(MULTIPLE_PERSONS_IMAGE);
        Thread.sleep(3000);

        //Get Status and Validate the Response
        response = streamingApiHelper.getLastImageProcessedStatus(
                imageData, ConfigurationFileHelper.getInstance().getLanID());
        System.out.println(response.getBody().asString());
        getLastImageProcessedStatusResponse = response.getBody().as(
                GetLastImageProcessedStatusResponse.class);
        violationsValidations.validateResponseForViolations(
                CreateViolationScenarios.MULTIPLE_PERSONS_CONSECUTIVELY, response, getLastImageProcessedStatusResponse);

    }
}
