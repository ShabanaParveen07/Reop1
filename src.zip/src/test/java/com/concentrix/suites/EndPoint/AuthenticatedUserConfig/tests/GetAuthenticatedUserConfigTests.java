package com.concentrix.suites.EndPoint.AuthenticatedUserConfig.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.BaseTests.ConcentrixBaseTest;
import com.concentrix.BaseValidations.EndpointBaseValidations;
import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.helper.streaming.StreamingApiHelper;
import com.concentrix.automation.service.streaming.pojo.response.GeneralResponse;
import com.concentrix.automation.service.streaming.pojo.response.GetAuthenticatedUserConfigResponse;
import com.concentrix.automation.service.streaming.pojo.response.StandardResponse;
import com.concentrix.listeners.RetryAnalyzer;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class GetAuthenticatedUserConfigTests extends ConcentrixBaseTest {

  StreamingApiHelper streamingApiHelper;

  GetAuthenticatedUserConfigResponse responseBody;

  Response response;

  EndpointBaseValidations endpointBaseValidations;

  @BeforeClass(alwaysRun = true)
  public void beforeClass() {
    streamingApiHelper = new StreamingApiHelper();
    endpointBaseValidations = new EndpointBaseValidations();
  }

  @XrayTest(key = "ORN-7157", summary = "TC_Get_Authenticated_User_Config_Valid_LanId", description = "Validate Response when Valid SSO ID is given", labels = "E2E")
  @Test(description = "Validate Response when Valid SSO ID is given", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Get_Authenticated_User_Config_Valid_LanId() {
    response = streamingApiHelper.getAuthenticatedUserConfig(authToken, ConfigurationFileHelper.getInstance().getLanID());
    endpointBaseValidations.assertGetAuthenticatedUserConfigResponse(response);
    responseBody = response.as(GetAuthenticatedUserConfigResponse.class);
    Assert.assertNotNull(responseBody.getData().getGcpImageUploadConfig());
    Assert.assertNotNull(responseBody.getData().getAzureImageUploadConfig());
    Assert.assertNotNull(responseBody.getData().getStreamingClientApplicationSource());
    Assert.assertNotNull(responseBody.getData().getImageUploadCloudProvider());

  }

  @XrayTest(key = "ORN-7158", summary = "TC_Get_Authenticated_User_Config_InValid_LanId", description = "Validate Response when InValid SSO ID is given", labels = "E2E")
  @Test(description = "Validate Response when InValid SSO ID is given", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Get_Authenticated_User_Config_InValid_LanId() {
    response = streamingApiHelper.getAuthenticatedUserConfig(authToken, ConfigurationFileHelper.getInstance().getLanID() + "test");
    endpointBaseValidations.assertGetAuthenticatedUserConfigResponse(response);
    responseBody = response.as(GetAuthenticatedUserConfigResponse.class);
    Assert.assertNull(responseBody.getData());
  }
}
