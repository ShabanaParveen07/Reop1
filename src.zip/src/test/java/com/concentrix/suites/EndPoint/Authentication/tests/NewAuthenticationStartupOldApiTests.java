package com.concentrix.suites.EndPoint.Authentication.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.BaseTests.ConcentrixBaseTest;
import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.helper.GCSHelper;
import com.concentrix.automation.service.streaming.constants.EndPointConstants;
import com.concentrix.automation.service.streaming.pojo.response.ResponseResult;
import com.concentrix.listeners.RetryAnalyzer;
import com.concentrix.suites.EndPoint.Authentication.validations.AuthenticationValidations;
import lombok.extern.log4j.Log4j;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.IOException;

import static com.concentrix.automation.service.streaming.constants.EndPointConstants.*;

@Log4j
public class NewAuthenticationStartupOldApiTests extends ConcentrixBaseTest {

  ResponseResult responseResult;

  AuthenticationValidations authenticationValidations;

  private String filePath;

  public static String objectKey;


  @BeforeMethod(alwaysRun = true)
  public void postBaseLineImage() throws InterruptedException {

    authenticationValidations = new AuthenticationValidations();
    postBaseLineImageToStreaming();
  }


  @XrayTest(key = "ORN-4390", summary = "TC_Endpoint_NewAuthentication_Startup_NoBlur_Success", description = "Authenticate to Streaming with Valid Person and Blur Type as No Blur", labels = "E2E")
  @Test(groups = {"smoke"}, description = "Authenticate to Streaming with Valid Person and Blur Type as No Blur", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_NewAuthentication_Startup_NoBlur_Success() throws IOException {
    objectKey = BASE_LINE_IMAGE.getAbsolutePath().substring(BASE_LINE_IMAGE.getAbsolutePath().indexOf("Endpoint"));
    GCSHelper.downloadObject(
        ConfigurationFileHelper.getInstance().getProjectId(),
        ConfigurationFileHelper.getInstance().getBucketName(),
        objectKey.replaceAll("\\\\", "/"),
        BASE_LINE_IMAGE.getAbsolutePath());
    filePath = BASE_LINE_IMAGE.getAbsolutePath();
    responseResult = sendImageToFaceAuth(filePath, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "NoBlur");
    authenticationValidations.validateResponseForNewAuthenticationScenariosWithBlurType(AuthenticationScenariosWithBlurType.NO_BLUR_SUCCESS, responseResult, FACE_AUTH_MODE_STARTUP);

  }

  @XrayTest(key = "ORN-4392", summary = "TC_Endpoint_NewAuthentication_Startup_NoBlur_CellPhone", description = "Authenticate to Streaming with Valid Person and CellPhone and Blur Type as No Blur", labels = "E2E")
  @Test(description = "Authenticate to Streaming with Valid Person and Cell Phone and Blur Type as No Blur", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_NewAuthentication_Startup_NoBlur_CellPhone() throws IOException {
    objectKey = CELL_PHONE_IMAGE.getAbsolutePath().substring(CELL_PHONE_IMAGE.getAbsolutePath().indexOf("Endpoint"));
    GCSHelper.downloadObject(
        ConfigurationFileHelper.getInstance().getProjectId(),
        ConfigurationFileHelper.getInstance().getBucketName(),
        objectKey.replaceAll("\\\\", "/"),
        CELL_PHONE_IMAGE.getAbsolutePath());
    filePath = CELL_PHONE_IMAGE.getAbsolutePath();
    responseResult = sendImageToFaceAuth(filePath, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "NoBlur");
    authenticationValidations.validateResponseForNewAuthenticationScenariosWithBlurType(AuthenticationScenariosWithBlurType.NO_BLUR_CELL_PHONE, responseResult, FACE_AUTH_MODE_STARTUP);

  }

  @XrayTest(key = "ORN-4394", summary = "TC_Endpoint_NewAuthentication_Startup_NoBlur_MultiplePersons", description = "Authenticate to Streaming with Multiple Persons Blur Type as No Blur", labels = "E2E")
  @Test(description = "Authenticate to Streaming with Multiple Persons and Blur Type as No Blur", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_NewAuthentication_Startup_NoBlur_MultiplePersons() throws IOException {
    objectKey = MULTIPLE_PERSONS_IMAGE.getAbsolutePath().substring(MULTIPLE_PERSONS_IMAGE.getAbsolutePath().indexOf("Endpoint"));
    GCSHelper.downloadObject(
        ConfigurationFileHelper.getInstance().getProjectId(),
        ConfigurationFileHelper.getInstance().getBucketName(),
        objectKey.replaceAll("\\\\", "/"),
        MULTIPLE_PERSONS_IMAGE.getAbsolutePath());
    filePath = MULTIPLE_PERSONS_IMAGE.getAbsolutePath();
    responseResult = sendImageToFaceAuth(filePath, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "NoBlur");
    authenticationValidations.validateResponseForNewAuthenticationScenariosWithBlurType(AuthenticationScenariosWithBlurType.NO_BLUR_MULTIPLE_PERSONS, responseResult, FACE_AUTH_MODE_STARTUP);

  }

  @XrayTest(key = "ORN-4396", summary = "TC_Endpoint_NewAuthentication_Startup_NoBlur_NoFacesFound", description = "Authenticate to Streaming with No Faces and Blur Type as No Blur", labels = "E2E")
  @Test(description = "Authenticate to Streaming with No Faces and Blur Type as No Blur", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_NewAuthentication_Startup_NoBlur_NoFacesFound() throws IOException {
    objectKey = NO_FACES_FOUND_IMAGE.getAbsolutePath().substring(NO_FACES_FOUND_IMAGE.getAbsolutePath().indexOf("Endpoint"));
    GCSHelper.downloadObject(
        ConfigurationFileHelper.getInstance().getProjectId(),
        ConfigurationFileHelper.getInstance().getBucketName(),
        objectKey.replaceAll("\\\\", "/"),
        NO_FACES_FOUND_IMAGE.getAbsolutePath());
    filePath = NO_FACES_FOUND_IMAGE.getAbsolutePath();
    responseResult = sendImageToFaceAuth(filePath, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "NoBlur");
    authenticationValidations.validateResponseForNewAuthenticationScenariosWithBlurType(AuthenticationScenariosWithBlurType.NO_BLUR_NO_FACES_FOUND, responseResult, FACE_AUTH_MODE_STARTUP);

  }

  @XrayTest(key = "ORN-4398", summary = "TC_Endpoint_NewAuthentication_Startup_NoBlur_BlockedCamera", description = "Authenticate to Streaming with Blocked Camera and Blur Type as No Blur", labels = "E2E")
  @Test(description = "Authenticate to Streaming with Blocked Camera and Blur Type as No Blur", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_NewAuthentication_Startup_NoBlur_BlockedCamera() throws IOException {
    objectKey = BLOCKED_CAMERA_IMAGE.getAbsolutePath().substring(BLOCKED_CAMERA_IMAGE.getAbsolutePath().indexOf("Endpoint"));
    GCSHelper.downloadObject(
        ConfigurationFileHelper.getInstance().getProjectId(),
        ConfigurationFileHelper.getInstance().getBucketName(),
        objectKey.replaceAll("\\\\", "/"),
        BLOCKED_CAMERA_IMAGE.getAbsolutePath());
    filePath = BLOCKED_CAMERA_IMAGE.getAbsolutePath();
    responseResult = sendImageToFaceAuth(filePath, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "NoBlur");
    authenticationValidations.validateResponseForNewAuthenticationScenariosWithBlurType(AuthenticationScenariosWithBlurType.NO_BLUR_BLOCKED_CAMERA, responseResult, FACE_AUTH_MODE_STARTUP);

  }

  @XrayTest(key = "ORN-4400", summary = "TC_Endpoint_NewAuthentication_Startup_NoBlur_OtherPerson", description = "Authenticate to Streaming with Other Person and Blur Type as No Blur", labels = "E2E")
  @Test(description = "Authenticate to Streaming with Other Person and Blur Type as No Blur", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_NewAuthentication_Startup_NoBlur_OtherPerson() throws IOException {
    objectKey = OTHER_PERSON_IMAGE.getAbsolutePath().substring(OTHER_PERSON_IMAGE.getAbsolutePath().indexOf("Endpoint"));
    GCSHelper.downloadObject(
        ConfigurationFileHelper.getInstance().getProjectId(),
        ConfigurationFileHelper.getInstance().getBucketName(),
        objectKey.replaceAll("\\\\", "/"),
        OTHER_PERSON_IMAGE.getAbsolutePath());
    filePath = OTHER_PERSON_IMAGE.getAbsolutePath();
    responseResult = sendImageToFaceAuth(filePath, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "NoBlur");
    authenticationValidations.validateResponseForNewAuthenticationScenariosWithBlurType(AuthenticationScenariosWithBlurType.NO_BLUR_OTHER_PERSON, responseResult, FACE_AUTH_MODE_STARTUP);

  }

  @XrayTest(key = "ORN-4402", summary = "TC_Endpoint_NewAuthentication_Startup_NoBlur_Spoof", description = "Authenticate to Streaming with Spoof Image and Blur Type as No Blur", labels = "E2E")
  @Test(description = "Authenticate to Streaming with Spoof Image and Blur Type as No Blur", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_NewAuthentication_Startup_NoBlur_Spoof() throws IOException {
    objectKey = SPOOF_IMAGE.getAbsolutePath().substring(SPOOF_IMAGE.getAbsolutePath().indexOf("Endpoint"));
    GCSHelper.downloadObject(
        ConfigurationFileHelper.getInstance().getProjectId(),
        ConfigurationFileHelper.getInstance().getBucketName(),
        objectKey.replaceAll("\\\\", "/"),
        SPOOF_IMAGE.getAbsolutePath());
    filePath = SPOOF_IMAGE.getAbsolutePath();
    responseResult = sendImageToFaceAuth(filePath, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "NoBlur");
    authenticationValidations.validateResponseForNewAuthenticationScenariosWithBlurType(AuthenticationScenariosWithBlurType.NO_BLUR_SPOOF, responseResult, FACE_AUTH_MODE_STARTUP);

  }


  @XrayTest(key = "ORN-4391", summary = "TC_Endpoint_NewAuthentication_Startup_SecondaryPersonBlur_Success", description = "Authenticate to Streaming with Valid Person and Blur Type as Secondary Person Blur", labels = "E2E")
  @Test(groups = {"smoke"}, description = "Authenticate to Streaming with Valid Person and Blur Type as Secondary Person Blur", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_NewAuthentication_Startup_SecondaryPersonBlur_Success() throws IOException {
    objectKey = BASE_LINE_IMAGE.getAbsolutePath().substring(BASE_LINE_IMAGE.getAbsolutePath().indexOf("Endpoint"));
    GCSHelper.downloadObject(
        ConfigurationFileHelper.getInstance().getProjectId(),
        ConfigurationFileHelper.getInstance().getBucketName(),
        objectKey.replaceAll("\\\\", "/"),
        BASE_LINE_IMAGE.getAbsolutePath());
    filePath = BASE_LINE_IMAGE.getAbsolutePath();
    responseResult = sendImageToFaceAuth(filePath, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "SecondaryPersonBlur");
    authenticationValidations.validateResponseForNewAuthenticationScenariosWithBlurType(AuthenticationScenariosWithBlurType.SECONDARY_PERSON_BLUR_SUCCESS, responseResult, FACE_AUTH_MODE_STARTUP);

  }

  @XrayTest(key = "ORN-4393", summary = "TC_Endpoint_NewAuthentication_Startup_SecondaryPersonBlur_CellPhone", description = "Authenticate to Streaming with Valid Person and CellPhone and Blur Type as Secondary Person Blur", labels = "E2E")
  @Test(description = "Authenticate to Streaming with Valid Person and Cell Phone and Blur Type as Secondary Person Blur", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_NewAuthentication_Startup_SecondaryPersonBlur_CellPhone() throws IOException {
    objectKey = CELL_PHONE_IMAGE.getAbsolutePath().substring(CELL_PHONE_IMAGE.getAbsolutePath().indexOf("Endpoint"));
    GCSHelper.downloadObject(
        ConfigurationFileHelper.getInstance().getProjectId(),
        ConfigurationFileHelper.getInstance().getBucketName(),
        objectKey.replaceAll("\\\\", "/"),
        CELL_PHONE_IMAGE.getAbsolutePath());
    filePath = CELL_PHONE_IMAGE.getAbsolutePath();
    responseResult = sendImageToFaceAuth(filePath, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "SecondaryPersonBlur");
    authenticationValidations.validateResponseForNewAuthenticationScenariosWithBlurType(AuthenticationScenariosWithBlurType.SECONDARY_PERSON_BLUR_CELL_PHONE, responseResult, FACE_AUTH_MODE_STARTUP);

  }

  @XrayTest(key = "ORN-4395", summary = "TC_Endpoint_NewAuthentication_Startup_SecondaryPersonBlur_MultiplePersons", description = "Authenticate to Streaming with Multiple Persons Blur Type as Secondary Person Blur", labels = "E2E")
  @Test(description = "Authenticate to Streaming with Multiple Persons and Blur Type as Secondary Person Blur", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_NewAuthentication_Startup_SecondaryPersonBlur_MultiplePersons() throws IOException {
    objectKey = MULTIPLE_PERSONS_IMAGE.getAbsolutePath().substring(MULTIPLE_PERSONS_IMAGE.getAbsolutePath().indexOf("Endpoint"));
    GCSHelper.downloadObject(
        ConfigurationFileHelper.getInstance().getProjectId(),
        ConfigurationFileHelper.getInstance().getBucketName(),
        objectKey.replaceAll("\\\\", "/"),
        MULTIPLE_PERSONS_IMAGE.getAbsolutePath());
    filePath = MULTIPLE_PERSONS_IMAGE.getAbsolutePath();
    responseResult = sendImageToFaceAuth(filePath, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "SecondaryPersonBlur");
    authenticationValidations.validateResponseForNewAuthenticationScenariosWithBlurType(AuthenticationScenariosWithBlurType.SECONDARY_PERSON_BLUR_MULTIPLE_PERSONS, responseResult, FACE_AUTH_MODE_STARTUP);

  }

  @XrayTest(key = "ORN-4397", summary = "TC_Endpoint_NewAuthentication_Startup_SecondaryPersonBlur_NoFacesFound", description = "Authenticate to Streaming with No Faces and Blur Type as Secondary Person Blur", labels = "E2E")
  @Test(description = "Authenticate to Streaming with No Faces and Blur Type as Secondary Person Blur", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_NewAuthentication_Startup_SecondaryPersonBlur_NoFacesFound() throws IOException {
    objectKey = NO_FACES_FOUND_IMAGE.getAbsolutePath().substring(NO_FACES_FOUND_IMAGE.getAbsolutePath().indexOf("Endpoint"));
    GCSHelper.downloadObject(
        ConfigurationFileHelper.getInstance().getProjectId(),
        ConfigurationFileHelper.getInstance().getBucketName(),
        objectKey.replaceAll("\\\\", "/"),
        NO_FACES_FOUND_IMAGE.getAbsolutePath());
    filePath = NO_FACES_FOUND_IMAGE.getAbsolutePath();
    responseResult = sendImageToFaceAuth(filePath, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "SecondaryPersonBlur");
    authenticationValidations.validateResponseForNewAuthenticationScenariosWithBlurType(AuthenticationScenariosWithBlurType.SECONDARY_PERSON_BLUR_NO_FACES_FOUND, responseResult, FACE_AUTH_MODE_STARTUP);

  }

  @XrayTest(key = "ORN-4399", summary = "TC_Endpoint_NewAuthentication_Startup_SecondaryPersonBlur_BlockedCamera", description = "Authenticate to Streaming with Blocked Camera and Blur Type as Secondary Person Blur", labels = "E2E")
  @Test(description = "Authenticate to Streaming with Blocked Camera and Blur Type as Secondary Person Blur", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_NewAuthentication_Startup_SecondaryPersonBlur_BlockedCamera() throws IOException {
    objectKey = BLOCKED_CAMERA_IMAGE.getAbsolutePath().substring(BLOCKED_CAMERA_IMAGE.getAbsolutePath().indexOf("Endpoint"));
    GCSHelper.downloadObject(
        ConfigurationFileHelper.getInstance().getProjectId(),
        ConfigurationFileHelper.getInstance().getBucketName(),
        objectKey.replaceAll("\\\\", "/"),
        BLOCKED_CAMERA_IMAGE.getAbsolutePath());
    filePath = BLOCKED_CAMERA_IMAGE.getAbsolutePath();
    responseResult = sendImageToFaceAuth(filePath, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "SecondaryPersonBlur");
    authenticationValidations.validateResponseForNewAuthenticationScenariosWithBlurType(AuthenticationScenariosWithBlurType.SECONDARY_PERSON_BLUR_BLOCKED_CAMERA, responseResult, FACE_AUTH_MODE_STARTUP);

  }

  @XrayTest(key = "ORN-4401", summary = "TC_Endpoint_NewAuthentication_Startup_SecondaryPersonBlur_OtherPerson", description = "Authenticate to Streaming with Blocked Camera and Blur Type as Secondary Person Blur", labels = "E2E")
  @Test(description = "Authenticate to Streaming with Other Person and Blur Type as Secondary Person Blur", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_NewAuthentication_Startup_SecondaryPersonBlur_OtherPerson() throws IOException {
    objectKey = OTHER_PERSON_IMAGE.getAbsolutePath().substring(OTHER_PERSON_IMAGE.getAbsolutePath().indexOf("Endpoint"));
    GCSHelper.downloadObject(
        ConfigurationFileHelper.getInstance().getProjectId(),
        ConfigurationFileHelper.getInstance().getBucketName(),
        objectKey.replaceAll("\\\\", "/"),
        OTHER_PERSON_IMAGE.getAbsolutePath());
    filePath = OTHER_PERSON_IMAGE.getAbsolutePath();
    responseResult = sendImageToFaceAuth(filePath, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "SecondaryPersonBlur");
    authenticationValidations.validateResponseForNewAuthenticationScenariosWithBlurType(AuthenticationScenariosWithBlurType.SECONDARY_PERSON_BLUR_OTHER_PERSON, responseResult, FACE_AUTH_MODE_STARTUP);

  }

  @XrayTest(key = "ORN-4403", summary = "TC_Endpoint_NewAuthentication_Startup_SecondaryPersonBlur_Spoof", description = "Authenticate to Streaming with Spoof Image and Blur Type as Secondary Person Blur", labels = "E2E")
  @Test(description = "Authenticate to Streaming with Spoof Image and Blur Type as Secondary Person Blur", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_NewAuthentication_Startup_SecondaryPersonBlur_Spoof() throws IOException {
    objectKey = SPOOF_IMAGE.getAbsolutePath().substring(SPOOF_IMAGE.getAbsolutePath().indexOf("Endpoint"));
    GCSHelper.downloadObject(
        ConfigurationFileHelper.getInstance().getProjectId(),
        ConfigurationFileHelper.getInstance().getBucketName(),
        objectKey.replaceAll("\\\\", "/"),
        SPOOF_IMAGE.getAbsolutePath());
    filePath = SPOOF_IMAGE.getAbsolutePath();
    responseResult = sendImageToFaceAuth(filePath, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "SecondaryPersonBlur");
    authenticationValidations.validateResponseForNewAuthenticationScenariosWithBlurType(AuthenticationScenariosWithBlurType.SECONDARY_PERSON_BLUR_SPOOF, responseResult, FACE_AUTH_MODE_STARTUP);

  }

  @XrayTest(key = "ORN-4448", summary = "TC_Endpoint_NewAuthentication_Startup_Blur_Background_Success", description = "Authenticate to Streaming with Valid Person and Blur Type as Blur Background", labels = "E2E")
  @Test(description = "Authenticate to Streaming with Valid Person and Blur Type as Blur Background", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_NewAuthentication_Startup_Blur_Background_Success() throws IOException {
    objectKey = BASE_LINE_IMAGE.getAbsolutePath().substring(BASE_LINE_IMAGE.getAbsolutePath().indexOf("Endpoint"));
    GCSHelper.downloadObject(
        ConfigurationFileHelper.getInstance().getProjectId(),
        ConfigurationFileHelper.getInstance().getBucketName(),
        objectKey.replaceAll("\\\\", "/"),
        BASE_LINE_IMAGE.getAbsolutePath());
    filePath = BASE_LINE_IMAGE.getAbsolutePath();
    responseResult = sendImageToFaceAuth(filePath, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "BlurBackground");
    authenticationValidations.validateResponseForNewAuthenticationScenariosWithBlurType(AuthenticationScenariosWithBlurType.BLUR_BACKGROUND_SUCCESS, responseResult, FACE_AUTH_MODE_STARTUP);

  }

  @XrayTest(key = "ORN-4451", summary = "TC_Endpoint_NewAuthentication_Startup_Blur_Background_CellPhone", description = "Authenticate to Streaming with Valid Person and CellPhone and Blur Type as Blur Background", labels = "E2E")
  @Test(description = "Authenticate to Streaming with Valid Person and Cell Phone and Blur Type as Blur Background", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_NewAuthentication_Startup_Blur_Background_CellPhone() throws IOException {
    objectKey = CELL_PHONE_IMAGE.getAbsolutePath().substring(CELL_PHONE_IMAGE.getAbsolutePath().indexOf("Endpoint"));
    GCSHelper.downloadObject(
        ConfigurationFileHelper.getInstance().getProjectId(),
        ConfigurationFileHelper.getInstance().getBucketName(),
        objectKey.replaceAll("\\\\", "/"),
        CELL_PHONE_IMAGE.getAbsolutePath());
    filePath = CELL_PHONE_IMAGE.getAbsolutePath();
    responseResult = sendImageToFaceAuth(filePath, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "BlurBackground");
    authenticationValidations.validateResponseForNewAuthenticationScenariosWithBlurType(AuthenticationScenariosWithBlurType.BLUR_BACKGROUND_CELL_PHONE, responseResult, FACE_AUTH_MODE_STARTUP);

  }

  @XrayTest(key = "ORN-4449", summary = "TC_Endpoint_NewAuthentication_Startup_Blur_Background_MultiplePersons", description = "Authenticate to Streaming with Multiple Persons Blur Type as Blur Background", labels = "E2E")
  @Test(description = "Authenticate to Streaming with Multiple Persons and Blur Type as Blur Background", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_NewAuthentication_Startup_Blur_Background_MultiplePersons() throws IOException {
    objectKey = MULTIPLE_PERSONS_IMAGE.getAbsolutePath().substring(MULTIPLE_PERSONS_IMAGE.getAbsolutePath().indexOf("Endpoint"));
    GCSHelper.downloadObject(
        ConfigurationFileHelper.getInstance().getProjectId(),
        ConfigurationFileHelper.getInstance().getBucketName(),
        objectKey.replaceAll("\\\\", "/"),
        MULTIPLE_PERSONS_IMAGE.getAbsolutePath());
    filePath = MULTIPLE_PERSONS_IMAGE.getAbsolutePath();
    responseResult = sendImageToFaceAuth(filePath, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "BlurBackground");
    authenticationValidations.validateResponseForNewAuthenticationScenariosWithBlurType(AuthenticationScenariosWithBlurType.BLUR_BACKGROUND_MULTIPLE_PERSONS, responseResult, FACE_AUTH_MODE_STARTUP);

  }

  @XrayTest(key = "ORN-4452", summary = "TC_Endpoint_NewAuthentication_Startup_Blur_Background_NoFacesFound", description = "Authenticate to Streaming with No Faces and Blur Type as Blur Background", labels = "E2E")
  @Test(description = "Authenticate to Streaming with No Faces and Blur Type as Blur Background", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_NewAuthentication_Startup_Blur_Background_NoFacesFound() throws IOException {
    objectKey = NO_FACES_FOUND_IMAGE.getAbsolutePath().substring(NO_FACES_FOUND_IMAGE.getAbsolutePath().indexOf("Endpoint"));
    GCSHelper.downloadObject(
        ConfigurationFileHelper.getInstance().getProjectId(),
        ConfigurationFileHelper.getInstance().getBucketName(),
        objectKey.replaceAll("\\\\", "/"),
        NO_FACES_FOUND_IMAGE.getAbsolutePath());
    filePath = NO_FACES_FOUND_IMAGE.getAbsolutePath();
    responseResult = sendImageToFaceAuth(filePath, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "BlurBackground");
    authenticationValidations.validateResponseForNewAuthenticationScenariosWithBlurType(AuthenticationScenariosWithBlurType.BLUR_BACKGROUND_NO_FACES_FOUND, responseResult, FACE_AUTH_MODE_STARTUP);

  }

  @XrayTest(key = "ORN-4454", summary = "TC_Endpoint_NewAuthentication_Startup_Blur_Background_BlockedCamera", description = "Authenticate to Streaming with Blocked Camera and Blur Type as Blur Background", labels = "E2E")
  @Test(description = "Authenticate to Streaming with Blocked Camera and Blur Type as Blur Background", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_NewAuthentication_Startup_Blur_Background_BlockedCamera() throws IOException {
    objectKey = BLOCKED_CAMERA_IMAGE.getAbsolutePath().substring(BLOCKED_CAMERA_IMAGE.getAbsolutePath().indexOf("Endpoint"));
    GCSHelper.downloadObject(
        ConfigurationFileHelper.getInstance().getProjectId(),
        ConfigurationFileHelper.getInstance().getBucketName(),
        objectKey.replaceAll("\\\\", "/"),
        BLOCKED_CAMERA_IMAGE.getAbsolutePath());
    filePath = BLOCKED_CAMERA_IMAGE.getAbsolutePath();
    responseResult = sendImageToFaceAuth(filePath, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "BlurBackground");
    authenticationValidations.validateResponseForNewAuthenticationScenariosWithBlurType(AuthenticationScenariosWithBlurType.BLUR_BACKGROUND_BLOCKED_CAMERA, responseResult, FACE_AUTH_MODE_STARTUP);

  }

  @XrayTest(key = "ORN-4453", summary = "TC_Endpoint_NewAuthentication_Startup_Blur_Background_OtherPerson", description = "Authenticate to Streaming with Other Person and Blur Type as Blur Background", labels = "E2E")
  @Test(description = "Authenticate to Streaming with Other Person and Blur Type as Blur Background", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_NewAuthentication_Startup_Blur_Background_OtherPerson() throws IOException {
    objectKey = OTHER_PERSON_IMAGE.getAbsolutePath().substring(OTHER_PERSON_IMAGE.getAbsolutePath().indexOf("Endpoint"));
    GCSHelper.downloadObject(
        ConfigurationFileHelper.getInstance().getProjectId(),
        ConfigurationFileHelper.getInstance().getBucketName(),
        objectKey.replaceAll("\\\\", "/"),
        OTHER_PERSON_IMAGE.getAbsolutePath());
    filePath = OTHER_PERSON_IMAGE.getAbsolutePath();
    responseResult = sendImageToFaceAuth(filePath, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "BlurBackground");
    authenticationValidations.validateResponseForNewAuthenticationScenariosWithBlurType(AuthenticationScenariosWithBlurType.BLUR_BACKGROUND_OTHER_PERSON, responseResult, FACE_AUTH_MODE_STARTUP);

  }

  @XrayTest(key = "ORN-4450", summary = "TC_Endpoint_NewAuthentication_Startup_Blur_Background_Spoof", description = "Authenticate to Streaming with Spoof Image and Blur Type as Blur Background", labels = "E2E")
  @Test(description = "Authenticate to Streaming with Spoof Image and Blur Type as Blur Background", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Endpoint_NewAuthentication_Startup_Blur_Background_Spoof() throws IOException {
    objectKey = SPOOF_IMAGE.getAbsolutePath().substring(SPOOF_IMAGE.getAbsolutePath().indexOf("Endpoint"));
    GCSHelper.downloadObject(
        ConfigurationFileHelper.getInstance().getProjectId(),
        ConfigurationFileHelper.getInstance().getBucketName(),
        objectKey.replaceAll("\\\\", "/"),
        SPOOF_IMAGE.getAbsolutePath());
    filePath = SPOOF_IMAGE.getAbsolutePath();
    responseResult = sendImageToFaceAuth(filePath, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "BlurBackground");
    authenticationValidations.validateResponseForNewAuthenticationScenariosWithBlurType(AuthenticationScenariosWithBlurType.BLUR_BACKGROUND_SPOOF, responseResult, FACE_AUTH_MODE_STARTUP);

  }
}
