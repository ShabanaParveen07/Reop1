package com.concentrix.suites.EndPoint.StreamingConfigurations.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.BaseTests.ConcentrixBaseTest;
import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.helper.streaming.StreamingApiHelper;
import com.concentrix.automation.service.streaming.pojo.response.GeneralResponse;
import com.concentrix.automation.service.streaming.pojo.response.StandardResponse;
import com.concentrix.listeners.RetryAnalyzer;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class StreamingConfigurationsTests extends ConcentrixBaseTest {

  StreamingApiHelper streamingApiHelper;

  StandardResponse response;

  @BeforeClass(alwaysRun = true)
  public void beforeClass() {
    streamingApiHelper = new StreamingApiHelper();
  }

  @XrayTest(key = "ORN-6090", summary = "TC_Get_Streaming_Configurations_Valid_LanId", description = "Check Streaming Configurations for a Valid LanId", labels = "E2E")
  @Test(description = "Check Streaming Configurations for a Valid LanId", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Get_Streaming_Configurations_Valid_LanId() {
    response = streamingApiHelper.getStreamingConfigurations(ConfigurationFileHelper.getInstance().getLanID(), ConfigurationFileHelper.getInstance().getStreamingAppVersion()).as(StandardResponse.class);
    Assert.assertNotNull(response.getCorrelationId());
    Assert.assertTrue(response.getSuccess());
    Assert.assertNotNull(response.getData().getShowPopup());
    Assert.assertNotNull(response.getData().getBlurSettings());
    Assert.assertNotNull(response.getData().getMiscSettings());
    Assert.assertNotNull(response.getData().getImageSettings());
    Assert.assertNotNull(response.getData().getCameraSettings());
    Assert.assertNotNull(response.getData().getClientSettings());
    Assert.assertNotNull(response.getData().getReadAPIBaseURL());
    Assert.assertNotNull(response.getData().getRetryIntervals());
    Assert.assertNotNull(response.getData().getStatusEndpoint());
    Assert.assertNotNull(response.getData().getDefaultLanguage());
    Assert.assertNotNull(response.getData().getBandWidthSettings());
    Assert.assertNotNull(response.getData().getStreamingEndpoint());
    Assert.assertNotNull(response.getData().getAcknowledgeSettings());
    Assert.assertNotNull(response.getData().getDisableMicrophones());
    Assert.assertNotNull(response.getData().getCalibrationSettings());
    Assert.assertNotNull(response.getData().getFaceAuthDuringSession());
    Assert.assertNotNull(response.getData().getMlIntegrationSettings());
    Assert.assertNotNull(response.getData().getViolationLogIntervals());
    Assert.assertNotNull(response.getData().getNonMLViolationSettings());
    Assert.assertNotNull(response.getData().getRtNotificationEndpoint());
    Assert.assertNotNull(response.getData().getApplicationExitSettings());
    Assert.assertNotNull(response.getData().getClientAppVersionSettings());
    Assert.assertNotNull(response.getData().getAuthenticationOTPSettings());
    Assert.assertNotNull(response.getData().getImageUploadStorageSettings());
    Assert.assertNotNull(response.getData().getDisableMonitoringDelaySetting());
    Assert.assertNotNull(response.getData().getRtNotificationHealthCheckEndpoint());
    Assert.assertNotNull(response.getData().getWorkdayConsent());
    Assert.assertNotNull(response.getData().getUiLocalization());
    Assert.assertNotNull(response.getData().getConfigMessageSettings());
    Assert.assertNotNull(response.getData().getServerMessageSettings());
    Assert.assertEquals(response.getData().getIsConfigUpdated(), "true");
    Assert.assertTrue(response.getData().getConfigVersion().contains("Base-0.OPEXOTHER-0"));
    Assert.assertEquals(response.getUserInfo().getUserName(), ConfigurationFileHelper.getInstance().getLanID().replace(".", " ").substring(0, ConfigurationFileHelper.getInstance().getLanID().indexOf("@")));
    Assert.assertNotNull(response.getUserInfo().getIsOtpAllowed());
    Assert.assertNotNull(response.getUserInfo().getIsSupervisorOTPAllowed());
    Assert.assertTrue(response.getUserInfo().getIsBackUpCodeAllowed());
    Assert.assertEquals(response.getUserInfo().getSsoId(), ConfigurationFileHelper.getInstance().getLanID());
    Assert.assertNotNull(response.getUserInfo().getEnrollmentDate());
    Assert.assertNotNull(response.getUserInfo().getRootCorrelationId());
    Assert.assertNotNull(response.getUserInfo().getCorrelationId());
  }

  @XrayTest(key = "ORN-8579", summary = "TC_Endpoint_Get_Streaming_Configurations_Valid_LanId_with-Authentication", description = "Check Streaming Configurations for a Valid LanId", labels = "E2E")
  @Test(description = "Check Streaming Configurations for a Valid LanId with authentication", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Get_Streaming_Configurations_Valid_LanId_With_Authentication() {
    response = streamingApiHelper.getStreamingConfigurationsWithAuthentication(ConfigurationFileHelper.getInstance().getLanID(), ConfigurationFileHelper.getInstance().getStreamingAppVersion(), authToken).as(StandardResponse.class);
    Assert.assertNotNull(response.getCorrelationId());
    Assert.assertTrue(response.getSuccess());
    Assert.assertNotNull(response.getData().getShowPopup());
    Assert.assertNotNull(response.getData().getBlurSettings());
    Assert.assertNotNull(response.getData().getMiscSettings());
    Assert.assertNotNull(response.getData().getImageSettings());
    Assert.assertNotNull(response.getData().getCameraSettings());
    Assert.assertNotNull(response.getData().getClientSettings());
    Assert.assertNotNull(response.getData().getReadAPIBaseURL());
    Assert.assertNotNull(response.getData().getRetryIntervals());
    Assert.assertNotNull(response.getData().getStatusEndpoint());
    Assert.assertNotNull(response.getData().getDefaultLanguage());
    Assert.assertNotNull(response.getData().getBandWidthSettings());
    Assert.assertNotNull(response.getData().getStreamingEndpoint());
    Assert.assertNotNull(response.getData().getAcknowledgeSettings());
    Assert.assertNotNull(response.getData().getDisableMicrophones());
    Assert.assertNotNull(response.getData().getCalibrationSettings());
    Assert.assertNotNull(response.getData().getFaceAuthDuringSession());
    Assert.assertNotNull(response.getData().getMlIntegrationSettings());
    Assert.assertNotNull(response.getData().getViolationLogIntervals());
    Assert.assertNotNull(response.getData().getNonMLViolationSettings());
    Assert.assertNotNull(response.getData().getRtNotificationEndpoint());
    Assert.assertNotNull(response.getData().getApplicationExitSettings());
    Assert.assertNotNull(response.getData().getClientAppVersionSettings());
    Assert.assertNotNull(response.getData().getAuthenticationOTPSettings());
    Assert.assertNotNull(response.getData().getImageUploadStorageSettings());
    Assert.assertNotNull(response.getData().getDisableMonitoringDelaySetting());
    Assert.assertNotNull(response.getData().getRtNotificationHealthCheckEndpoint());
    Assert.assertNotNull(response.getData().getWorkdayConsent());
    Assert.assertNotNull(response.getData().getUiLocalization());
    Assert.assertNotNull(response.getData().getConfigMessageSettings());
    Assert.assertNotNull(response.getData().getServerMessageSettings());
    Assert.assertEquals(response.getData().getIsConfigUpdated(), "true");
    Assert.assertTrue(response.getData().getConfigVersion().contains("Base-0.OPEXOTHER-0"));
    Assert.assertEquals(response.getUserInfo().getUserName(), ConfigurationFileHelper.getInstance().getLanID().replace(".", " ").substring(0, ConfigurationFileHelper.getInstance().getLanID().indexOf("@")));
    Assert.assertNotNull(response.getUserInfo().getIsOtpAllowed());
    Assert.assertNotNull(response.getUserInfo().getIsSupervisorOTPAllowed());
    Assert.assertTrue(response.getUserInfo().getIsBackUpCodeAllowed());
    Assert.assertEquals(response.getUserInfo().getSsoId(), ConfigurationFileHelper.getInstance().getLanID());
    Assert.assertNotNull(response.getUserInfo().getEnrollmentDate());
    Assert.assertNotNull(response.getUserInfo().getRootCorrelationId());
    Assert.assertNotNull(response.getUserInfo().getCorrelationId());
  }

  @XrayTest(key = "ORN-6091", summary = "TC_Get_Streaming_Configurations_InValid_LanId", description = "Check Streaming Configurations for a InValid LanId", labels = "E2E")
  @Test(description = "Check Streaming Configurations for a InValid LanId", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Get_Streaming_Configurations_InValid_LanId() {
    response = streamingApiHelper.getStreamingConfigurations(ConfigurationFileHelper.getInstance().getLanID() + ".com", ConfigurationFileHelper.getInstance().getStreamingAppVersion()).as(StandardResponse.class);
    Assert.assertNotNull(response.getCorrelationId());
    Assert.assertFalse(response.getSuccess());
    Assert.assertEquals(response.getErrorMessage(), "Invalid SSO");

  }

  @XrayTest(key = "ORN-8581", summary = "TC_Endpoint_Get_Streaming_Configurations_InValid_LanId_with_Authentication", description = "Check Streaming Configurations for a InValid LanId", labels = "E2E")
  @Test(description = "Check Streaming Configurations for a InValid LanId With Authentication", retryAnalyzer = RetryAnalyzer.class)
  public void TC_Get_Streaming_Configurations_InValid_LanId_with_authentication() {
    response = streamingApiHelper.getStreamingConfigurationsWithAuthentication(ConfigurationFileHelper.getInstance().getLanID() + ".com", ConfigurationFileHelper.getInstance().getStreamingAppVersion(), authToken).as(StandardResponse.class);
    Assert.assertNotNull(response.getCorrelationId());
    Assert.assertFalse(response.getSuccess());
    Assert.assertEquals(response.getErrorMessage(), "Invalid SSO");

  }
}
