package com.concentrix.suites.Vision.testData;

import com.concentrix.automation.service.vision.constants.VisionConstants;
import com.concentrix.automation.service.vision.pojo.request.VisionStandardRequest;
import com.concentrix.automation.service.vision.pojo.request.Images;
import com.concentrix.automation.service.vision.pojo.response.UserTokenResponse;

import java.util.ArrayList;
import java.util.List;

public class EnrollmentFullRequest {

  public VisionStandardRequest enrollmentRequest(String Rimage, String Limage, String Fimage,String JobId,String JobName, UserTokenResponse userTokenResponse) {
    Images rImage = Images.builder().imageData(Rimage).imagePosition("R").build();
    Images lImage = Images.builder().imageData(Limage).imagePosition("L").build();
    Images fImage = Images.builder().imageData(Fimage).imagePosition("F").build();

    List<Images> images = new ArrayList<>();
    images.add(rImage);
    images.add(lImage);
    images.add(fImage);

    return VisionStandardRequest.builder().emailId(userTokenResponse.getEmailId())
        .candidateID(userTokenResponse.getCandidateID())
        .location(userTokenResponse.getLocation())
        .firstname(userTokenResponse.getFirstname())
        .lastname(userTokenResponse.getLastname())
        .jobid(JobId)
        .jobname(JobName)
        .language(userTokenResponse.getLanguage())
        .isexists(userTokenResponse.getIsexists())
        .images(images).build();

  }


}
