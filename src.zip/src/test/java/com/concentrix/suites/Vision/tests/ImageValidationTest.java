package com.concentrix.suites.Vision.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.BaseTests.VisionBaseTest;
import com.concentrix.automation.helper.vision.VisionHelper;
import com.concentrix.automation.rest.ConversionUtil;
import com.concentrix.automation.service.streaming.constants.EndPointConstants;
import com.concentrix.automation.service.streaming.pojo.request.TestData;
import com.concentrix.automation.service.streaming.pojo.response.GeneralResponse;
import com.concentrix.automation.service.vision.pojo.request.ImageValidationRequest;
import com.concentrix.automation.service.vision.pojo.response.ImageValidationResponse;
import com.concentrix.suites.ML.testdata.MLDataProvider;
import io.restassured.response.Response;
import lombok.extern.log4j.Log4j;
import org.testng.Assert;
import org.testng.annotations.Test;

@Log4j
public class ImageValidationTest extends VisionBaseTest {

  //@XrayTest(key = "VS-93", summary = "TC_Vision_Enrollment_Success_Response", description = "Image validation API response for valid image", labels = "E2E")
  @Test(groups = {"smoke"}, description = "Image validation API response for valid image", dataProviderClass = MLDataProvider.class, dataProvider = "getVisionSpoofTP")
  public void spoofImageTest(TestData testData) {
    log.info("Test Data: " + testData);
    String imageFilePath = "src/test/resources/ML/spoofImagesSumit/";
    String path = imageFilePath + "TP/" + testData.getFileName();
    VisionHelper visionHelper = new VisionHelper();
    String base64Str = imageToBase64Converter(path);
    log.info("base64Encoded data: " + base64Str);
    ImageValidationRequest imageValidationRequest = ImageValidationRequest.builder().imageData(base64Str).build();
    Response response = visionHelper.imageValidation(imageValidationRequest, Token);
    assertResponseData(response, EndPointConstants.spoofResultId, "SPOOF","FAIL");
  }

  protected void assertResponseData(Response response, Integer resultId, String expectedMsg,String responseStatus) {
    GeneralResponse generalResponse = response.getBody().as(
        GeneralResponse.class);
    Assert.assertEquals(response.getStatusCode(), EndPointConstants.responseOK, "Actual status code: " + response.getStatusCode());
    Assert.assertNotNull(generalResponse.getData());
    ImageValidationResponse imageResponse = ConversionUtil.deserializedResponse(generalResponse.getData(), ImageValidationResponse.class);
    Assert.assertEquals(imageResponse.getMsg(), expectedMsg, "Actual message is: " + imageResponse.getMsg());
    Assert.assertEquals(imageResponse.getResult_id(), String.valueOf(resultId), "Actual result Id: " + imageResponse.getResult_id());
    Assert.assertEquals(generalResponse.getResponseStatus().toUpperCase(), responseStatus, "Actual response status: " + generalResponse.getResponseStatus());
    Assert.assertEquals(generalResponse.getResponseResult(), expectedMsg, "Actual response result: " + generalResponse.getResponseResult());
  }
}
