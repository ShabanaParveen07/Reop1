package com.concentrix.suites.Vision.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.BaseTests.VisionBaseTest;
import com.concentrix.automation.service.vision.constants.VisionConstants;
import com.concentrix.automation.service.vision.pojo.response.VisionStandardResponse;
import com.concentrix.automation.service.vision.pojo.response.TokenDataResponse;
import com.concentrix.automation.service.vision.pojo.response.UserTokenResponse;
import com.concentrix.suites.Vision.testData.EnrollmentFullRequest;
import com.concentrix.suites.Vision.validations.TokenApiResponseValidations;
import com.fasterxml.jackson.core.JsonProcessingException;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class VisionTokenApiTest extends VisionBaseTest {

  EnrollmentFullRequest enrollmentFullRequest;
  TokenApiResponseValidations tokenApiResponseValidations;

  @BeforeClass(alwaysRun = true)
  public void beforeClass() {
    enrollmentFullRequest = new EnrollmentFullRequest();
    tokenApiResponseValidations = new TokenApiResponseValidations();
  }

  @XrayTest(key = "VS-311", summary = "TC_Vision_Token_Api_response_for_not_enrolled_user", description = "Token API Success Response for not enrolled user", labels = "E2E")
  @Test(groups = {"smoke"}, description = "Token API Success Response with not enrolled user")
  public void TC01_Vision_Token_Api_response_for_not_enrolled_user() throws JsonProcessingException {
    Assert.assertEquals(response.getStatusCode(),200);
    VisionStandardResponse standardResponse = response.as(VisionStandardResponse.class);
    tokenApiResponseValidations.TokenApiUserTokenValidation(userTokenResponse,EmailId ,false);
  }

  @XrayTest(key = "VS-311", summary = "TC_Vision_Token_Api_response_enrolled_user", description = "Token API Success Response for enrolled user", labels = "E2E")
  @Test(groups = {"smoke"}, description = "Token API Success Response for enrolled user")
  public void TC02_Vision_Token_Api_response_for_enrolled_user() throws JsonProcessingException {
    String frontImagePath = imageFilePath + "front.png";
    String leftImagePath = imageFilePath + "left.png";
    String rightImagePath = imageFilePath + "right.png";
    String frontImage = imageToBase64Converter(frontImagePath);
    String leftImage = imageToBase64Converter(leftImagePath);
    String rightImage = imageToBase64Converter(rightImagePath);
    String enrollmentRequest = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(enrollmentFullRequest.enrollmentRequest(
        rightImage,
        leftImage,
        frontImage,
        VisionConstants.JOBID1,
        VisionConstants.JobName1,
        userTokenResponse
    ));
    Response Enrollmentresponse = visionHelper.EnrollmentHelper(enrollmentRequest.trim(),Token);
    Assert.assertEquals(Enrollmentresponse.getStatusCode(),201);
    Response TokenResponse = visionHelper.TokenHelper(EmailId);
    Assert.assertEquals(TokenResponse.getStatusCode(),200);
    VisionStandardResponse standardResponse = TokenResponse.as(VisionStandardResponse.class);
    TokenDataResponse tokenDataResponse = objectMapper.readValue(standardResponse.getData(), TokenDataResponse.class);
    UserTokenResponse  userTokenResponse = objectMapper.readValue(decodeString(tokenDataResponse.getUserToken()),UserTokenResponse.class);
    tokenApiResponseValidations.TokenApiUserTokenValidation(userTokenResponse,EmailId ,true);

  }

  @XrayTest(key = "VS-311", summary = "TC_Vision_Token_Api_response_invalid_email", description = "Token API Success Response for invalid email", labels = "E2E")
  @Test(description = "Token API Success Response for invalid email")
  public void TC03_Vision_Token_Api_response_for_invalid_email() throws JsonProcessingException {
   String[] emails = new String[]{userTokenResponse.getCandidateID(),VisionConstants.FIRSTNAME+"@"+VisionConstants.LASTNAME};
   for(String email : emails) {
     Response TokenResponse = visionHelper.TokenHelper(email);
     Assert.assertEquals(TokenResponse.getStatusCode(), 400);
     VisionStandardResponse standardResponse = TokenResponse.as(VisionStandardResponse.class);
     Assert.assertEquals(standardResponse.getResponseResult(),String.format(VisionConstants.INVALIDEMAIL,email));
     Assert.assertEquals(standardResponse.getResponseStatus(),VisionConstants.FAIL);
   }
  }
}
