package com.concentrix.suites.Vision.validations;

import com.concentrix.automation.service.vision.constants.VisionConstants;
import com.concentrix.automation.service.vision.pojo.response.VisionStandardResponse;
import io.restassured.response.Response;
import org.testng.Assert;

public class EnrollmentResponseValidations {

  public void EnrollmentStandardResponseValidation(Response response, String emailID){
    VisionStandardResponse visionStandardResponse = response.as(VisionStandardResponse.class);
    Assert.assertEquals(visionStandardResponse.getResponseResult(),String.format(VisionConstants.RESPONSERESULT,emailID));
    Assert.assertEquals(visionStandardResponse.getResponseStatus(),VisionConstants.SUCCESS);
    Assert.assertNull(visionStandardResponse.getData());
    Assert.assertNull(visionStandardResponse.getResponseResult1());
  }
}
