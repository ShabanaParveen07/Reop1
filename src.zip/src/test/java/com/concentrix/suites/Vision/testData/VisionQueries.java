package com.concentrix.suites.Vision.testData;

public class VisionQueries {

  public static String ENROLLMENT_EMPLOYEE_QUERY="SELECT lanid,emailaddr,employeeId,firstname,lastname,empid FROM fb_enrollment_%s.employee where lanid='%s';";
  public static String ENROLLMENT_SYSTEMENVIRONMENT_QUERY="SELECT employeeid,empid,systemenviornmentid FROM fb_enrollment_%s.systemenviornment  where employeeid = '%s';";
  public static String ENROLLMENT_IMAGEBAG_QUERY="SELECT systemenviornmentid,employeeid,empid,imageprofile FROM fb_enrollment_%s.enrollment_imagebag where employeeid = '%s';";
  public static String ENROLLMENT_AGENTENROLLMENT_QUERY="SELECT Employeeid as employeeid, SsoId as lanid,EnrollmentAction,EnrollmentActionBy,Remarks,Enrollmentflag  FROM fb_enrollment_%s.AgentEnrollment where Employeeid='%s';";
  public static String ENROLLMENT_JOBDETAILS_QUERY="SELECT CANDIDATE_ID as employeeid,JOBAPPLICATION_ID as JobId FROM fb_enrollment_%s.CandidateJobDetails where CANDIDATE_ID ='%s';";
  public static String ENORLLMENT_IMAGEEMBADDINGS_COUNT_QUERY="SELECT count(*) as count FROM fb_enrollment_%s.image_embeddings where employeeid='%s';";
  public static String ENROLLMENT_CANDIDATE_ADDITIONALINFORMATION_QUERY="SELECT CANDIDATE_ID as employeeId,FIRST_NAME as firstname,LAST_NAME as lastname,EMAIL_ID as emailaddr FROM fb_enrollment_%s.Candidateadditionalinformation where EMAIL_ID='%s';";
  public static String ENROLLMENT_CANDIDATE_ASSESSMENT_COUNT_QUERY= "SELECT count(*) as count FROM fb_enrollment_%s.CandidateAssessmentDetails where CANDIDATE_ID='%s';";

  public static String DELETE_ENROLLMENT_EMPLOYEE_QUERY="delete FROM fb_enrollment_%s.employee where lanid ='%s';";
  public static String DELETE_ENROLLMENT_SYSTEMENVIRONMENT_QUERY="delete FROM fb_enrollment_%s.systemenviornment where employeeid ='%s';";
  public static String DELETE_ENROLLMENT_IMAGEBAG_QUERY="delete FROM fb_enrollment_%s.enrollment_imagebag  where employeeId = '%s';";
  public static String DELETE_ENROLLMENT_AGENTENROLLMENT_QUERY="delete FROM fb_enrollment_%s.AgentEnrollment where SsoId = '%s';";
  public static String DELETE_ENROLLMENT_CANDIDATE_ADDITIONAL_INFORMATION="delete FROM fb_enrollment_%s.Candidateadditionalinformation where EMAIL_ID ='%s';";
  public static String DELETE_ENROLLMENT_JOBDETAILS_QUERY="delete FROM fb_enrollment_%s.CandidateJobDetails where CANDIDATE_ID = '%s';";
  public static String DELETE_ENORLLMENT_IMAGEEMBADDINGS_QUERY="delete FROM fb_enrollment_%s.image_embeddings where employeeid = '%s';";
  public static String DELETE_ENROLLMENT_CANDIDATE_ASSESSMENT_QUERY= "delete FROM fb_enrollment_%s.CandidateAssessmentDetails where CANDIDATE_ID = '%s';";


}
