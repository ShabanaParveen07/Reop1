package com.concentrix.suites.Vision.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.BaseTests.VisionBaseTest;
import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.service.vision.constants.VisionConstants;
import com.concentrix.automation.service.vision.pojo.response.TokenDataResponse;
import com.concentrix.automation.service.vision.pojo.response.UserTokenResponse;
import com.concentrix.automation.service.vision.pojo.response.VisionStandardResponse;
import com.concentrix.listeners.RetryAnalyzer;
import com.concentrix.suites.Vision.testData.VisionQueries;
import com.concentrix.suites.Vision.validations.EnrollmentDBValidations;
import com.concentrix.suites.Vision.testData.EnrollmentFullRequest;
import com.concentrix.suites.Vision.validations.EnrollmentResponseValidations;
import com.fasterxml.jackson.core.JsonProcessingException;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


public class EnrollmentTest extends VisionBaseTest {

  EnrollmentFullRequest enrollmentFullRequest;
  EnrollmentDBValidations enrollmentDBValidations;
  EnrollmentResponseValidations enrollmentResponseValidations;

  public String frontImage;
  public String leftImage;
  public String rightImage;
  public String env;
  public String workdDayemailID="prabha.shareef112@gmail.com";
  public String workdayCandidateID="00420412621";


  @BeforeClass(alwaysRun = true)
  public void beforeClass() {
    enrollmentFullRequest = new EnrollmentFullRequest();
    String frontImagePath = imageFilePath + "front.png";
    String leftImagePath = imageFilePath + "left.png";
    String rightImagePath = imageFilePath + "right.png";
    frontImage = imageToBase64Converter(frontImagePath);
    leftImage = imageToBase64Converter(leftImagePath);
    rightImage = imageToBase64Converter(rightImagePath);
    enrollmentResponseValidations = new EnrollmentResponseValidations();
    env = ConfigurationFileHelper.getInstance().getEnv();
    enrollmentDBValidations = new EnrollmentDBValidations(dbConnectionHelper, ConfigurationFileHelper.getInstance().getEnv());
  }

  @XrayTest(key = "VS-93", summary = "TC_Vision_Enrollment_Success_Response", description = "Enrollment API Success Response", labels = "E2E")
  @Test(groups = {"smoke"}, description = "Enrollment API Success Response and Data Storage in DB")
  public void TC01_Vision_Candidate_Enrollment() throws JsonProcessingException {
    String enrollmentRequest = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(enrollmentFullRequest.enrollmentRequest(
        rightImage,
        leftImage,
        frontImage,
        VisionConstants.JOBID1,
        VisionConstants.JobName1,
        userTokenResponse
    ));
    Response response = visionHelper.EnrollmentHelper(enrollmentRequest.trim(),Token);
    Assert.assertEquals(response.getStatusCode(),201);
    enrollmentResponseValidations.EnrollmentStandardResponseValidation(response,EmailId);
    enrollmentDBValidations.EnrollmentEmployeeTableValidation(EmailId,userTokenResponse.getCandidateID(),userTokenResponse.getFirstname(),userTokenResponse.getLastname());
    enrollmentDBValidations.EnrollmentSystemEnvironmentTableValidation(userTokenResponse.getCandidateID());
    enrollmentDBValidations.EnrollmentImagebagTableValidation(userTokenResponse.getCandidateID());
    enrollmentDBValidations.EnrollmentAgentEnrollmentTableValidation(userTokenResponse.getCandidateID(),EmailId);
    enrollmentDBValidations.EnrollmentSingleJOBIDInJobDetailsTableValidation(userTokenResponse.getCandidateID(),VisionConstants.JOBID1);
    enrollmentDBValidations.EnrollmentImageEmbaddingsCountValidation(userTokenResponse.getCandidateID());
    enrollmentDBValidations.EnrollmentCandidateAdditionalInformationValidation(userTokenResponse.getCandidateID(),userTokenResponse.getFirstname(),userTokenResponse.getLastname(),userTokenResponse.getEmailId());
    Assert.assertEquals(enrollmentDBValidations.returnCandidateAssessmentCount(userTokenResponse.getCandidateID()), 0);
  }

  @XrayTest(key = "VS-187", summary = "TC_Vision_Enrollment_for_New_Job", description = "Candidate Enrollment for new Job", labels = "E2E")
  @Test(groups = {"smoke"}, description = "Enrollment API response and DB validation for Same candidate with different job ID", retryAnalyzer = RetryAnalyzer.class)
  public void TC02_Vision_Candidate_Enrollment_for_different_job() throws JsonProcessingException {
    String enrollmentRequest = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(enrollmentFullRequest.enrollmentRequest(
        rightImage,
        leftImage,
        frontImage,
        VisionConstants.JOBID2,
        VisionConstants.JobName2,
        userTokenResponse
    ));
    Response response = visionHelper.EnrollmentHelper(enrollmentRequest.trim(),Token);
    Assert.assertEquals(response.getStatusCode(),201);
    enrollmentResponseValidations.EnrollmentStandardResponseValidation(response,EmailId);
    enrollmentDBValidations.EnrollmentEmployeeTableValidation(EmailId,userTokenResponse.getCandidateID(),userTokenResponse.getFirstname(),userTokenResponse.getLastname());
    enrollmentDBValidations.EnrollmentSystemEnvironmentTableValidation(userTokenResponse.getCandidateID());
    enrollmentDBValidations.EnrollmentImagebagTableValidation(userTokenResponse.getCandidateID());
    enrollmentDBValidations.EnrollmentAgentEnrollmentTableValidation(userTokenResponse.getCandidateID(),EmailId);
    enrollmentDBValidations.EnrollmentJOBIDsInJobDetailsTableValidation(userTokenResponse.getCandidateID());
    enrollmentDBValidations.EnrollmentImageEmbaddingsCountValidation(userTokenResponse.getCandidateID());
    enrollmentDBValidations.EnrollmentCandidateAdditionalInformationValidation(userTokenResponse.getCandidateID(),userTokenResponse.getFirstname(),userTokenResponse.getLastname(),userTokenResponse.getEmailId());
    Assert.assertEquals(enrollmentDBValidations.returnCandidateAssessmentCount(userTokenResponse.getCandidateID()), 0);
  }

  @XrayTest(key = "VS-141", summary = "TC_Vision_ReEnrollment_of_Same_Candidate", description = "Candidate ReEnrollment in the portal", labels = "E2E")
  @Test( description = "ReEnrollment API response and DB validation for Same candidate", retryAnalyzer = RetryAnalyzer.class)
  public void TC03_Vision_Candidate_ReEnrollment() throws JsonProcessingException{
    String enrollmentRequest = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(enrollmentFullRequest.enrollmentRequest(
        rightImage,
        leftImage,
        frontImage,
        VisionConstants.JOBID1,
        VisionConstants.JobName1,
        userTokenResponse
    ));
    Response response = visionHelper.EnrollmentHelper(enrollmentRequest.trim(),Token);
    Assert.assertEquals(response.getStatusCode(),201);
    enrollmentResponseValidations.EnrollmentStandardResponseValidation(response,EmailId);
    enrollmentDBValidations.EnrollmentEmployeeTableValidation(EmailId,userTokenResponse.getCandidateID(),userTokenResponse.getFirstname(),userTokenResponse.getLastname());
    enrollmentDBValidations.EnrollmentSystemEnvironmentTableValidation(userTokenResponse.getCandidateID());
    enrollmentDBValidations.EnrollmentImagebagTableValidation(userTokenResponse.getCandidateID());
    enrollmentDBValidations.EnrollmentAgentEnrollmentTableValidation(userTokenResponse.getCandidateID(),EmailId);
    enrollmentDBValidations.EnrollmentJOBIDsInJobDetailsTableValidation(userTokenResponse.getCandidateID());
    enrollmentDBValidations.EnrollmentImageEmbaddingsCountValidation(userTokenResponse.getCandidateID());
    enrollmentDBValidations.EnrollmentCandidateAdditionalInformationValidation(userTokenResponse.getCandidateID(),userTokenResponse.getFirstname(),userTokenResponse.getLastname(),userTokenResponse.getEmailId());
    Assert.assertEquals(enrollmentDBValidations.returnCandidateAssessmentCount(userTokenResponse.getCandidateID()), 0);
  }

  @Test
  public void TC04_Vision_workday_Candidate_Enrollment() throws JsonProcessingException {
    Response TokenResponse = visionHelper.TokenHelper(ConfigurationFileHelper.getInstance().getWorkdayEmailID());
    VisionStandardResponse standardResponse = TokenResponse.as(VisionStandardResponse.class);
    TokenDataResponse tokenDataResponse = objectMapper.readValue(standardResponse.getData(), TokenDataResponse.class);
    String token = tokenDataResponse.getAccessToken();
    UserTokenResponse UserTokenResponse = objectMapper.readValue(decodeString(tokenDataResponse.getUserToken()),UserTokenResponse.class);
    String enrollmentRequest = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(enrollmentFullRequest.enrollmentRequest(
        rightImage,
        leftImage,
        frontImage,
        UserTokenResponse.getJobid(),
        UserTokenResponse.getJobname(),
        UserTokenResponse
    ));
    Response response = visionHelper.EnrollmentHelper(enrollmentRequest.trim(),token);
    Assert.assertEquals(response.getStatusCode(),201);
    workdDayemailID = UserTokenResponse.getEmailId();
    workdayCandidateID= UserTokenResponse.getCandidateID();
    enrollmentResponseValidations.EnrollmentStandardResponseValidation(response,workdDayemailID);
    enrollmentDBValidations.EnrollmentEmployeeTableValidation(workdDayemailID,workdayCandidateID,UserTokenResponse.getFirstname(),UserTokenResponse.getLastname());
    enrollmentDBValidations.EnrollmentSystemEnvironmentTableValidation(workdayCandidateID);
    enrollmentDBValidations.EnrollmentImagebagTableValidation(workdayCandidateID);
    enrollmentDBValidations.EnrollmentAgentEnrollmentTableValidation(workdayCandidateID,workdDayemailID);
    enrollmentDBValidations.EnrollmentSingleJOBIDInJobDetailsTableValidation(workdayCandidateID,UserTokenResponse.getJobid());
    enrollmentDBValidations.EnrollmentImageEmbaddingsCountValidation(workdayCandidateID);
    enrollmentDBValidations.EnrollmentCandidateAdditionalInformationValidation(workdayCandidateID,UserTokenResponse.getFirstname(),UserTokenResponse.getLastname(),workdDayemailID);
    Assert.assertTrue(enrollmentDBValidations.returnCandidateAssessmentCount(workdayCandidateID)>0);

  }
  @XrayTest(key = "VS-142", summary = "TC_Vision_Enrollment_invalid_token", description = "401 unauthorized message should come for invalid token", labels = "E2E")
  @Test( description = "401 unauthorized message should come for invalid token", retryAnalyzer = RetryAnalyzer.class)
  public void TC05_Vision_Candidate_Enrollment_invalid_token() throws JsonProcessingException{
    String enrollmentRequest = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(enrollmentFullRequest.enrollmentRequest(
        rightImage,
        leftImage,
        frontImage,
        VisionConstants.JOBID2,
        VisionConstants.JobName2,
        userTokenResponse
    ));
    Response response = visionHelper.EnrollmentHelper(enrollmentRequest.trim(),Token+"1");
    Assert.assertEquals(response.getStatusCode(),401);
    Assert.assertEquals(response.asPrettyString(),VisionConstants.INVALIDTOKEN);
  }

  @XrayTest(key = "VS-143", summary = "TC_Vision_Enrollment_invalid_user", description = "401 unauthorized message should come for invalid user", labels = "E2E")
  @Test( description = "401 unauthorized message should come for invalid user", retryAnalyzer = RetryAnalyzer.class)
  public void TC06_Vision_Candidate_Enrollment_invalid_user() throws JsonProcessingException{
    String enrollmentRequest = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(enrollmentFullRequest.enrollmentRequest(
        rightImage,
        leftImage,
        frontImage,
        VisionConstants.JOBID2,
        VisionConstants.JobName2,
        userTokenResponse
    ));
    Response response = visionHelper.EnrollmentHelper(enrollmentRequest.trim(),Token);
    Assert.assertEquals(response.getStatusCode(),401);
    Assert.assertEquals(response.asPrettyString(),VisionConstants.INVLAIDUSER);
  }

  @XrayTest(key = "VS-144", summary = "TC_Vision_Enrollment_no_token", description = "401 unauthorized message should come for no token", labels = "E2E")
  @Test( description = "401 unauthorized message should come for no token", retryAnalyzer = RetryAnalyzer.class)
  public void TC07_Vision_Candidate_Enrollment_no_token() throws JsonProcessingException{
    String enrollmentRequest = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(enrollmentFullRequest.enrollmentRequest(
        rightImage,
        leftImage,
        frontImage,
        VisionConstants.JOBID2,
        VisionConstants.JobName2,
        userTokenResponse
    ));
    Response response = visionHelper.EnrollmentHelper(enrollmentRequest.trim(),"");
    Assert.assertEquals(response.getStatusCode(),401);
    Assert.assertEquals(response.asPrettyString(),VisionConstants.NOTOKENFOUND);
  }

  @Test( description = "delete the workday user enrollment")
  public void TC08_Vision_delete_workday_Candidate_Enrollment() {
    enrollmentDBValidations.EnrollmentdetailsDeletions(String.format(VisionQueries.DELETE_ENROLLMENT_EMPLOYEE_QUERY,env,workdDayemailID));
    enrollmentDBValidations.EnrollmentdetailsDeletions(String.format(VisionQueries.DELETE_ENROLLMENT_SYSTEMENVIRONMENT_QUERY,env,workdayCandidateID));
    enrollmentDBValidations.EnrollmentdetailsDeletions(String.format(VisionQueries.DELETE_ENROLLMENT_IMAGEBAG_QUERY,env,workdayCandidateID));
    enrollmentDBValidations.EnrollmentdetailsDeletions(String.format(VisionQueries.DELETE_ENROLLMENT_AGENTENROLLMENT_QUERY,env,workdDayemailID));
    enrollmentDBValidations.EnrollmentdetailsDeletions(String.format(VisionQueries.DELETE_ENROLLMENT_CANDIDATE_ADDITIONAL_INFORMATION,env,workdDayemailID));
    enrollmentDBValidations.EnrollmentdetailsDeletions(String.format(VisionQueries.DELETE_ENROLLMENT_JOBDETAILS_QUERY,env,workdayCandidateID));
    enrollmentDBValidations.EnrollmentdetailsDeletions(String.format(VisionQueries.DELETE_ENROLLMENT_CANDIDATE_ASSESSMENT_QUERY,env,workdayCandidateID));
    enrollmentDBValidations.EnrollmentdetailsDeletions(String.format(VisionQueries.DELETE_ENORLLMENT_IMAGEEMBADDINGS_QUERY,env,workdayCandidateID));


  }
}
