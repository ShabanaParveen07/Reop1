package com.concentrix.suites.Vision.validations;

import com.concentrix.automation.helper.DBConnectionHelper;
import com.concentrix.automation.service.vision.constants.VisionConstants;
import com.concentrix.suites.Vision.testData.VisionQueries;
import org.testng.Assert;

import java.sql.ResultSet;
import java.sql.SQLException;

public class EnrollmentDBValidations {
  DBConnectionHelper dbConnectionHelper;
  String env;
  public String empid;
  public String systemEnvironmentID;

  public EnrollmentDBValidations(DBConnectionHelper dbConnectionHelper, String env){
    this.dbConnectionHelper = dbConnectionHelper;
    this.env = env;
  }
  public void EnrollmentEmployeeTableValidation(String emailId, String CandidateId, String firstName, String lastName) {
   try {
     ResultSet rs = dbConnectionHelper.executeQuery(String.format(VisionQueries.ENROLLMENT_EMPLOYEE_QUERY, env, emailId));
     int count = 0;
     while (rs.next()) {
       Assert.assertEquals(rs.getString(VisionConstants.LANID), emailId);
       Assert.assertEquals(rs.getString(VisionConstants.EMAILADDR), emailId);
       Assert.assertEquals(rs.getString(VisionConstants.EMPLOYEEID), CandidateId);
       Assert.assertEquals(rs.getString(VisionConstants.DBFIRSTNAME), firstName);
       Assert.assertEquals(rs.getString(VisionConstants.DBLASTNAME),lastName );
       empid = rs.getString(VisionConstants.EMPID);
       count++;
     }
     Assert.assertEquals(count, 1);
   }
   catch (SQLException e){
     throw new RuntimeException(e);
   }
  }

  public void EnrollmentSystemEnvironmentTableValidation(String CandidateID) {
    try {
    ResultSet rs = dbConnectionHelper.executeQuery(String.format(VisionQueries.ENROLLMENT_SYSTEMENVIRONMENT_QUERY,env,CandidateID));
    int count =0;
    while (rs.next()){
       Assert.assertEquals(rs.getString(VisionConstants.EMPLOYEEID),CandidateID);
       Assert.assertEquals(rs.getString(VisionConstants.EMPID),empid);
       systemEnvironmentID = rs.getString(VisionConstants.SYSTEMENVIRONMENTID);
       count++;
    }
    Assert.assertEquals(count,1);
    }
    catch (SQLException e){
      throw new RuntimeException(e);
    }
  }
  public void EnrollmentImagebagTableValidation(String CandidateID) {
    try {
      ResultSet rs = dbConnectionHelper.executeQuery(String.format(VisionQueries.ENROLLMENT_IMAGEBAG_QUERY,env,CandidateID));
      int count =0;
      while (rs.next()){
        Assert.assertEquals(rs.getString(VisionConstants.EMPLOYEEID),CandidateID);
        Assert.assertEquals(rs.getString(VisionConstants.EMPID),empid);
        Assert.assertEquals(rs.getString(VisionConstants.SYSTEMENVIRONMENTID),systemEnvironmentID);
        String ImageProfile = rs.getString(VisionConstants.IMAGEPROFILE);
        Assert.assertTrue(ImageProfile.equals("R") || ImageProfile.equals("L")||ImageProfile.equals("F"));
        count++;
      }
      Assert.assertEquals(count,3);
    }
    catch (SQLException e){
      throw new RuntimeException(e);
    }
  }

  public void EnrollmentAgentEnrollmentTableValidation(String CandidateID,String emailID) {
    try {
      ResultSet rs = dbConnectionHelper.executeQuery(String.format(VisionQueries.ENROLLMENT_AGENTENROLLMENT_QUERY,env,CandidateID));
      int count =0;
      while (rs.next()){
        Assert.assertEquals(rs.getString(VisionConstants.EMPLOYEEID),CandidateID);
        Assert.assertEquals(rs.getString(VisionConstants.LANID),emailID);
        Assert.assertEquals(rs.getString(VisionConstants.ENROLLMENTACTION),VisionConstants.APPROVE);
        Assert.assertEquals(rs.getString(VisionConstants.ENROLLMENTACTIONBY),VisionConstants.SYSTEMAUTOAPPROVE);
        Assert.assertEquals(rs.getString(VisionConstants.REMARKS),VisionConstants.SYSTEMAUTOAPPROVE);
        Assert.assertEquals(rs.getString(VisionConstants.ENROLLMENTFALG),"E");
        count++;
      }
      Assert.assertEquals(count,1);
    }
    catch (SQLException e){
      throw new RuntimeException(e);
    }
  }

  public void EnrollmentSingleJOBIDInJobDetailsTableValidation(String CandidateID,String JobId) {
    try {
      ResultSet rs = dbConnectionHelper.executeQuery(String.format(VisionQueries.ENROLLMENT_JOBDETAILS_QUERY,env,CandidateID));
      int count =0;
      while (rs.next()){
        Assert.assertEquals(rs.getString(VisionConstants.EMPLOYEEID),CandidateID);
        Assert.assertEquals(rs.getString(VisionConstants.DBJOBID),JobId);
        count++;
      }
      Assert.assertEquals(count,1);
    }
    catch (SQLException e){
      throw new RuntimeException(e);
    }
  }
  public void EnrollmentJOBIDsInJobDetailsTableValidation(String CandidateID) {
    try {
      ResultSet rs = dbConnectionHelper.executeQuery(String.format(VisionQueries.ENROLLMENT_JOBDETAILS_QUERY,env,CandidateID));
      int count =0;
      while (rs.next()){
        Assert.assertEquals(rs.getString(VisionConstants.EMPLOYEEID),CandidateID);
        String JOBID= rs.getString(VisionConstants.DBJOBID);
        Assert.assertTrue(JOBID.equals(VisionConstants.JOBID1)|| JOBID.equals(VisionConstants.JOBID2));
        count++;
      }
      Assert.assertEquals(count,2);
    }
    catch (SQLException e){
      throw new RuntimeException(e);
    }
  }
  public void EnrollmentImageEmbaddingsCountValidation(String CandidateID) {
    try {
      ResultSet rs = dbConnectionHelper.executeQuery(String.format(VisionQueries.ENORLLMENT_IMAGEEMBADDINGS_COUNT_QUERY,env,CandidateID));
      while (rs.next()){
        Assert.assertEquals(rs.getInt(VisionConstants.COUNT),1);
      }

    }
    catch (SQLException e){
      throw new RuntimeException(e);
    }
  }

  public void EnrollmentCandidateAdditionalInformationValidation(String CandidateID,String firstName,String LastName, String email) {
    int count =0;
    try {
      ResultSet rs = dbConnectionHelper.executeQuery(String.format(VisionQueries.ENROLLMENT_CANDIDATE_ADDITIONALINFORMATION_QUERY,env,email));
      while (rs.next()){
        Assert.assertEquals(rs.getString(VisionConstants.EMPLOYEEID),CandidateID);
        Assert.assertEquals(rs.getString(VisionConstants.DBFIRSTNAME),firstName);
        Assert.assertEquals(rs.getString(VisionConstants.DBLASTNAME),LastName);
        Assert.assertEquals(rs.getString(VisionConstants.EMAILADDR),email);
        count++;
      }
     Assert.assertEquals(count,1);
    }
    catch (SQLException e){
      throw new RuntimeException(e);
    }
  }

  public int returnCandidateAssessmentCount(String CandidateID) {
    int count =0;
    try {
      ResultSet rs = dbConnectionHelper.executeQuery(String.format(VisionQueries.ENROLLMENT_CANDIDATE_ASSESSMENT_COUNT_QUERY,env,CandidateID));
      while (rs.next()){
       count = rs.getInt(VisionConstants.COUNT);
      }

    }
    catch (SQLException e){
      throw new RuntimeException(e);
    }
    return count;
  }

  public void EnrollmentdetailsDeletions(String Query) {
    try {
      int value = dbConnectionHelper.executeUpdateQuery(Query);
      System.out.println(value);
      Assert.assertTrue(value>=0);
    }
    catch (Exception e){
      throw new RuntimeException(e);
    }
  }
}
