package com.concentrix.suites.Vision.validations;

import com.concentrix.automation.service.vision.pojo.response.UserTokenResponse;
import org.testng.Assert;

public class TokenApiResponseValidations {

  public void TokenApiUserTokenValidation(UserTokenResponse userTokenResponse,String emailId ,Boolean isEnrolled){
    Assert.assertEquals(userTokenResponse.getEmailId(),emailId);
    Assert.assertNotNull(userTokenResponse.getCandidateID());
    Assert.assertNotNull(userTokenResponse.getLocation());
    Assert.assertNotNull(userTokenResponse.getFirstname());
    Assert.assertNotNull(userTokenResponse.getLastname());
    Assert.assertNotNull(userTokenResponse.getJobid());
    Assert.assertNotNull(userTokenResponse.getJobname());
    Assert.assertNotNull(userTokenResponse.getLanguage());
    Assert.assertEquals(userTokenResponse.getIsenrolled(),isEnrolled);
  }
}
