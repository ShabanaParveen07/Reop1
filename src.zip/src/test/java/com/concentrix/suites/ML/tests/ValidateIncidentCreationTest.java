package com.concentrix.suites.ML.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.BaseTests.MLBaseTest;
import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.helper.DBConnectionHelper;
import com.concentrix.automation.helper.GCSHelper;
import com.concentrix.automation.service.streaming.pojo.request.TestData;
import com.concentrix.automation.service.streaming.pojo.response.GetLastImageProcessedStatusResponse;
import com.concentrix.suites.ML.testdata.MLDataProvider;
import io.restassured.response.Response;
import lombok.extern.log4j.Log4j;
import org.testng.Assert;
import org.testng.annotations.*;

import java.io.File;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

@Listeners({app.getxray.xray.testng.listeners.XrayListener.class})
@Log4j
public class ValidateIncidentCreationTest extends MLBaseTest {
  private DBConnectionHelper dbConnectionHelper;

  public static String objectKey;

  @BeforeMethod(alwaysRun = true)
  public void postBaseLineImage() throws InterruptedException {
    postBaseLineImageToStreaming();
    dbConnectionHelper = DBConnectionHelper.getInstance();
  }

  @XrayTest(key = "ORN-6316", summary = "validateIncidentTest", description = "Validate incidents getting created in incident table", labels = "E2E")
  @Test(groups = {"smoke"}, description = "Validate incidents getting created in incident table", dataProviderClass = MLDataProvider.class, dataProvider = "getViolationData")
  public void validateIncidentTest(TestData testData) throws InterruptedException {
    log.info(testData);
    String imageFilePath = System.getProperty("user.dir") + File.separator + "src" + File.separator + "test" + File.separator + "resources" + File.separator + "ML" + File.separator;
    imageFilePath = imageFilePath + testData.getFilePath();
    String envName = System.getProperty("env");
    if (envName == null)
      envName = "qa";
    Response response;
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + File.separator + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    File file = new File(imageFilePath + File.separator + testData.getFileName());
    response = executeMlAPIs(file);
    assertResponseData(response, testData.getResultId());
    GetLastImageProcessedStatusResponse getLastImageProcessedStatusResponse = response.getBody().as(
        GetLastImageProcessedStatusResponse.class);
    String imagePathId = getLastImageProcessedStatusResponse.getImageCacheKey();
    Thread.sleep(10000);
    try {
      ResultSet rs1 = dbConnectionHelper.executeQuery("SELECT * from fb_biometrics_" + envName + ".imageprocess_status where imagePath in ('" + imagePathId + "')");
      Assert.assertTrue(rs1.isBeforeFirst(), "image process ResultSet is empty");
      while (rs1.next()) {
        String authModeValue = rs1.getString("FaceAuthMode");
        log.info("AuthModeValue is: " + authModeValue);
        if (authModeValue.equals("99")) {
          log.info(rs1.getString("violations"));
          Assert.assertNotNull(rs1.getString("violations"));
        } else {
          ResultSet rs = dbConnectionHelper.executeQuery("SELECT * from fb_enrollment_" + envName + ".Incident where imagePath in ('" + imagePathId + "')");
          Assert.assertTrue(rs.isBeforeFirst(), "Incident ResultSet is empty");
          while (rs.next()) {
            log.info(rs.getString(1) + "  " + rs.getString(2) + "  " + rs.getString(3) + "  " + rs.getString(4));
            Assert.assertNotNull(rs.getString(1));
          }
          rs.close();
        }
      }
      rs1.close();
    } catch (Exception e) {
      System.out.println(e.getMessage());
    }

  }

  @AfterClass
  public void TearDown() throws SQLException {
    dbConnectionHelper.closeConnection();
  }
}
