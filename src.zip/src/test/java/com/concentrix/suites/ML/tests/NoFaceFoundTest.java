package com.concentrix.suites.ML.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.BaseTests.MLBaseTest;
import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.helper.GCSHelper;
import com.concentrix.automation.service.streaming.constants.EndPointConstants;
import com.concentrix.automation.service.streaming.pojo.request.TestData;
import com.concentrix.suites.ML.testdata.MLDataProvider;
import io.restassured.response.Response;
import lombok.extern.log4j.Log4j;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;

@Listeners({app.getxray.xray.testng.listeners.XrayListener.class})
@Log4j
public class NoFaceFoundTest extends MLBaseTest {

  private final String imageFilePath = System.getProperty("user.dir") + File.separator + "src" + File.separator + "test" + File.separator + "resources" + File.separator + "ML" + File.separator + "No_Face_Found" + File.separator;
  private int tpCount, fnCount, tnCount, fpCount = 0;
  int resultId = 0;

  public static String objectKey;
  private String imagePathId;

  @XrayTest(key = "ORN-4622", summary = "No Face Found True Positives Test", description = "Testing of No face found violations with pre-defined TP dataset", labels = "E2E")
  @Test(description = "Testing of noFaceFound violations with pre-defined TP dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getNoFaceFoundTP")
  public void noFaceFound_TPTest(TestData testData) {
    log.info(testData);
    Response response;
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "TP/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "TP" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    File file = new File(imageFilePath + "TP" + File.separator + testData.getFileName());
    response = executeMlAPIs(file);
    //Check response status is not 204
    if (response.getStatusCode() == 204)
      resultId = 0;
    else {
      resultId = response.path("result_id");
      imagePathId = response.path("imagecachekey");
    }
    assertResponseData(response, EndPointConstants.noFacesFoundResultId);
  }

  @XrayTest(key = "ORN-4623", summary = "No Face Found True Negatives Test", description = "Testing of No face found violations with pre-defined TN dataset", labels = "E2E")
  @Test(description = "Testing of noFaceFound violations with pre-defined TN dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getNoFaceFoundTN")
  public void noFaceFound_TNTest(TestData testData) {
    log.info(testData);
    Response response;
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "TN/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "TN" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    File file = new File(imageFilePath + "TN" + File.separator + testData.getFileName());
    response = executeMlAPIs(file);
    //Check response status is not 204
    if (response.getStatusCode() == 204)
      resultId = 0;
    else {
      resultId = response.path("result_id");
      imagePathId = response.path("imagecachekey");
    }
    assertResponseData(response, EndPointConstants.successResultId);
  }

  @AfterMethod
  public void status(ITestResult result, ITestContext context) {
    log.info("Status of execution is:" + result.getStatus());
    String fileName = getTestName(result);
    try {
      if ("noFaceFound_TPTest".equals(result.getName()) && result.getStatus() == ITestResult.SUCCESS) {
        log.info("Test case execution status is SUCCESS");
        File file = new File(imageFilePath + "TP" + File.separator + fileName);
        writeImageToPath(file, false);
        tpCount++;
      } else if ("noFaceFound_TPTest".equals(result.getName()) && result.getStatus() == ITestResult.FAILURE) {
        File file = new File(imageFilePath + "TP" + File.separator + fileName);
        writeImageToPath(file, true);
        saveActualResult(fileName, resultId, "noFaceFound_TPTest", String.valueOf(EndPointConstants.noFacesFoundResultId), imageFilePath + "TP" + File.separator + fileName, imagePathId);
        log.info("Test case execution status is FAILURE");
        fnCount++;
      } else if ("noFaceFound_TNTest".equals(result.getName()) && result.getStatus() == ITestResult.SUCCESS) {
        File file = new File(imageFilePath + "TP" + File.separator + fileName);
        writeImageToPath(file, false);
        tnCount++;
      } else if ("noFaceFound_TNTest".equals(result.getName()) && result.getStatus() == ITestResult.FAILURE) {
        log.info("Test case execution status is FAILURE");
        File file = new File(imageFilePath + "TN" + File.separator + fileName);
        writeImageToPath(file, true);
        saveActualResult(fileName, resultId, "noFaceFound_TNTest", String.valueOf(EndPointConstants.successResultId), imageFilePath + "TN" + File.separator + fileName, imagePathId);
        fpCount++;
      } else if (result.getStatus() == ITestResult.SKIP) {
        log.info("Test case execution status is SKIP");
      }
      context.setAttribute("noFaceFound", true);
      context.setAttribute("noFaceFound_TP", tpCount);
      context.setAttribute("noFaceFound_FN", fnCount);
      context.setAttribute("noFaceFound_TN", tnCount);
      context.setAttribute("noFaceFound_FP", fpCount);
      context.setAttribute("resultList", list);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
