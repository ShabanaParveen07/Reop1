package com.concentrix.suites.ML.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.BaseTests.MLBaseTest;
import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.helper.GCSHelper;
import com.concentrix.automation.helper.streaming.StreamingApiHelper;
import com.concentrix.automation.service.streaming.constants.EndPointConstants;
import com.concentrix.automation.service.streaming.pojo.request.TestData;
import com.concentrix.suites.ML.testdata.MLDataProvider;
import io.restassured.response.Response;
import lombok.extern.log4j.Log4j;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.net.UnknownHostException;

@Listeners({app.getxray.xray.testng.listeners.XrayListener.class})
@Log4j
public class SpoofImageFaceStreamingTest extends MLBaseTest {

  private String imageFilePath;
  private int tpCount = 0;
  private int fnCount = 0;
  private int tnCount = 0;
  private int fpCount = 0;
  private String authToken1;
  private String authToken2;
  private String authToken3;
  String lanId1 = "orion.test@concentrix.com";
  String lanId2 = "sumit.agrawal1@concentrix.com";
  String lanId3 = "aishwarya.vatsa@concentrix.com";
  int resultId = 0;
  StreamingApiHelper streamingApiHelper;
  double spoofScore = 0;
  public static String objectKey;
  private String imagePathId;

  @BeforeClass(alwaysRun = true)
  public void getAuthToken() throws UnknownHostException {
    streamingApiHelper = new StreamingApiHelper();
     authToken1 = generateAuthToken(lanId1);
    streamingApiHelper.refreshFaceStreaming(lanId2);
    streamingApiHelper.getCheckBaseValidation(lanId2);
    authToken2 = generateAuthToken(lanId2);
    streamingApiHelper.refreshFaceStreaming(lanId3);
    streamingApiHelper.getCheckBaseValidation(lanId3);
      authToken3 = generateAuthToken(lanId3);
  }

  @XrayTest(key = "ORN-4140", summary = "Spoof Images positive Test", description = "Testing of spoof images with pre-defined TP dataset", labels = "E2E")
  @Test(description = "Testing of spoof images with pre-defined TP dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getSpoofImageTP")
  public void spoofTPTest(TestData testData) throws InterruptedException {
    log.info("Test Data: " + testData);
    imageFilePath = "src/test/resources/ML/spoofImages/";
    Response response;
    // String path = imageFilePath + "TP/" + testData.getFileName();
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "TP/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "TP" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    File file = new File(imageFilePath + "TP/" + testData.getFileName());
    response = executeMlAPIsForSpoof(file,authToken1,lanId1);
    if (response != null) {
      log.info(response);
      resultId = response.path("result_id");
    } else
      resultId = 0;
    assertResponseData(response, EndPointConstants.spoofResultId);
  }

  @XrayTest(key = "ORN-4140", summary = "Spoof Images positive Test", description = "Testing of spoof images with pre-defined TP dataset", labels = "E2E")
  @Test(description = "Testing of spoof images with pre-defined TP dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getSpoofImage2TP")
  public void spoofTPTest2(TestData testData) throws InterruptedException {
    log.info("Test Data: " + testData);
    imageFilePath = "src/test/resources/ML/spoofImagesSumit/";
    Response response;
    // String path = imageFilePath + "TP/" + testData.getFileName();
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "TP/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "TP" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    File file = new File(imageFilePath + "TP/" + testData.getFileName());
    response = executeMlAPIsForSpoof(file,authToken2,lanId2);
    if (response != null) {
      log.info(response);
      resultId = response.path("result_id");
    } else
      resultId = 0;
    assertResponseData(response, EndPointConstants.spoofResultId);
  }

  @XrayTest(key = "ORN-4140", summary = "Spoof Images positive Test", description = "Testing of spoof images with pre-defined TP dataset", labels = "E2E")
  @Test(description = "Testing of spoof images with pre-defined TP dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getSpoofImage3TP")
  public void spoofTPTest3(TestData testData) throws InterruptedException {
    log.info("Test Data: " + testData);
    imageFilePath = "src/test/resources/ML/spoofImagesAishwarya/";
    Response response;
    // String path = imageFilePath + "TP/" + testData.getFileName();
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "TP/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "TP" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    File file = new File(imageFilePath + "TP/" + testData.getFileName());
    response = executeMlAPIsForSpoof(file,authToken3,lanId3);
    if (response != null) {
      log.info(response);
      resultId = response.path("result_id");
    } else
      resultId = 0;
    assertResponseData(response, EndPointConstants.spoofResultId);
  }


  @XrayTest(key = "ORN-4141", summary = "Spoof Images negative Test", description = "Testing of spoof images with pre-defined TN dataset", labels = "E2E")
  @Test(description = "Testing of spoof images with pre-defined TN dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getSpoofImageTN")
  public void spoofTNTest(TestData testData) throws InterruptedException {
    log.info("Test Data: " + testData);
    imageFilePath = "src/test/resources/ML/spoofImages/";
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "TN/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "TN" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    Response response;
    File file = new File(imageFilePath + "TN/" + testData.getFileName());
    response = executeMlAPIsForSpoof(file,authToken1,lanId1);
    if (response != null) {
      log.info(response);
      resultId = response.path("result_id");
      // will enable once changes deployed to UAT/PT
      //spoofScore = responseResult.spoofScore;
    } else
      resultId = 0;
    assertResponseData(response, EndPointConstants.successResultId);
  }

  @XrayTest(key = "ORN-4141", summary = "Spoof Images negative Test", description = "Testing of spoof images with pre-defined TN dataset", labels = "E2E")
  @Test(description = "Testing of spoof images with pre-defined TN dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getSpoofImage2TN")
  public void spoofTNTest2(TestData testData) throws InterruptedException {
    log.info("Test Data: " + testData);
    imageFilePath = "src/test/resources/ML/spoofImagesSumit/";
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "TN/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "TN" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    Response response;
    File file = new File(imageFilePath + "TN/" + testData.getFileName());
    response = executeMlAPIsForSpoof(file,authToken2,lanId2);
    if (response != null) {
      log.info(response);
      resultId = response.path("result_id");
      imagePathId = response.path("imagecachekey");
    } else
      resultId = 0;
    assertResponseData(response, EndPointConstants.successResultId);
  }

  @XrayTest(key = "ORN-4141", summary = "Spoof Images negative Test", description = "Testing of spoof images with pre-defined TN dataset", labels = "E2E")
  @Test(description = "Testing of spoof images with pre-defined TN dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getSpoofImage3TN")
  public void spoofTNTest3(TestData testData) throws InterruptedException {
    log.info("Test Data: " + testData);
    imageFilePath = "src/test/resources/ML/spoofImagesAishwarya/";
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "TN/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "TN" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    Response response;
    File file = new File(imageFilePath + "TN/" + testData.getFileName());
    response = executeMlAPIsForSpoof(file,authToken3,lanId3);
    if (response != null) {
      log.info(response);
      resultId = response.path("result_id");
      imagePathId = response.path("imagecachekey");
    } else
      resultId = 0;
    assertResponseData(response, EndPointConstants.successResultId);
  }

  @AfterMethod
  public void status(ITestResult result, ITestContext context) {
    String fileName = getTestName(result);
    log.info("Status of execution is:" + result.getStatus());
    try {
      if (("spoofTPTest".equals(result.getName()) || "spoofTPTest2".equals(result.getName()) || "spoofTPTest3".equals(result.getName())) && result.getStatus() == ITestResult.SUCCESS) {
        log.info("Test case execution status is SUCCESS");
        File file = new File(imageFilePath + "TP/" + fileName);
        writeImageToPath(file, false);
        tpCount++;
      } else if (("spoofTPTest".equals(result.getName()) || "spoofTPTest2".equals(result.getName()) || "spoofTPTest3".equals(result.getName())) && result.getStatus() == ITestResult.FAILURE) {
        log.info("Test case execution status is FAILURE");
        File file = new File(imageFilePath + "TP/" + fileName);
        writeImageToPath(file, true);
        saveActualResult(fileName, resultId, spoofScore, "spoofTPTest", String.valueOf(EndPointConstants.spoofResultId), imageFilePath + "TP/" + fileName);
        //saveActualResult(fileName, resultId, "spoofTPTest", String.valueOf(EndPointConstants.spoofResultId), imageFilePath + "TP/" + fileName);
        fnCount++;
      } else if (("spoofTNTest".equals(result.getName()) || "spoofTNTest2".equals(result.getName()) || "spoofTNTest3".equals(result.getName())) && result.getStatus() == ITestResult.SUCCESS) {
        File file = new File(imageFilePath + "TN/" + fileName);
        writeImageToPath(file, false);
        saveActualResult(fileName, resultId, "spoofTNTest", String.valueOf(EndPointConstants.successResultId), imageFilePath + "TN" + File.separator + fileName,imagePathId);
        tnCount++;
      } else if (("spoofTNTest".equals(result.getName()) || "spoofTNTest2".equals(result.getName()) || "spoofTNTest3".equals(result.getName())) && result.getStatus() == ITestResult.FAILURE) {
        log.info("Test case execution status is FAILURE");
        File file = new File(imageFilePath + "TN/" + fileName);
        writeImageToPath(file, true);
       // saveActualResult(fileName, resultId, spoofScore, "spoofTNTest", String.valueOf(EndPointConstants.successResultId), imageFilePath + "TN/" + fileName);
        //saveActualResult(fileName, resultId, "spoofTNTest", String.valueOf(EndPointConstants.spoofResultId), imageFilePath + "TN/" + fileName);
        saveActualResult(fileName, resultId, "spoofTNTest", String.valueOf(EndPointConstants.successResultId), imageFilePath + "TN" + File.separator + fileName,imagePathId);
        fpCount++;
      } else if (result.getStatus() == ITestResult.SKIP) {
        log.info("Test case execution status is SKIP");
      }

      context.setAttribute("spoofTP", tpCount);
      context.setAttribute("spoofFN", fnCount);
      context.setAttribute("spoofTN", tnCount);
      context.setAttribute("spoofFP", fpCount);
      context.setAttribute("resultList", list);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

}
