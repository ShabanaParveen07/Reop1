package com.concentrix.suites.ML.tests;

import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.helper.EncryptDecryptHelper;
import com.concentrix.automation.helper.FileHelper;
import com.concentrix.automation.helper.pii.PiiApiHelper;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.response.Response;
import lombok.extern.log4j.Log4j;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;

@Log4j
public class PiiApiTest {
  private final String key = ConfigurationFileHelper.getInstance().getEncryptionKey();
  private final String piiDataFilePath = System.getProperty("user.dir") + File.separator + "src" + File.separator + "test" + File.separator + "resources" + File.separator + "ML" + File.separator + "pii" + File.separator;
  PiiApiHelper piiApiHelper;
  private String testName;

  @BeforeClass(alwaysRun = true)
  public void setUp() {
    piiApiHelper = new PiiApiHelper();
    //Deleting PII results folder
    FileHelper.deleteDirectory("test-output/Actual Results/");
  }

  @BeforeMethod
  public void name(Method method) {
    log.info("Test name: " + method.getName());
    testName = method.getName();
  }

  @Test(description = "Test pii anonymization api with test data scenario1")
  public void Pii_scenario_01() throws Exception {
    String inputData = readFile(piiDataFilePath + "scenario1.txt");
    String encodedOutput = EncryptDecryptHelper.encryptString(inputData, key);
    log.info("Data: " + encodedOutput);
    Response response = piiApiHelper.piiApiV1(encodedOutput);
    Assert.assertEquals(response.getStatusCode(), 200);
    log.info("API response:" + response.getBody().prettyPrint());
    String resData = response.getBody().asString().replace("\"", "");
    String decodedOutput = EncryptDecryptHelper.decryptString(resData, key);
    log.info("Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'Birthdate','values':['06/01/1990']},{'piiDataType':'Credit card number','values':['3759-876543-21001','4539-0031-3703-0732','5527-1247-5046-7784']},{'piiDataType':'Email','values':['sumit444agrawal@gmail.com']},{'piiDataType':'Passport number','values':['T7652677']},{'piiDataType':'Person name','values':['Teresa Kaminski']},{'piiDataType':'Phone number','values':['+91-7688288283']},{'piiDataType':'Social security number','values':['151-32-2561']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario2")
  public void Pii_scenario_02() throws Exception {
    String decodedOutput = testPIIAPI("scenario2.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'Aadhaar','values':['4653 **** 8782','6562-6722-****','7638 7687 7673']},{'piiDataType':'Birthdate','values':['10-12-1988','1967/01/03','1980-08-08','1990 21 12']},{'piiDataType':'Credit card number','values':['30569309025904','3714 4963 5398 431','3782 8224 6310 005','3787-3449-3671-000','38520000023237','5610 5910 8101 ****','6011-1111-1111-1117','7868-888-66']},{'piiDataType':'Passport number','values':['B7687673']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario3")
  public void Pii_scenario_03() throws Exception {
    String decodedOutput = testPIIAPI("scenario3.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Credit card number', 'values': ['**** **** 5454 5454', '**** 6100 0000 0000', '2222 4000 1000 0008', '34343434343434', '3714 4963 5398 431', '4012-8888-8888-1881', '4035 5014 2814 6300', '5455 3307 6000 0018', '5506 9004 9000 0436', '5506 9004 9000 0444']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario4")
  public void Pii_scenario_04() throws Exception {
    String decodedOutput = testPIIAPI("scenario4.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Aadhaar', 'values': ['4653 **** 8782', '6562 6722 ****', '7638 7687 7673']}, {'piiDataType': 'Credit card number', 'values': ['30569309025904', '371449635398431', '378282246310005', '378734493671000', '38520000023237', '5610591081018250', '6011111111111117']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario5")
  public void Pii_scenario_05() throws Exception {
    String decodedOutput = testPIIAPI("scenario5.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Aadhaar', 'values': ['4096 9640 8086', '5166-4000-4011']}, {'piiDataType': 'Birthdate', 'values': ['01-11-2011', '11-26-97', '11-27-2023', '12-12-10', '12-25-1996', '12/24/99', '15 06 1993', '15/07/94']}, {'piiDataType': 'Credit card number', 'values': ['4386-2436-0863-6256', '6522 9401 2874 2437', '6522-XXXX-XXXX-2437']}, {'piiDataType': 'Email', 'values': ['shaik.shareef2@concentrix.com', 'testetsst921@gmail.com']}, {'piiDataType': 'Passport number', 'values': ['A1234567', 'H1234567']}, {'piiDataType': 'Person name', 'values': ['sankalp']}, {'piiDataType': 'Social security number', 'values': ['778-62-8144', 'XXXX-XX-8144']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario6")
  public void Pii_scenario_06() throws Exception {
    String decodedOutput = testPIIAPI("scenario6.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Birthdate', 'values': ['11-27-1997']}, {'piiDataType': 'Credit card number', 'values': ['1234-6823-4678-3246']}, {'piiDataType': 'Email', 'values': ['shaik.shareef2@concentrix.com', 'testetsst921@gmail.com']}, {'piiDataType': 'Passport number', 'values': ['G5636337']}, {'piiDataType': 'Person name', 'values': ['John Brown', 'sankalp']}, {'piiDataType': 'Social security number', 'values': ['778-62-8144', 'XXXX-XX-8144']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario7")
  public void Pii_scenario_07() throws Exception {
    String decodedOutput = testPIIAPI("scenario7.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'Address','values':['130 Rosario Viaduct Suite 719 Kimberlyshire, MT 27251 Croatia']},{'piiDataType':'Birthdate','values':['2009-12-20']},{'piiDataType':'Credit card number','values':['4486 8217 6729 8860']},{'piiDataType':'Email','values':['judithmayo@example.net']},{'piiDataType':'Person name','values':['Katherine Thomas']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario8")
  public void Pii_scenario_08() throws Exception {
    String decodedOutput = testPIIAPI("scenario8.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'Birthdate','values':['06-01-93']},{'piiDataType':'Credit card number','values':['5105 1051 0510 ****','5105 1051 0510 7683']},{'piiDataType':'Email','values':['sumit444agrawal@gmail.com']},{'piiDataType':'Passport number','values':['A3436733','L8727777','S5452677']},{'piiDataType':'Phone number','values':['+1 876 577-9814','+44 7911 123456','+91 9856373333','+91-7688288283','+917688288283']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario9")
  public void Pii_scenario_09() throws Exception {
    String decodedOutput = testPIIAPI("scenario9.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'Address','values':['02789 Sandra Valleys Suite 891','North Paulafort, FL 96468']},{'piiDataType':'Birthdate','values':['1982-06-18']},{'piiDataType':'Credit card number','values':['6525084654354775']},{'piiDataType':'Email','values':['Christinamoore@example.net']},{'piiDataType':'Person name','values':['Sylvia Montgomery']},{'piiDataType':'Phone number','values':['618-243-8723']},{'piiDataType':'Social security number','values':['592-25-6741']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario10")
  public void Pii_scenario_10() throws Exception {
    String decodedOutput = testPIIAPI("scenario10.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'Address','values':['Tiffanytown, NC 89932']},{'piiDataType':'Birthdate','values':['1972-12-07']},{'piiDataType':'Credit card number','values':['371449635398431','378282246310005','5116465886406789']},{'piiDataType':'Email','values':['Sumit.test@concentrix.com']},{'piiDataType':'Person name','values':['Diana Dickson']},{'piiDataType':'Social security number','values':['518-46-1849']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario11")
  public void Pii_scenario_11() throws Exception {
    String decodedOutput = testPIIAPI("scenario11.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Email', 'values': ['contact@airsafetyinc.com', 'info@abdriverslimited.com', 'sales@inkconglomerateinc.com', 'support@dirtminingltd.com']}, {'piiDataType': 'Person name', 'values': ['Chris Olliver', 'Jim Brennan']}, {'piiDataType': 'Phone number', 'values': ['+1 - 282 - 838 - 7335', '+1 - 379 - 855 - 5024', '+1 - 964 - 142 - 3563', '+1 - 967 - 166 - 4393']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario12")
  public void Pii_scenario_12() throws Exception {
    String decodedOutput = testPIIAPI("scenario12.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'Aadhaar','values':['4096 9640 8086','5652 7833 2377','6828-8678-8782','7682 3783 7939','xxxx-xxxx-8086']},{'piiDataType':'Birthdate','values':['15/06/1993']},{'piiDataType':'Credit card number','values':['1234 4567 8902']},{'piiDataType':'Social security number','values':['778-62-8144','XXX-XX-8144']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario13")
  public void Pii_scenario_13() throws Exception {
    String decodedOutput = testPIIAPI("scenario13.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'Birthdate','values':['06/01/1990']},{'piiDataType':'Credit card number','values':['371449635398431','378282246310005','4111111111111111','5555555555554444','5105105105105100']},{'piiDataType':'Email','values':['SUMIT4agrawal@gmail.com']},{'piiDataType':'Passport number','values':['T7652677']},{'piiDataType':'Person name','values':['Krati Agrawal']},{'piiDataType':'Phone number','values':['+91-7688288283']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario14")
  public void Pii_scenario_14() throws Exception {
    String decodedOutput = testPIIAPI("scenario14.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'Address','values':['222339 SW Schmelttzer Rd','OR 97140']},{'piiDataType':'Email','values':['MOOitOfii@B','a@b.com','james.bean@concentrix.com','jomes.beon@concentrixcom']},{'piiDataType':'Phone number','values':['503-806-0072','503-806-0073','503-806-0075','503-806-0076','503-806-0077','503-806-0078']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario15")
  public void Pii_scenario_15() throws Exception {
    String decodedOutput = testPIIAPI("scenario15.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Address', 'values': [', 4632 Tempus St.', '2511 Enim. Rd.', '417-2469 Tellus. St.', 'Ap #462-9959 Sagittis Rd.', 'Ap #688-9104 Purus Road', 'Avennes', 'Chungju', 'Leoben', 'P.O. Box 473', 'Trondheim']}, {'piiDataType': 'Birthdate', 'values': ['19-Jul-95', '26-May-96', '3-May-10', '30-Sep-98', '4-Jul-03', '9-Mar-86']}, {'piiDataType': 'Credit card number', 'values': ['4.42892E+12', '448 52882 28992 779', '455614 636374 3965', '4916 173 85 8229', '5438 5366 4348 5521', '557 66861 77845 335']}, {'piiDataType': 'Email', 'values': ['donec@aol.org', 'eu.augue@google.com', 'iaculis@protonmail.com', 'interdum.sed@outlook.net', 'lacinia.mattis@yahoo.org', 'libero@google.couk']}, {'piiDataType': 'Person name', 'values': ['Alyssa Fields']}, {'piiDataType': 'Phone number', 'values': ['01223  539887', '016977  7475', '056 5626 4621', '070 2644 2207', '0800 899 5056', '0948 333 7365']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario16")
  public void Pii_scenario_16() throws Exception {
    String decodedOutput = testPIIAPI("scenario16.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Aadhaar', 'values': ['4096 9640 8086', '5652 7833 2377', '6828-8678-8782', '7682 3783 7939', 'xxxx-xxxx-8086']}, {'piiDataType': 'Birthdate', 'values': ['15/06/1993']}, {'piiDataType': 'Credit card number', 'values': ['1234 4567 8902']}, {'piiDataType': 'Social security number', 'values': ['778-62-8144', 'XXX-XX-8144']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario17")
  public void Pii_scenario_17() throws Exception {
    String decodedOutput = testPIIAPI("scenario17.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Birthdate', 'values': ['2/1/1968', '2/2/1968', '2/3/1968', '2/4/1968', '4/20/1968', '5/21/1968', '6/22/1968', '7/23/1968']}, {'piiDataType': 'Credit card number', 'values': ['345389698201044', '4916-4034-9269-8783', '4916-4811-5814-8111', '4929-3813-3266-4295', '5370-4638-8881-3020']}, {'piiDataType': 'Email', 'values': ['ChristopherAnderson@gmail.com', 'JamesSmith@gmail.com', 'MaryWright@gmail.com']}, {'piiDataType': 'Person name', 'values': ['Danny Reyes', 'Gail Watson', 'Jacki Russell', 'Johnson White', 'Lillian Venson', 'Mireille Townsend', 'Rebecca Zwick', 'Thomas Santos']}, {'piiDataType': 'Social security number', 'values': ['151-32-2558', '172-32-1176', '404-12-2154', '451-80-3526', '461-97-5660', '505-88-5714', '514-30-2668', '624-84-9181']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario18")
  public void Pii_scenario_18() throws Exception {
    String decodedOutput = testPIIAPI("scenario18.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'Email','values':['borer.preston@yahoo.com','bzboncak@gmail.com','fcormier@hotmail.com','freddy.tromp@gmail.com','garett.bernier@paucek.com','graham.shaun@greenfelder.com','ibahringer@hotmail.com','melba.schmeler@fritsch.net','qdaniel@blanda.com','sarah98@harber.com']},{'piiDataType':'Person name','values':['alexane71','angie.fay','cwhite','hheathcote','jaime03','mayra.fahey','reichert.jimmy','upton.reginald','wintheiser.lela','zschoen']},{'piiDataType':'Phone number','values':['+1  949  595-0897','+1.270.892.8710','+1.814.436.2074','-1556','1-279-971-0423','17543800365','407  879-6869','520  373-3256','520-378-7840','540.712.9752']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario19")
  public void Pii_scenario_19() throws Exception {
    String decodedOutput = testPIIAPI("scenario19.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'Aadhaar','values':['8293 8793 7686','8982 8723 ****']},{'piiDataType':'Birthdate','values':['4-Jul-03']},{'piiDataType':'Credit card number','values':['3600 0000 0000 08','3612 3404 8703 94','3612 3409 8536 19','3612 3442 2696 33','3712 3480 6987 034','4722 6673 8883 5868','6011 1111 1111 1117']},{'piiDataType':'Email','values':['adipiscing.lacus.ut@outlook.net','mi.tempor.lorem@protonmail.net']},{'piiDataType':'Phone number','values':['01223  539887','01447  44055','021  8245 2947','0927 297 1652','668-683-7933']},{'piiDataType':'Passport number','values':['H67878283']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario20")
  public void Pii_scenario_20() throws Exception {
    String decodedOutput = testPIIAPI("scenario20.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'Address','values':['3602 Jeffery Inlet','Allenland, MN 62678 Colombia']},{'piiDataType':'Birthdate','values':['1995-06-19']},{'piiDataType':'Credit card number','values':['5564 1227 0858 0270']},{'piiDataType':'Email','values':['lopezkathleen@example.net']},{'piiDataType':'Passport number','values':['J6766777']},{'piiDataType':'Person name','values':['Christopher Roberts']},{'piiDataType':'Phone number','values':['1-307-414-6889','354  638-6416']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario21")
  public void Pii_scenario_21() throws Exception {
    String decodedOutput = testPIIAPI("scenario21.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Birthdate', 'values': ['2/1/1968', '2/2/1968', '2/3/1968', '2/4/1968', '4/20/1968', '5/21/1968', '6/22/1968', '7/23/1968']}, {'piiDataType': 'Credit card number', 'values': ['345389698201044', '4916-4034-9269-8783', '4916-4811-5814-8111', '4929-3813-3266-4295', '5370-4638-8881-3020']}, {'piiDataType': 'Email', 'values': ['ChristopherAnderson@gmail.com', 'JamesSmith@gmail.com', 'MaryWright@gmail.com']}, {'piiDataType': 'Person name', 'values': ['Danny Reyes', 'Gail Watson', 'Jacki Russell', 'Johnson White', 'Lillian Venson', 'Mireille Townsend', 'Rebecca Zwick', 'Thomas Santos']}, {'piiDataType': 'Social security number', 'values': ['151-32-2558', '172-32-1176', '404-12-2154', '451-80-3526', '461-97-5660', '505-88-5714', '514-30-2668', '624-84-9181']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario22")
  public void Pii_scenario_22() throws Exception {
    String decodedOutput = testPIIAPI("scenario22.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'Address','values':['1076 Angela Way Apt. 627','Larrystad, AL 41421']},{'piiDataType':'Credit card number','values':['4974500342140970']},{'piiDataType':'Email','values':['carrvalerie@example.com']},{'piiDataType':'Passport number','values':['K59378164']},{'piiDataType':'Person name','values':['Zachary Parsons']},{'piiDataType':'Phone number','values':['001-444-211-7404x430']},{'piiDataType':'Social security number','values':['038-34-3342']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario23")
  public void Pii_scenario_23() throws Exception {
    String decodedOutput = testPIIAPI("scenario23.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'Address','values':['FPO','Malawi','USNS Benson']},{'piiDataType':'Birthdate','values':['2000-08-02']},{'piiDataType':'Credit card number','values':['5222 3342 5150 7000']},{'piiDataType':'Email','values':['jocelynhull@example.com']},{'piiDataType':'Person name','values':['David Leonard']},{'piiDataType':'Passport number','values':['A74886553']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario24")
  public void Pii_scenario_24() throws Exception {
    String decodedOutput = testPIIAPI("scenario24.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'Birthdate','values':['01/27/2000','1/29/2002','1/30/2006','01/28/2001']},{'piiDataType':'Credit card number','values':['30569309025904','38520000023237','5610591081018250','6011111111111110']},{'piiDataType':'Person name','values':['Baker','Garcia','Maria','Sandra']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario25")
  public void Pii_scenario_25() throws Exception {
    String decodedOutput = testPIIAPI("scenario25.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'Aadhaar','values':['8293 8793 7686','8982 8723 ****']},{'piiDataType':'Credit card number','values':['3600 0000 0000 08','3612 3409 8536 19','3612 3442 2696 33','3712 3480 6987 034','4722 6673 8883 5868','6011 1111 1111 1117','612 3404 8703 94']},{'piiDataType':'Email','values':['adipiscing.lacus.ut@outlook.net','mi.tempor.lorem@protonmail.net']},{'piiDataType':'Phone number','values':['01223  539887','01447  44055','021  8245 2947','0927 297 1652']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario26")
  public void Pii_scenario_26() throws Exception {
    String decodedOutput = testPIIAPI("scenario26.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'Aadhaar','values':['676389618502']},{'piiDataType':'Address','values':['http://www.black-morgan.biz/']},{'piiDataType':'Email','values':['mary37@example.net']},{'piiDataType':'Person name','values':['Barnett','Robinson','Wilson']},{'piiDataType':'Passport number','values':['B61725005']},{'piiDataType':'Social security number','values':['712-23-1488']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario27")
  public void Pii_scenario_27() throws Exception {
    String decodedOutput = testPIIAPI("scenario27.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'Aadhaar','values':['676389618502']},{'piiDataType':'Address','values':['9547 Michael Spur Suite 810','Austinborough, SC 17051']},{'piiDataType':'Birthdate','values':['1989-01-07']},{'piiDataType':'Email','values':['mary37@example.net']},{'piiDataType':'Person name','values':['Rachel Harvey']},{'piiDataType':'Phone number','values':['+1  437  638-6416','+1 858 617-2672','+1 950 308-6485','+13074146889','+1474-318-2672','+353 89 980 4969','+44 7774 656364','250-348-9769']},{'piiDataType':'Social security number','values':['712-23-1488']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario28")
  public void Pii_scenario_28() throws Exception {
    String decodedOutput = testPIIAPI("scenario28.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'Aadhaar','values':['4653 **** 8782','6562-6722-****','7638 7687 7673']},{'piiDataType':'Birthdate','values':['10-12-1988','1967/01/03','1980-08-08','1990 21 12']},{'piiDataType':'Credit card number','values':['30569309025904','3714 4963 5398 431','3782 8224 6310 005','3787-3449-3671-000','38520000023237','5610 5910 8101 ****','6011-1111-1111-1117']},{'piiDataType':'Phone number','values':['+917868886688']},{'piiDataType':'Passport number','values':['B7687673']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario29")
  public void Pii_scenario_29() throws Exception {
    String decodedOutput = testPIIAPI("scenario29.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'Aadhaar','values':['6563-8448-8788']},{'piiDataType':'Birthdate','values':['1959-09-23','2002-06-06','2001-06-04','1996-06-06','1999-06-07','2003-06-07']},{'piiDataType':'Credit card number','values':['4929-3813-3266-4296']},{'piiDataType':'Email','values':['nec@google.net']},{'piiDataType':'Financial statement','values':['$1178','$17,736.67','$24,113.00']},{'piiDataType':'Person name','values':['Jim Brennan']},{'piiDataType':'Passport number','values':['J8369854','G76788744','C7674744','D7747786','R66865889','K76767444']},{'piiDataType':'Social security number','values':['333-22-4444']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario30")
  public void Pii_scenario_30() throws Exception {
    String decodedOutput = testPIIAPI("scenario30.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Aadhaar', 'values': ['7668 4476 3484']}, {'piiDataType': 'Address', 'values': ['4945 Wall Way Suite 604', 'New Gary, NE 11274 Singapore']}, {'piiDataType': 'Birthdate', 'values': ['1978-04-05']}, {'piiDataType': 'Credit card number', 'values': ['5387 6316 8445 3760']}, {'piiDataType': 'Email', 'values': ['riveraandrea@example.com']}, {'piiDataType': 'Passport number', 'values': ['T8764784','Y7689444']}, {'piiDataType': 'Person name', 'values': ['Holly Bates']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario31")
  public void Pii_scenario_31() throws Exception {
    String decodedOutput = testPIIAPI("scenario31.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Aadhaar', 'values': ['xxxx-xxxx-7174']}, {'piiDataType':'Address','values':['Ap #163-1337 Cursus, Road','Ap #789-9043 Nascetur Street']},{'piiDataType':'Credit card number','values':['4532-4220-6922-9909','5270-4267-6450-5516','6331101999990016']},{'piiDataType':'Email','values':['beshelby0@t-online.de','molestie.arcu.sed@yahoo.couk','nullam.suscipit@protonmail.ca']},{'piiDataType':'Person name','values':['James Heard','Rebecca Zwick']},{'piiDataType':'Social security number','values':['559-81-1301']},{'piiDataType':'Aadhaar','values':['xxxx-xxxx-7174']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario32")
  public void Pii_scenario_32() throws Exception {
    String decodedOutput = testPIIAPI("scenario32.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Address', 'values': ['291-7952 Nullam Street,610516,Vestland,Turkey']}, {'piiDataType': 'Birthdate', 'values': ['01/01/01', '01/01/1990']}, {'piiDataType': 'Credit card number', 'values': ['5205105105105109', '5305105105105108', '6011000990139424']}, {'piiDataType': \"Driver's license\", 'values': ['428165389']}, {'piiDataType': 'Email', 'values': ['mi.duis@hotmail.org']}, {'piiDataType': 'Financial statement', 'values': ['$27.04']},{'piiDataType': 'Medical insurance number', 'values': ['DE7845']}, {'piiDataType': 'Person name', 'values': ['John Grady', 'Kay Roy']}, {'piiDataType': 'Phone number', 'values': ['1-813-658-8623']}, {'piiDataType': 'Social security number', 'values': ['909-03-4642']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario33")
  public void Pii_scenario_33() throws Exception {
    String decodedOutput = testPIIAPI("scenario33.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Birthdate', 'values': ['23/11/88']}, {'piiDataType': 'Credit card number', 'values': ['4566604538181253', '4929-3813-3266-4295', '5205105105105109']}, {'piiDataType': 'Email', 'values': ['amet.massa@aol.ca']}, {'piiDataType': 'Financial statement', 'values': ['$33.70']}, {'piiDataType': 'Passport number', 'values': ['123456789GBR1234567U1234567']}, {'piiDataType': 'Person name', 'values': ['Clark Kent', 'Robert Aragon']}, {'piiDataType': 'Phone number', 'values': ['1-361-837-8622']}, {'piiDataType': 'Social security number', 'values': ['489-36-8350']}, {'piiDataType': 'Vehicle registration number', 'values': ['439405987']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario34")
  public void Pii_scenario_34() throws Exception {
    String decodedOutput = testPIIAPI("scenario34.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Aadhaar', 'values': ['2332-2232-2233']}, {'piiDataType': 'Credit card number', 'values': ['371449635398442*', '4012 8888 8888 1881', '5299-1561-5689-1938']}, {'piiDataType': \"Driver's license\", 'values': ['3456788999']}, {'piiDataType': 'Email', 'values': ['emulqueeny2r@mlb.com']}, {'piiDataType': 'Person name', 'values': ['Zhōnghuá Mínguó hùzhào', 'Christopher Diaz', 'Everard Mulqueeny']}, {'piiDataType': 'Phone number', 'values': ['1-917-582-5868']}, {'piiDataType': 'Social security number', 'values': ['805 14 1893', '458-02-6124']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario35")
  public void Pii_scenario_35() throws Exception {
    String decodedOutput = testPIIAPI("scenario35.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Aadhaar', 'values': ['2332-****-2233']}, {'piiDataType': 'Birthdate', 'values': ['12/28/2001']}, {'piiDataType': 'Credit card number', 'values': ['37144963539****', '4012 8888 8888 1881', '5299-1561-5689-1938']}, {'piiDataType': 'Email', 'values': ['emulqueeny2r@mlb.com']}, {'piiDataType': 'Passport number', 'values': ['3456788000']}, {'piiDataType': 'Person name', 'values': ['John Nell']}, {'piiDataType': 'Phone number', 'values': ['1-917-582-5868']}, {'piiDataType': 'Social security number', 'values': ['458-02-6124', '805 ** 1893']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario36")
  public void Pii_scenario_36() throws Exception {
    String decodedOutput = testPIIAPI("scenario36.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Aadhaar', 'values': ['1234 9999 0001']}, {'piiDataType': 'Address', 'values': ['P.O. Box 752, 7732 Tincidunt Road,99910,Limón,Indonesia']}, {'piiDataType': 'Birthdate', 'values': ['01/15/1975', '11/23/1988', '1976']}, {'piiDataType': 'Credit card number', 'values': ['4539-5385-7425-5830', '4566604538181253', '5144-8691-2776-1108', '6011111111111112']}, {'piiDataType': \"Driver's license\", 'values': ['428165389']}, {'piiDataType': 'Email', 'values': ['lorem@aol.net']}, {'piiDataType': 'Financial statement', 'values': ['$84.79']}, {'piiDataType': 'Passport number', 'values': ['12AB12345', '7141506RA']}, {'piiDataType': 'Person name', 'values': ['Clark Kent', 'Lisa Garrison', 'Ori Myers', 'Tim Low']}, {'piiDataType': 'Phone number', 'values': ['234  674-6353']}, {'piiDataType': 'Social security number', 'values': ['044-34-6954', '113-01-1111', '660-03-8365']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario37")
  public void Pii_scenario_37() throws Exception {
    String decodedOutput = testPIIAPI("scenario37.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Birthdate', 'values': ['10/19/1975', '11/5/2025', '25/12/90', '5/6/1981', '8/27/1991']}, {'piiDataType': 'Credit card number', 'values': ['6331101999990###', '3566002020360505', '4532-0065-1968-****', '4532-9929-3036-9308', '5325-****-9519-6624', '5325-3256-9519-6624']}, {'piiDataType': \"Driver's license\", 'values': ['S12345678']}, {'piiDataType': 'Email', 'values': ['JeffMartin@aol.com', 'LisaMitchell@gmail.com']}, {'piiDataType': 'Financial statement', 'values': ['$44.56']}, {'piiDataType': 'Passport number', 'values': ['AB1234567']}, {'piiDataType': 'Person name', 'values': ['Danny Reyes', 'Jeff Martin', 'Lisa Mitchell', 'Lynette Oyola', 'Ryan Doherty', 'Tom Brady']}, {'piiDataType': 'Social security number', 'values': ['465-73-5022', '587-03-2682', '624-84-9181']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario38")
  public void Pii_scenario_38() throws Exception {
    String decodedOutput = testPIIAPI("scenario38.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Aadhaar', 'values': ['8580-3038-****']}, {'piiDataType': 'Birthdate', 'values': ['11/11/11', '25/12/90', '5/14/2023']}, {'piiDataType': 'Credit card number', 'values': ['3566002020360505', '3530111333300000', '4916 8549 $$$$ 9045', '6011 8109 1445 6476']}, {'piiDataType': \"Driver's license\", 'values': ['S12345678']}, {'piiDataType': 'Email', 'values': ['andrew_roberts@yahoo.com', 'khall43@outlook.com', 'ullamcorper.nisl@icloud.ca']}, {'piiDataType': 'Financial statement', 'values': ['$33.11', '$38.31']}, {'piiDataType': 'Passport number', 'values': ['1234567890USA1234567M1234567', 'KF0192332C', 'ABA9875413']}, {'piiDataType': 'Person name', 'values': ['Cassidy Sosa', 'Mary Jones', 'Ryan Doherty', 'Tom Brady']}, {'piiDataType': 'Social security number', 'values': ['149-13-****', '757-85-7495', '805 14 1893']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario39")
  public void Pii_scenario_39() throws Exception {
    String decodedOutput = testPIIAPI("scenario39.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Aadhaar', 'values': ['5548-****-6336']}, {'piiDataType': 'Address', 'values': ['Newark,19716,Warehousing, Ltd.,Warehousing,www.WarehousingLtd.net', 'P.O. Box 558, 6538 Scelerisque Ave,22678', 'West Long Branch,07764,Beverages, Inc.,Beverages,www.BeveragesInc.net']}, {'piiDataType': 'Birthdate', 'values': ['28/8/2013', '15/9/2011']}, {'piiDataType': 'Credit card number', 'values': ['30569309025904**', '345389698201044', '5144-8691-2776-****', '5425 2334 3010 ****']}, {'piiDataType': 'Email', 'values': ['andrew_roberts@yahoo.com', 'khall43@outlook.com', 'nam@yahoo.net']}, {'piiDataType': 'Passport number', 'values': ['KF0192332C']}, {'piiDataType': 'Person name', 'values': ['Andrew', 'Cadillac', 'DeVille', 'Forte', 'Green', 'Hall', 'Kevin', 'Kia', 'Kimberly', 'Roberts', 'Shea Norris']}, {'piiDataType': 'Phone number', 'values': ['+17315569119', '+19075826245']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario40")
  public void Pii_scenario_40() throws Exception {
    String decodedOutput = testPIIAPI("scenario40.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'Aadhaar','values':['3149-5544-0800']},{'piiDataType':'Address','values':['rambunctiousrailway,Newark,39.564499,-75.597047,Delaware,DE,253 River Street,19716','standingtray,West Long Branch,40.289985,-74.016710']},{'piiDataType':'Credit card number','values':['47013222****1234','4701322211111234','4960999008288***','5455-7805-8606-0000','5610591081018228','6011000990139424','6034883265619896']},{'piiDataType':'Email','values':['andrew_roberts@yahoo.com','khall43@outlook.com','nunc.quis@aol.couk']},{'piiDataType':'Passport number','values':['A2096457','J8369845']},{'piiDataType':'Person name','values':['Herrod Edwards']},{'piiDataType':'Phone number','values':['+17315569119','+19075826245']},{'piiDataType':'Social security number','values':['003 06 ****']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario41")
  public void Pii_scenario_41() throws Exception {
    String decodedOutput = testPIIAPI("scenario41.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Aadhaar', 'values': ['510406000000']}, {'piiDataType': 'Address', 'values': ['Canada,P.O. Box 220, 3191 Eget Street', 'Newark,39.564499,Delaware,DE,253 River Street,19716', 'P.O. Box 558, 6538 Scelerisque Ave,22678', 'West Long Branch,40.289985,New Jersey,NJ,6343 River Road,07764']}, {'piiDataType': 'Credit card number', 'values': ['4012 8888 8888 1881', '4539-8219-0484-7598', '4916854957639045', '5104 **** 0000 0008', '5104 0600 0000 0008', '6011810914456476']}, {'piiDataType': 'Email', 'values': ['nam@yahoo.net']}, {'piiDataType': 'Passport number', 'values': ['123456789USA1234567U1234567']}, {'piiDataType': 'Person name', 'values': ['Abdul Valentine', 'Mireille Townsend', 'Shea Norris']}, {'piiDataType': 'Phone number', 'values': ['779 906-8167']}, {'piiDataType': 'Social security number', 'values': ['404-12-2154']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario42")
  public void Pii_scenario_42() throws Exception {
    String decodedOutput = testPIIAPI("scenario42.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Aadhaar', 'values': ['9621 **** 5606']}, {'piiDataType': 'Birthdate', 'values': ['02/28/2000', '1/17/1968', '11/10/2025']}, {'piiDataType': 'Credit card number', 'values': ['**********1113', '30204861594838**', '356600202036####', '4916854957639045', '5455-7805-8606-2610', '6011810914456476']}, {'piiDataType': 'Email', 'values': ['GeorgeThompson@yahoo.com']}, {'piiDataType': 'Passport number', 'values': ['A2096457']}, {'piiDataType': 'Social security number', 'values': ['401318448', '003 06 8815']}]\n";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario43")
  public void Pii_scenario_43() throws Exception {
    String decodedOutput = testPIIAPI("scenario43.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Aadhaar', 'values': ['5455-7805-XXXX', '9621 6511 5606', '0249-3285-####']}, {'piiDataType': 'Address', 'values': ['Ap #123-969 Faucibus Rd.,919777', 'Ap #564-6938 Libero Avenue,41712']}, {'piiDataType': 'Credit card number', 'values': ['4916022708346118', '371140808956093', '4701322211111234', '5241 8100 0000 0000']}, {'piiDataType': 'Email', 'values': ['a.facilisis@google.org', 'return@email.ca', 'ullamcorper@aol.com', 'customer+disputed-return@email.ca']}, {'piiDataType': 'Passport number', 'values': ['P4366918']}, {'piiDataType': 'Person name', 'values': ['Jacob Rutledge', 'Norman Calderon']}, {'piiDataType': 'Phone number', 'values': ['1-718-221-6516', '478  827-6455']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario44")
  public void Pii_scenario_44() throws Exception {
    String decodedOutput = testPIIAPI("scenario44.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Aadhaar', 'values': ['8580-3038-****', '9621 6511 5606', '****-2350-9284']}, {'piiDataType': 'Birthdate', 'values': ['25/12/90', '4/5/1981', '2019-02-28']}, {'piiDataType': 'Credit card number', 'values': ['3566002020360505', '4916854957639045', '5370-4638-8881-3020', '5413-4428-0145-0036', '60111111111111**', '6011810914456476']}, {'piiDataType': \"Driver's license\", 'values': ['S12345678']}, {'piiDataType': 'Email', 'values': ['MaryWright@gmail.com', 'lorem.semper@google.edu']}, {'piiDataType': 'Person name', 'values': ['Christopher Anderson', 'Mary Wright', 'Michael Scott', 'Quinn Porter', 'Ryan Doherty', 'Tom Brady']}, {'piiDataType': 'Phone number', 'values': ['+17315569119', '+19075826245', '1-425-274-6385']}, {'piiDataType': 'Social security number', 'values': ['003 06 ####', '401318448']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario45")
  public void Pii_scenario_45() throws Exception {
    String decodedOutput = testPIIAPI("scenario45.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Aadhaar', 'values': [ '96216511****']}, {'piiDataType': 'Address', 'values': ['265-3518 Sagittis Avenue, 263', '9454 Ut Av.,', 'Newark,Delaware,19716', 'West Long Branch,New Jersey,07764']}, {'piiDataType': 'Birthdate', 'values': ['2000-01-01T00:00:00Z']}, {'piiDataType': 'Credit card number', 'values': ['5200533989557118', '58956267465956$$', '4718 6091 0820 4366', '5495-****-4508-6804']}, {'piiDataType': 'Email', 'values': ['RobertLewis@hotmail.com']}, {'piiDataType': 'Phone number', 'values': ['263 652-1872', '1-465-366-7855', '731-556-9119', '907-582-6245']}, {'piiDataType': 'Social security number', 'values': ['****-85-7495']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }


  @Test(description = "Test pii anonymization api with test data scenario46")
  public void Pii_scenario_46() throws Exception {
    String decodedOutput = testPIIAPI("scenario46.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Aadhaar', 'values': ['207585156125', '2161 6729 ####']}, {'piiDataType': 'Birthdate', 'values': ['1/2/1981', '28/8/2013', '8/28/2013']}, {'piiDataType': 'Credit card number', 'values': ['5019717010103742', '38520000023237**', '4916-4811-5814-8111', '6011810914456476']}, {'piiDataType': 'Email', 'values': ['LindaJones@hotmail.com', 'auctor.quis@icloud.couk', 'received@email.ca', 'ultrices.iaculis@icloud.net']}, {'piiDataType': 'Passport number', 'values': ['439405987']}, {'piiDataType': 'Person name', 'values': ['Calvin Price', 'Octavius Byrd', 'James Smith']}, {'piiDataType': 'Phone number', 'values': ['+15195550117']}, {'piiDataType': 'Social security number', 'values': ['003 ## 8815', '16325404', '690-05-5315']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario47")
  public void Pii_scenario_47() throws Exception {
    String decodedOutput = testPIIAPI("scenario47.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Aadhaar', 'values': ['1667-9750-5883', '**** 6511 5606','6213-3631-4249']}, {'piiDataType': 'Birthdate', 'values': ['10-07-1970', '2/21/1991', '2011-09-15', '2013-08-28', '7/8/1981']}, {'piiDataType': 'Credit card number', 'values': ['3782822####0005', '6331101999990010', '4347699988887777', '4556-0072-1294-7415', '5241 8100 0000 0000']}, {'piiDataType': 'Email', 'values': ['JasonBrown@aol.com', 'JohnThomas@gmail.com', 'cum.sociis@protonmail.couk', 'email+reject_reason_CREDIT_LIMIT_EXCEEDED@email.com']}, {'piiDataType': 'Financial statement', 'values': ['$75k', '$85k']}, {'piiDataType': 'Passport number', 'values': ['gbr 123456789GBR1234567U1234567']}, {'piiDataType': 'Person name', 'values': ['Andrew', 'Brian\\tKing', 'Kevin', 'Kyla Gentry', 'Mark Hall', 'Matthew', 'Roberts', 'William']}, {'piiDataType': 'Phone number', 'values': ['645 311-9683']}, {'piiDataType': 'Social security number', 'values': ['318-54-7618', '401318448', '449-48-3135', '743-11-3942']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario48")
  public void Pii_scenario_48() throws Exception {
    String decodedOutput = testPIIAPI("scenario48.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Aadhaar', 'values': ['79071461****', '8580-3038-2541']}, {'piiDataType': 'Address', 'values': ['242-8945 Enim Av.,634442,Cauca,Norway,GHB55NWX5DN', 'P.O. Box 665, 5588 Mauris St.,69155,Tamaulipas,United Kingdom,YZV05ONN2WB']}, {'piiDataType': 'Birthdate', 'values': ['12/28/1968', '5/24/1991']}, {'piiDataType': 'Credit card number', 'values': ['****111333300000', '4012888888881880', '4916854957639045', '5325-3256-9519-6624', '6011810914456476', '6362970000457013']}, {'piiDataType': 'Email', 'values': ['JosephHernandez@facebook.com', 'KimberlyGreen@aol.com', 'customer@email.fi']}, {'piiDataType': 'Passport number', 'values': ['AB203481']}, {'piiDataType': 'Person name', 'values': ['Geraldine Berry', 'Kimberly Green', 'Indira Lyons', 'Joseph Hernandez', 'Sharon Collins']}, {'piiDataType': 'Phone number', 'values': ['1-671-441-6312', '764  665-2519']}, {'piiDataType': 'Social security number', 'values': ['909-03-4642', '751 01 2327']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario49")
  public void Pii_scenario_49() throws Exception {
    String decodedOutput = testPIIAPI("scenario49.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Aadhaar', 'values': ['8580 3038 2541', '8580-3038-2541']}, {'piiDataType': 'Birthdate', 'values': ['10-07-1990', '8/28/2013', '9/15/2011']}, {'piiDataType': 'Credit card number', 'values': ['4916854957639045', '5104 0155 5555 5558', '5104 0600 0000 0008', '6011810914456476', '6062826786276634', '345389698202****']}, {'piiDataType': \"Driver's license\", 'values': ['428165389']}, {'piiDataType': 'Email', 'values': ['customer@email.pt']}, {'piiDataType': 'Passport number', 'values': ['5484880UA']}, {'piiDataType': 'Person name', 'values': ['Andrew', 'Kevin', 'Roberts']}, {'piiDataType': 'Phone number', 'values': ['+351212162265']}, {'piiDataType': 'Social security number', 'values': ['757-85-****']}]\n";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario50")
  public void Pii_scenario_50() throws Exception {
    String decodedOutput = testPIIAPI("scenario50.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Aadhaar', 'values': ['$$$$-$$$$-5883', '0249-3285-1294', '****-3285-1294']}, {'piiDataType': 'Address', 'values': ['123 Any Street, Seattle, WA 98109', 'Delaware,DE,253 River Street,19716,', 'New Jersey,NJ,6343 River Road,07764,']}, {'piiDataType': 'Birthdate', 'values': ['25-12-1970', '9/1/2001', '2013-08-28', '2011-09-15']}, {'piiDataType': 'Credit card number', 'values': ['1111-0000-1111-0000', '5105 1051 0510 &&&&', '5555 5555 5555 4444', '6250941006528599']}, {'piiDataType': 'Email', 'values': ['andrew_roberts@yahoo.com', 'khall43@outlook.com']}, {'piiDataType': 'Passport number', 'values': ['H045489']}, {'piiDataType': 'Person name', 'values': ['Paulo Santos', 'Ryan Smith']}, {'piiDataType': 'Phone number', 'values': ['731-556-9119', '907-582-6245']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario51")
  public void Pii_scenario_51() throws Exception {
    String decodedOutput = testPIIAPI("scenario51.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Birthdate', 'values': ['01-01-2000']}, {'piiDataType': 'Credit card number', 'values': ['4000056655665550', '4539-0031-3703-****', '5299-1561-5689-1938']}, {'piiDataType': 'Email', 'values': ['BrianKing@facebook.com', 'customer+disputed-high_risk_order@email.es', 'eu.turpis@google.edu', 'nonummy.ac@google.ca']}, {'piiDataType': 'Passport number', 'values': ['BB0979829']}, {'piiDataType': 'Person name', 'values': ['Andrew', 'Christopher Diaz', 'Dorothy Carter', 'Hollee Dominguez', 'Kay Leon', 'Kevin']}, {'piiDataType': 'Phone number', 'values': ['219  676-5693', '862  757-4523']}, {'piiDataType': 'Social security number', 'values': ['*** 06 8815', '318-54-7618', '421-90-3440', '743-11-3942', '790714###']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario52")
  public void Pii_scenario_52() throws Exception {
    String decodedOutput = testPIIAPI("scenario52.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Aadhaar', 'values': ['2161 **** 3627', '0249-3285-1294']}, {'piiDataType': 'Address', 'values': ['100 Main Street, Anytown, USA', 'Calle de Santa Isabel 52 DCHA']}, {'piiDataType': 'Credit card number', 'values': ['385200000232****', '4916854957639045', '501105448859@@@@', '6011810914456476']}, {'piiDataType': 'Email', 'values': ['cursus.integer.mollis@google.org']}, {'piiDataType': 'Phone number', 'values': ['735  351-2577']}, {'piiDataType': 'Social security number', 'values': ['123456783', '123456789', '70906649', '030 72 7381']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario53")
  public void Pii_scenario_53() throws Exception {
    String decodedOutput = testPIIAPI("scenario53.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Aadhaar', 'values': ['9621 #### 5606', '****-****-2541']}, {'piiDataType': 'Birthdate', 'values': ['01/01/01', '01/15/1975', '21-03-1941']}, {'piiDataType': 'Credit card number', 'values': ['4539-5385-7425-5830', '4960999008288', '5305105105105108', '5455-7805-8606-2610', '6011000990139424']}, {'piiDataType': 'Email', 'values': ['andrew_roberts@yahoo.com', 'khall43@outlook.com']}, {'piiDataType': 'Person name', 'values': ['Andrew', 'Clark Hfldaskjfiougj', 'Clark Kent', 'John Grady', 'Kevin', 'Lisa Garrison']}, {'piiDataType': 'Phone number', 'values': ['731-556-9119', '907-582-6245']}, {'piiDataType': 'Social security number', 'values': ['660-03-8365']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario54")
  public void Pii_scenario_54() throws Exception {
    String decodedOutput = testPIIAPI("scenario54.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Aadhaar', 'values': ['9621 6511 5606']}, {'piiDataType': 'Birthdate', 'values': ['15th,September', '28th,August']}, {'piiDataType': 'Credit card number', 'values': ['4916854957639045', '5180-3807-3679-####', '6011810914456476']}, {'piiDataType': 'Email', 'values': ['05@email.us', 'dolor.quam@google.net', 'purus.ac.tellus@hotmail.edu']}, {'piiDataType': 'Person name', 'values': ['Andrew', 'Jerry Ingram', 'Kevin', 'Owen Gonzalez']}, {'piiDataType': 'Phone number', 'values': ['+17315569119', '+19075826245', '253  165-2684', '677  726-6186', '+13105550117']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario55")
  public void Pii_scenario_55() throws Exception {
    String decodedOutput = testPIIAPI("scenario55.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Aadhaar', 'values': ['2625-2331-7140']}, {'piiDataType': 'Birthdate', 'values': ['January 1, 1945', 'December 31, 1990']}, {'piiDataType': 'Credit card number', 'values': ['4012 8888 8888 1881', '4916022708346118', '4916854957639045', '5104 0600 0000 0008', '6011810914456476']}, {'piiDataType': 'Email', 'values': ['a.taylor@aol.com,', 'abc@cisco.com', 'customer+disputed-already_paid@email.us', 'khall43@outlook.com']}, {'piiDataType': 'Phone number', 'values': ['+13105550118', '+17315569119', '+18027709597', '+19075826245']}]\n";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario56")
  public void Pii_scenario_56() throws Exception {
    String decodedOutput = testPIIAPI("scenario56.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Aadhaar', 'values': ['2075-8515-6125']}, {'piiDataType': 'Address', 'values': ['Garth Fulton,P.O. Box 658, 9494 Nec Road']}, {'piiDataType': 'Birthdate', 'values': ['May,2012']}, {'piiDataType': 'Credit card number', 'values': ['4222222222222', '5325-3256-9519-6624', '6011380647754845']}, {'piiDataType': 'Email', 'values': ['MargaretEdwards@facebook.com', 'customer+disputed-unauthorized_purchase@email.us', 'k_m96@live.com']}, {'piiDataType': 'Passport number', 'values': ['A12345678']}, {'piiDataType': 'Phone number', 'values': ['+16013492180']}]\n";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario57")
  public void Pii_scenario_57() throws Exception {
    String decodedOutput = testPIIAPI("scenario57.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Aadhaar', 'values': ['#### 6511 5606', '2653 **** 4663']}, {'piiDataType': 'Birthdate', 'values': ['2013,August', '25/12/90']}, {'piiDataType': 'Credit card number', 'values': ['3566002020360505', '4532-9929-3036-9308', '30569309025904**', '5104 0155 5555 ****']}, {'piiDataType': 'Email', 'values': ['SharonCollins@facebook.com', 'at.velit@outlook.com', 'et@google.couk']}, {'piiDataType': 'Passport number', 'values': ['0691084DH', '5484880UA']}, {'piiDataType': 'Person name', 'values': ['Amelia Calderon', 'Kevin', 'Lynette Oyola', 'Philip Garner', 'Ryan Doherty', 'Tom Brady']}, {'piiDataType': 'Phone number', 'values': ['731-556-9119']}, {'piiDataType': 'Social security number', 'values': ['587-**-2682']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario58")
  public void Pii_scenario_58() throws Exception {
    String decodedOutput = testPIIAPI("scenario58.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Aadhaar', 'values': ['4756 **** 7470', '4756 8307 7470', '9706-6089-5363']}, {'piiDataType': 'Birthdate', 'values': ['8/28/2013', '1/27/2015', '2/17/2019']}, {'piiDataType': 'Credit card number', 'values': ['5252-5971-4219-4116']}, {'piiDataType': 'Email', 'values': ['NancyWilliams@hotmail.com', 'haldus2q@t-online.de', 'rpigeon2n@lulu.com']}, {'piiDataType': 'Person name', 'values': ['Joseph', 'Joshua', 'Kelsey', 'Kevin', 'Rebecca Zwick']}, {'piiDataType': 'Phone number', 'values': ['+12761616886', '+16013492180', '+17206485128', '+17315569119']}, {'piiDataType': 'Social security number', 'values': ['151-32-2558']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario59")
  public void Pii_scenario_59() throws Exception {
    String decodedOutput = testPIIAPI("scenario59.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Aadhaar', 'values': ['###-####-7140', '8580-3038-2541']}, {'piiDataType': 'Address', 'values': ['138-7457 Ullamcorper Av.,Australia', '492-7062 Vel, Ave,Austria', 'Ap #972-184 Accumsan Av.,Pakistan']}, {'piiDataType': 'Credit card number', 'values': ['340389244626426', '4929-3813-3266-4295', '4929-3813-3266-4296', '6011810914456476', '6034932528973614']}, {'piiDataType': 'Email', 'values': ['a.taylor@aol.com', 'andrew_roberts@yahoo.com', 'elit.pede@outlook.couk', 'j.james@ymail.com', 'tellus.aenean@hotmail.edu']}, {'piiDataType': 'Financial statement', 'values': ['$125k', '$215k', '$3.15', '$68.91']}, {'piiDataType': 'Passport number', 'values': ['4115381JA', '7700225VH']}, {'piiDataType': 'Person name', 'values': ['Byron Paul', 'Merritt Whitney', 'Robert Aragon']}, {'piiDataType': 'Phone number', 'values': ['236-1196', '811-5941']}, {'piiDataType': 'Social security number', 'values': ['230-54-2825', '423-72-2654', '489-36-8350', '489-36-8351', '489-36-8352']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario60")
  public void Pii_scenario_60() throws Exception {
    //checked
    String decodedOutput = testPIIAPI("scenario60.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType': 'Aadhaar', 'values': ['12222333****']}, {'piiDataType': 'Address', 'values': ['492-7062 Vel, Ave,Austria']}, {'piiDataType': 'Credit card number', 'values': ['4916854957639045', '6011810914456476']}, {'piiDataType': 'Email', 'values': ['dolor.sit.amet@icloud.ca', 'khall43@outlook.com', 'roberts@yahoo.com']}, {'piiDataType': 'Financial statement', 'values': ['$62.41']}, {'piiDataType': 'Passport number', 'values': ['AR12345678']}, {'piiDataType': 'Person name', 'values': ['Kelly Burke']}, {'piiDataType': 'Phone number', 'values': ['1-813-362-8336', '+3580401234587']}, {'piiDataType': 'Social security number', 'values': ['1890118007123']}, {'piiDataType': 'Vehicle registration number', 'values': ['U7NH57G7NAZE54627', 'WEFHVJH8JM2V57078']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario61")
  public void Pii_scenario_61() throws Exception {
    String decodedOutput = testPIIAPI("scenario61.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'IPv4 Addresses','values':['13.208.89.86','13.54.186.110','162.158.186.213','172.69.33.192','172.70.114.3','172.70.215.15','20.190.117.162','3.113.237.86','43.200.31.191','72.80.76.109']},{'piiDataType':'IPv6 Addresses','values':['1099:f86f:0ccd:360d:5074:c4e4:e0f0:cbe3','2001:0db8:0001:0000:0000:0ab9:C0A8:0102','c13c:4b70:7e74:d9b5:999d:5c5e:547a:3509','e7a1:b1d0:0c13:b46e:d729:fdf6:2c73:2ce9']},{'piiDataType':'MAC Addresses','values':['11:cb:a1:42:93:6d','63:71:c6:a7:71:7e','7a:bf:1a:28:c9:51','c5:5b:a9:de:b7:cf']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario62")
  public void Pii_scenario_62() throws Exception {
    String decodedOutput = testPIIAPI("scenario62.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'IPv4 Addresses','values':['101.42.116.80','124.222.228.228','124.223.30.144','150.109.171.184','18.167.234.221','3.0.239.173','34.101.102.199','34.101.171.73','34.101.192.182','34.101.213.71','34.101.81.171','43.204.105.75']},{'piiDataType':'IPv6 Addresses','values':['2001:0db8:0001:0db8:0000:0ab9:C0A8:0102','625c:8783:6eaf:b960:4e89:fa22:85ad:ea07','ac57:7f11:05c1:ec13:a5a4:51c7:2f44:92df','e01f:9d05:d574:feed:94ad:93f9:07b8:a107','e2fe:6a38:a169:eea8:9120:66af:659a:5d26']},{'piiDataType':'MAC Addresses','values':['43:2b:7a:e0:4e:4b','4a:57:25:0d:07:fa','9e:80:76:5c:ad:4c']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario63")
  public void Pii_scenario_63() throws Exception {
    String decodedOutput = testPIIAPI("scenario63.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'Address','values':['California, USA','Dubai, UAE','Ireland','London, UK','Paris','Sao Paulo, Brazil','Toronto, Canada']},{'piiDataType':'IPv4 Addresses','values':['13.36.154.207','184.169.250.146','3.11.88.57','34.240.49.81','35.182.98.197','54.207.159.35']},{'piiDataType':'IPv6 Addresses','values':['41f9:ae92:7415:5ef7:0fe5:ab68:27ad:1f20','7a69:2413:d87a:018c:14e3:e7c1:3002:c537','a55a:2d02:be24:b6e6:6cfd:e0cf:8d29:23cc','a6f9:abe6:1577:10fb:ed12:8d2f:f80a:7814']},{'piiDataType':'MAC Addresses','values':['4e:fb:a7:b5:36:3d','98:a7:3e:cf:fd:9a','e8:41:b4:b7:0d:91']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario64")
  public void Pii_scenario_64() throws Exception {
    String decodedOutput = testPIIAPI("scenario64.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'IPv6 Addresses','values':['47dc:11b6:6cab:24b1:f2c0:1753:6d76:af0e','b898:aaff:28a1:90c1:1940:924b:e055:f879','e263:79a0:9cd2:2a45:8084:c763:20ed:7f38','e4af:7013:a0a2:491a:9ef3:3732:86cd:240b','eca3:0c47:53a2:c648:d556:869a:e0b1:3d32']},{'piiDataType':'MAC Addresses','values':['21:b8:aa:44:43:45','9f:c5:f2:bb:f7:33','a2:47:ef:01:a4:6f','ec:59:6a:e5:9a:3c']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario65")
  public void Pii_scenario_65() throws Exception {
    String decodedOutput = testPIIAPI("scenario65.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'Address','values':['Osaka, Japan','Sydney, Australia','Tokyo, Japan']},{'piiDataType':'IPv4 Addresses','values':['13.208.89.86','13.54.186.110','3.113.237.86','43.200.31.191']},{'piiDataType':'MAC Addresses','values':['22:ad:ce:ab:97:57','a1:66:e3:d6:35:03','a2:d5:b6:23:10:ac','a9:da:21:ea:fa:ae']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario66")
  public void Pii_scenario_66() throws Exception {
    //checked
    String decodedOutput = testPIIAPI("scenario66.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'IPv6 Addresses','values':['0ca0:afb7:0639:dd37:dc6d:14a2:c4c1:e2f2','11a7:f4ed:946f:c08a:c7a1:25aa:73c5:c8a3','8bb1:078d:a178:6de5:5459:4d3c:4da4:7338','98de:0196:f094:e3a2:c8bc:0105:8e91:57bc']},{'piiDataType':'MAC Addresses','values':['08:c5:42:56:6d:9e','38-F3-AB-F8-F6-27','b9:74:6a:1e:5a:c4']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario67")
  public void Pii_scenario_67() throws Exception {
    String decodedOutput = testPIIAPI("scenario67.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'IPv6 Addresses','values':['1989:1a9a:2862:7c48:7968:29fb:5f8c:1cd6','1dfb:acb8:f1ba:3c0e:1b99:67d2:c66e:9a97','8256:82bf:e144:bfb4:f34c:3777:57d9:3614','b34f:b0f7:4858:9006:dafa:e5cc:a62a:70fb','bc1a:d209:72a5:94fd:7179:192b:374b:f057','ceb9:cbaa:beab:fc5e:0024:a232:04a4:ccf4','d249:85c0:1bc7:d899:8538:240c:4abd:5397']},{'piiDataType':'MAC Addresses','values':['0e:98:f0:ba:fb:48','99:9a:4a:c7:61:27','be:f6:1e:5e:58:e2','c5:72:d3:d9:7b:13']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario68")
  public void Pii_scenario_68() throws Exception {
    String decodedOutput = testPIIAPI("scenario68.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'IPv6 Addresses','values':['0e82:cb61:495f:5a11:b4a5:19bb:72e5:9aac','234c:6424:d066:9f43:09bc:2020:3484:807c','571c:8d5b:bb85:f108:e368:ebdf:b861:b486','66dd:9d7b:75b7:383b:ca71:25ce:fa80:7450','83f3:f4b3:0bbb:4d41:199b:6b5c:dad5:b5a0','b675:2344:ad4f:32aa:5a8f:18f8:1de9:7c1b','c5b2:e9b8:615f:455a:f02b:e572:9931:bcd8','d5f0:4fbe:21a3:5202:e198:fd32:bbf4:83eb']},{'piiDataType':'MAC Addresses','values':['47:a4:62:21:b7:b3','5c:e6:16:38:d3:77','74-4C-A1-DA-8B-F6','87:7c:06:83:84:ad','F6-4C-A1-DA-8B-F5','a9:2a:af:83:1d:f0']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario69")
  public void Pii_scenario_69() throws Exception {
    String decodedOutput = testPIIAPI("scenario69.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'IPv6 Addresses','values':['1cd7:f063:ed3c:ab9d:9d89:6325:3d8d:6cc8','6fa4:44e1:b705:db2d:aad5:faf2:3119:8b5c','8ac5:3e53:b82d:361c:0a52:780e:a553:bb3e','af61:b614:4be8:aa42:9efb:797a:7dea:681b','b006:88e8:18a3:027d:a95d:9082:f372:938b','c416:8aca:d96f:a5fb:27df:e47c:9df0:652e']},{'piiDataType':'MAC Addresses','values':['34:46:c4:8a:36:bb','35:d8:92:74:ac:eb','49:e9:24:84:27:29','74-4C-A1-DA-8B-F5','dd:2c:f9:e1:02:b3','e7:a6:2b:f2:13:aa']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario70")
  public void Pii_scenario_70() throws Exception {
    String decodedOutput = testPIIAPI("scenario70.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'IPv4 Addresses','values':['13.246.114.251','15.184.48.78','16.16.9.17','18.102.57.88','34.32.167.79','34.90.76.140','35.156.209.163','35.204.186.193','35.204.8.130']},{'piiDataType':'IPv6 Addresses','values':['27fb:5bf0:66bf:075b:e1a7:59df:7d13:eca0','a58c:c4f6:b499:aa85:494d:10e9:0542:00c8','cf62:1a35:12f3:a213:7434:eda7:498b:788f']},{'piiDataType':'MAC Addresses','values':['d6:44:28:af:03:f2','ef:48:2c:e1:d1:52','f0:5e:b4:0b:48:23']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario70")
  public void Pii_scenario_71() throws Exception {
    String decodedOutput = testPIIAPI("scenario71.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'Aadhaar','values':['4096 9640 8086']},{'piiDataType':'Financial statement','values':['8.41']},{'piiDataType':'IPv4 Addresses','values':['10.43.128.1','192.168.29.193','255.255.240.0','255.255.255.0']},{'piiDataType':'IPv6 Addresses','values':['2405:201:4031:e811:a47c:446a:6f40:9d7a','2405:201:4031:e811:f9da:25d1:465b:f53f','fe80::4355:9e8c:b588:8d7a%15','fe80::5a6f:d508:88c6:48a1%20','fe80::a24c:cffifeed:77b9%20','fe80::f94a:9055:724b:e127%15']},{'piiDataType':'Social security number','values':['778-62-8144']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario70")
  public void Pii_scenario_72() throws Exception {
    String decodedOutput = testPIIAPI("scenario72.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'Address','values':['3220 Janet Key','Garciaport, LA 64277 Namibia']},{'piiDataType':'Credit card number','values':['5381 2204 4055 7670']},{'piiDataType':'Email','values':['mckayjose@example.org']},{'piiDataType':'IPv4 Addresses','values':['10.43.192.175','155.90.248.206','155.90.248.207','255.255.240.0']},{'piiDataType':'IPv6 Addresses','values':['fe80::115e:bab6:87b6:5f38%16','fe80::b2a2:9d36:4061:40e9%16']},{'piiDataType':'MAC Addresses','values':['00-05-9A-3C-7A-00']},{'piiDataType':'Person name','values':['Christy Carroll']},{'piiDataType':'Social security number','values':['723-62-8144','778-62-8144']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario70")
  public void Pii_scenario_73() throws Exception {
    String decodedOutput = testPIIAPI("scenario73.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'Address','values':['425 Jennifer Fork Suite 467','North Aaronton, PW 61863']},{'piiDataType':'Credit card number','values':['4779122113206737']},{'piiDataType':'Email','values':['qjones@example.com']},{'piiDataType':'IPv4 Addresses','values':['225.100.129.116','23.2.168.71','247.221.71.204','249.225.56.130','86.45.53.221']},{'piiDataType':'IPv6 Addresses','values':['5d67:638e:4c10:8cb7:3ae7:1ff1:14ab:9f6e','67ab:52bc:2cc4:b808:cec1:f856:3b31:d26f','aaef:6eac:bad2:848c:0398:7558:f0d8:c207']},{'piiDataType':'Person name','values':['Joseph Graham']},{'piiDataType':'Social security number','values':['481-92-6557']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario70")
  public void Pii_scenario_74() throws Exception {
    String decodedOutput = testPIIAPI("scenario74.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'Address','values':['White Cross Co']},{'piiDataType':'Credit card number','values':['4012888888881881','4111111111111111','5105105105105100','5555555555554444']},{'piiDataType':'Financial statement','values':['$1178','$24,113.00','$27,204.44','$4,684.44','$4171','$6,765.56']},{'piiDataType':'IPv6 Addresses','values':['0ca0:afb7:0639:dd37:dc6d:14a2:c4c1:e2f2','11a7:f4ed:946f:c08a:c7a1:25aa:73c5:c8a3','8bb1:078d:a178:6de5:5459:4d3c:4da4:7338','98de:0196:f094:e3a2:c8bc:0105:8e91:57bc']},{'piiDataType':'MAC Addresses','values':['08:c5:42:56:6d:9e','38-F3-AB-F8-F6-27','66 69 OF AA 66 61','b9:74:6a:1e:5a:c4']},{'piiDataType':'Passport number','values':['TL1621875']},{'piiDataType':'Person name','values':['Jen Smith','Jim Brennan']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  @Test(description = "Test pii anonymization api with test data scenario70")
  public void Pii_scenario_75() throws Exception {
    String decodedOutput = testPIIAPI("scenario75.txt");
    log.info("Decrypted Data: " + decodedOutput);
    String expectedPiiData = "[{'piiDataType':'Address','values':[', 4632 Tempus St.','2511 Enim. Rd.','417-2469 Tellus. St.','Ap #462-9959 Sagittis Rd.','Ap #566-8117 Sed Rd.','Ap #688-9104 Purus Road','Avennes','Chungju','Hamburg','Leoben','P.O. Box 473','Trondheim']},{'piiDataType':'Birthdate','values':['19-Jul-95','26-May-96','3-May-10','30-Sep-98','4-Jul-03','9-Mar-86']},{'piiDataType':'Credit card number','values':['448 52882 28992 779','455614 636374 3965','4916 173 85 8229','5438 5366 4348 5521','5576686177845335']},{'piiDataType':'Email','values':['donec@aol.org','eu.augue@google.com','iaculis@protonmail.com','interdum.sed@outlook.net','lacinia.mattis@yahoo.org','libero@google.couk']},{'piiDataType':'IPv4 Addresses','values':['140.105.111.107','228.183.252.59','252.214.28.205','31.249.57.95','45.161.200.112']},{'piiDataType':'IPv6 Addresses','values':['2283:4a8b:3e3b:a117:0c35:c66c:e753:db2a','7ab4:3548:c0d3:3364:6615:4896:8f2b:b825','8cc7:3e0e:3dba:a7ac:9a95:b783:9838:37fa','d334:801a:b782:25c5:fd0f:71a3:b413:220c','f3c4:6cc3:e455:a843:2924:fc83:ad59:8fca']},{'piiDataType':'Person name','values':['Alyssa Fields']},{'piiDataType':'Phone number','values':['01223  539887','016977  7475','056 5626 4621','070 2644 2207','0800 899 5056','0948 333 7365']}]";
    validatePiiResponse(decodedOutput, expectedPiiData);
  }

  private String testPIIAPI(String testDatafileName) throws Exception {
    String inputData = readFile(piiDataFilePath + testDatafileName);
    String encodedOutput = EncryptDecryptHelper.encryptString(inputData, key);
    log.info("Encrypted Data: " + encodedOutput);
    Response response = piiApiHelper.piiApiV1(encodedOutput);
    Thread.sleep(10000);
    for (int count = 1; count <= 3; count++) {
      if (response.getStatusCode() != 200) {
        log.warn("Retrying count " + count);
        Thread.sleep(10000);
        response = piiApiHelper.piiApiV1(encodedOutput);
      } else
        break;
    }
    Assert.assertEquals(response.getStatusCode(), 200);
    log.info("API response:" + response.getBody().prettyPrint());
    String resData = response.getBody().asString().replace("\"", "");
    return EncryptDecryptHelper.decryptString(resData, key);
  }

  private void validatePiiResponse(String actualData, String expectedData) throws IOException {
    String fileContent = "";
    ObjectMapper objectMapper = new ObjectMapper();
    objectMapper.configure(JsonParser.Feature.ALLOW_SINGLE_QUOTES, true);
    JsonNode jsonNode2 = objectMapper.readTree(expectedData);
    JsonNode jsonNode1 = objectMapper.readTree(actualData);
    if (!jsonNode1.equals(jsonNode2)) {
      fileContent = "***** Actual response: *****" + System.lineSeparator() + actualData + System.lineSeparator() + "***** Expected response: *****" + System.lineSeparator() + expectedData;
      writeFile(testName, fileContent);
    }
    Assert.assertEquals(jsonNode1, jsonNode2);
  }

  private String readFile(String filePath) throws IOException {
    Path fileName = Path.of(filePath);
    String str = Files.readString(fileName);
    log.info(str);
    return str;
  }

  private void writeFile(String fileName, String jsonData) throws IOException {
    File dir = new File("test-output/Actual Results/pii");
    if (!dir.exists())
      dir.mkdirs();
    FileWriter fileWriter = new FileWriter(dir + "//" + fileName + ".txt", true);
    fileWriter.write(jsonData);
    // log.info(jsonData);
    fileWriter.close();
  }
}
