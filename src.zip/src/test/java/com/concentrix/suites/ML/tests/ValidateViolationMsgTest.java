package com.concentrix.suites.ML.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.BaseTests.MLBaseTest;
import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.helper.DBConnectionHelper;
import com.concentrix.automation.helper.GCSHelper;
import com.concentrix.automation.rest.ConversionUtil;
import com.concentrix.automation.service.streaming.pojo.request.TestData;
import com.concentrix.automation.service.streaming.pojo.response.Actions;
import com.concentrix.automation.service.streaming.pojo.response.GetLastImageProcessedStatusResponse;
import com.concentrix.automation.service.streaming.pojo.response.ResponseResult;
import com.concentrix.suites.ML.testdata.MLDataProvider;
import io.restassured.response.Response;
import lombok.extern.log4j.Log4j;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

@Listeners({app.getxray.xray.testng.listeners.XrayListener.class})
@Log4j
public class ValidateViolationMsgTest extends MLBaseTest {
  private DBConnectionHelper dbConnectionHelper;
  public static String objectKey;
  private Actions[] actions;

  @BeforeMethod(alwaysRun = true)
  public void setUp() {
    //postBaseLineImageToStreaming();
    dbConnectionHelper = DBConnectionHelper.getInstance();
  }

  //@XrayTest(key = "ORN-6316", summary = "validateIncidentTest", description = "Validate incidents getting created in incident table", labels = "E2E")
  @Test(groups = {"smoke"}, description = "Validate client action message in imageprocess_status_actions table", dataProviderClass = MLDataProvider.class, dataProvider = "getViolationData")
  public void validateViolationMsgTest(TestData testData) throws InterruptedException {
    log.info(testData);
    String violationMsg = "";
    String violationType = testData.getFilePath().split("/")[0];
    log.info(violationType);
    String imageFilePath = System.getProperty("user.dir") + File.separator + "src" + File.separator + "test" + File.separator + "resources" + File.separator + "ML" + File.separator;
    imageFilePath = imageFilePath + testData.getFilePath();
    String envName = System.getProperty("env");
    if (envName == null)
      envName = "qa";
    Response response;
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + File.separator + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    File file = new File(imageFilePath + File.separator + testData.getFileName());
    response = executeMlAPIs(file);
    assertResponseData(response, testData.getResultId());
    GetLastImageProcessedStatusResponse getLastImageProcessedStatusResponse = response.getBody().as(
        GetLastImageProcessedStatusResponse.class);
    String actionDataAlertMsg = getLastImageProcessedStatusResponse.getActionsNewFormat()[0].getActionData().getAlertMessage().toString();
    //String imagePathId = getLastImageProcessedStatusResponse.getImageCacheKey();
    Long imageBagId = getLastImageProcessedStatusResponse.getImageBagID();
    Thread.sleep(10000);

    try {
      ResultSet rs_status_action = dbConnectionHelper.executeQuery("SELECT * from fb_biometrics_" + envName + ".imageprocess_status_actions where imagebagid in (" + imageBagId + ")");
      Assert.assertTrue(rs_status_action.isBeforeFirst(), "image process ResultSet is empty");
      while (rs_status_action.next()){
        violationMsg = rs_status_action.getString("ClientActionsNewFormat");
        String empId = rs_status_action.getString("employeeId");
        Assert.assertNotNull(violationMsg);
        Assert.assertNotNull(empId);
       actions = ConversionUtil.deserializedResponse(violationMsg, Actions[].class);
        log.info("Violation msg: " + violationMsg);
        log.info("Employee Id: " + empId);
      }
      Assert.assertEquals(actions[0].getActionData().getAlertMessage().toString(),actionDataAlertMsg);
//      switch (violationType){
//        case "CP":
//          Assert.assertEquals(actions.getActionData().toString(),actionDataMsg);
//          break;
//        case "CP-PRE":
//          Assert.assertEquals(violationMsg,"tes1t");
//          break;
//        case "MP":
//          Assert.assertEquals(actions.getActionData().toString(),actionDataMsg);
//          break;
//        case "MP-PRE":
//          Assert.assertEquals(violationMsg,"test4");
//      }
      rs_status_action.close();
    } catch (Exception e) {
      log.error(e.getMessage());
    }
  }

  @AfterClass
  public void TearDown() throws SQLException {
    dbConnectionHelper.closeConnection();
  }
}
