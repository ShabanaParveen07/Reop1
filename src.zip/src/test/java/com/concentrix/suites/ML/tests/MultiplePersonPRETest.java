package com.concentrix.suites.ML.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.BaseTests.MLBaseTest;
import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.helper.GCSHelper;
import com.concentrix.automation.service.streaming.constants.EndPointConstants;
import com.concentrix.automation.service.streaming.pojo.request.TestData;
import com.concentrix.suites.ML.testdata.MLDataProvider;
import io.restassured.response.Response;
import lombok.extern.log4j.Log4j;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;

@Listeners({app.getxray.xray.testng.listeners.XrayListener.class})
@Log4j
public class MultiplePersonPRETest extends MLBaseTest {
  private final String imageFilePath = System.getProperty("user.dir") + File.separator + "src" + File.separator + "test" + File.separator + "resources" + File.separator + "ML" + File.separator + "MP-PRE" + File.separator;

  private int tpCount, fnCount, tnCount, fpCount = 0;
  int resultId = 0;

  public static String objectKey;
  private String imagePathId;

  @XrayTest(key = "ORN-3903", summary = "Multiple Person PRE True Positive Test", description = "Testing of multiple person PRE violations with pre-defined TP dataset", labels = "E2E")
  @Test(description = "Testing of multiple person PRE violations with pre-defined TP dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getMultiplePersonPRETP")
  public void multiplePersonPRE_TPTest(TestData testData) throws InterruptedException {
    log.info(testData);
    Response response;
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "TP/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "TP" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    File file = new File(imageFilePath + "TP" + File.separator + testData.getFileName());
    response = executeMlAPIs(file);
    if (response.getStatusCode() != 200)
      resultId = 0;
    else {
      resultId = response.path("result_id");
      imagePathId = response.path("imagecachekey");
    }
    assertResponseData(response, EndPointConstants.multiplePersonsPREResultId);
  }

  @XrayTest(key = "ORN-3905", summary = "Multiple Person PRE True Negatives Test", description = "Testing of cellphone PRE violations with pre-defined TN dataset", labels = "E2E")
  @Test(description = "Testing of multiple person PRE violations with pre-defined TN dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getMultiplePersonPRETN")
  public void multiplePersonPRE_TNTest(TestData testData) throws InterruptedException {
    log.info(testData);
    Response response;
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "TN/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "TN" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    File file = new File(imageFilePath + "TN" + File.separator + testData.getFileName());
    response = executeMlAPIs(file);
    if (response.getStatusCode() != 200){
      resultId = 0;
      log.info("Response: " + response.statusCode() + " || " + response.getStatusLine());
    }
    else {
      resultId = response.path("result_id");
      imagePathId = response.path("imagecachekey");
    }
    assertResponseData(response, EndPointConstants.successResultId);
  }

  @AfterMethod
  public void status(ITestResult result, ITestContext context) {
    log.info("Status of execution is:" + result.getStatus());
    String fileName = getTestName(result);
    try {
      if ("multiplePersonPRE_TPTest".equals(result.getName()) && result.getStatus() == ITestResult.SUCCESS) {
        log.info("Test case execution status is SUCCESS");
        File file = new File(imageFilePath + "TP" + File.separator + fileName);
        writeImageToPath(file, false);
        tpCount++;
      } else if ("multiplePersonPRE_TPTest".equals(result.getName()) && result.getStatus() == ITestResult.FAILURE) {
        File file = new File(imageFilePath + "TP" + File.separator + fileName);
        writeImageToPath(file, true);
        log.info("Test case execution status is FAILURE");
        saveActualResult(fileName, resultId, "multiplePersonPRE_TPTest", String.valueOf(EndPointConstants.multiplePersonsPREResultId), imageFilePath + "TP" + File.separator + fileName, imagePathId);
        fnCount++;
      } else if ("multiplePersonPRE_TNTest".equals(result.getName()) && result.getStatus() == ITestResult.SUCCESS) {
        File file = new File(imageFilePath + "TN" + File.separator + fileName);
        writeImageToPath(file, false);
        tnCount++;
      } else if ("multiplePersonPRE_TNTest".equals(result.getName()) && result.getStatus() == ITestResult.FAILURE) {
        log.info("Test case execution status is FAILURE");
        File file = new File(imageFilePath + "TN" + File.separator + fileName);
        writeImageToPath(file, true);
        saveActualResult(fileName, resultId, "multiplePersonPRE_TNTest", String.valueOf(EndPointConstants.successResultId), imageFilePath + "TN" + File.separator + fileName, imagePathId);
        fpCount++;
      } else if (result.getStatus() == ITestResult.SKIP) {
        log.info("Test case execution status is SKIP");
      }
      context.setAttribute("multiplePersonPRE", true);
      context.setAttribute("multiplePersonPRE_TP", tpCount);
      context.setAttribute("multiplePersonPRE_FN", fnCount);
      context.setAttribute("multiplePersonPRE_TN", tnCount);
      context.setAttribute("multiplePersonPRE_FP", fpCount);
      context.setAttribute("resultList", list);
    } catch (Exception e) {
      log.error(e.getMessage());
    }
  }
}
