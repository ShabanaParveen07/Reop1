package com.concentrix.suites.ML.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.BaseTests.MLBaseTest;
import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.helper.GCSHelper;
import com.concentrix.automation.service.streaming.constants.EndPointConstants;
import com.concentrix.automation.service.streaming.pojo.request.TestData;
import com.concentrix.suites.ML.testdata.MLDataProvider;
import io.restassured.response.Response;
import lombok.extern.log4j.Log4j;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;

/*
 This class contains Ml smoke test cases.
 */
@Listeners({app.getxray.xray.testng.listeners.XrayListener.class})
@Log4j
public class MLSmokeTest extends MLBaseTest {
  private final String imageFilePath = System.getProperty("user.dir") + File.separator + "src" + File.separator + "test" + File.separator + "resources" + File.separator + "ML" + File.separator;
  int resultId = 0;
  public static String objectKey;

  @XrayTest(key = "ORN-3861", summary = "Cell Phone PRE True Positives smoke Test", description = "Testing of cellphone PRE violations with pre-defined TP dataset", labels = "E2E")
  @Test(groups = {"smoke"}, description = "Smoke testing of cellphone PRE violations with pre-defined TP dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getSmokeCellPhonePRETP")
  public void cellPhonePRE_TPTest(TestData testData) {
    log.info(testData);
    Response response;
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "CP-PRE/TP/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "CP-PRE/TP" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    File file = new File(imageFilePath + "CP-PRE/TP" + File.separator + testData.getFileName());
    response = executeMlAPIs(file);
    //Check response status is not 204
    if (response.getStatusCode() == 204)
      resultId = 0;
    else
      resultId = response.path("result_id");
    assertResponseData(response, EndPointConstants.cellPhonePREResultId);
  }

  @XrayTest(key = "ORN-5558", summary = "Cell Phone PRE True Negatives smoke test", description = "Testing of cellphone PRE violations with pre-defined TP dataset", labels = "E2E")
  @Test(groups = {"smoke"}, description = "Smoke testing of cellphone PRE violations with pre-defined TN dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getSmokeCellPhonePRETN")
  public void cellPhonePRE_TNTest(TestData testData) {
    log.info(testData);
    Response response;
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "CP-PRE/TN/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "CP-PRE/TN" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    File file = new File(imageFilePath + "CP-PRE/TN" + File.separator + testData.getFileName());
    response = executeMlAPIs(file);
    //Check response status is not 204
    if (response.getStatusCode() == 204)
      resultId = 0;
    else
      resultId = response.path("result_id");
    assertResponseData(response, EndPointConstants.successResultId);
  }

  @XrayTest(key = "ORN-5558", summary = "Cell Phone True Positives smoke test", description = "Testing of cellphone Non-PRE violations with pre-defined True Positives dataset", labels = "E2E")
  @Test(groups = {"smoke"}, description = "Smoke testing of cellphone Non-PRE violations with pre-defined True Positives dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getSmokeCellPhoneTP")
  public void cellPhoneTPTest(TestData testData) {
    log.info("Test Data: " + testData);
    Response response;
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "CP/TP/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "CP/TP" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    File file = new File(imageFilePath + "CP/TP" + File.separator + testData.getFileName());
    response = executeMlAPIs(file);
    //Check response status is not 204
    if (response.getStatusCode() == 204)
      resultId = 0;
    else
      resultId = response.path("result_id");
    assertResponseData(response, EndPointConstants.cellPhoneResultId);
  }

  @XrayTest(key = "ORN-5558", summary = "Cell Phone True Negatives smoke test", description = "Testing of cellphone Non-PRE violations with pre-defined TN dataset", labels = "E2E")
  @Test(groups = {"smoke"}, description = "Smoke testing of cellphone Non-PRE violations with pre-defined TN dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getSmokeCellPhoneTN")
  public void cellPhoneTNTest(TestData testData) {
    log.info("Test Data: " + testData);
    Response response;
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "CP/TN/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "CP/TN" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    File file = new File(imageFilePath + "CP/TN" + File.separator + testData.getFileName());
    response = executeMlAPIs(file);
    //Check response status is not 204
    if (response.getStatusCode() == 204)
      resultId = 0;
    else
      resultId = response.path("result_id");
    assertResponseData(response, EndPointConstants.successResultId);
  }

  @XrayTest(key = "ORN-5558", summary = "Multiple Person PRE True Positive smoke Test", description = "Testing of multiple person PRE violations with pre-defined TP dataset", labels = "E2E")
  @Test(groups = {"smoke"}, description = "Smoke testing of multiple person PRE violations with pre-defined TP dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getSmokeMultiplePersonPRETP")
  public void multiplePersonPRE_TPTest(TestData testData) {
    log.info(testData);
    Response response;
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "MP-PRE/TP/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "MP-PRE/TP" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    File file = new File(imageFilePath + "MP-PRE/TP" + File.separator + testData.getFileName());
    response = executeMlAPIs(file);
    if (response.getStatusCode() == 204)
      resultId = 0;
    else
      resultId = response.path("result_id");
    assertResponseData(response, EndPointConstants.multiplePersonsPREResultId);
  }

  @XrayTest(key = "ORN-5558", summary = "Multiple Person PRE True Negatives smoke Test", description = "Testing of cellphone PRE violations with pre-defined TN dataset", labels = "E2E")
  @Test(groups = {"smoke"}, description = "Smoke testing of multiple person PRE violations with pre-defined TN dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getSmokeMultiplePersonPRETN")
  public void multiplePersonPRE_TNTest(TestData testData) {
    log.info(testData);
    Response response;
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "MP-PRE/TN/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "MP-PRE/TN" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    File file = new File(imageFilePath + "MP-PRE/TN" + File.separator + testData.getFileName());
    response = executeMlAPIs(file);
    if (response.getStatusCode() == 204)
      resultId = 0;
    else
      resultId = response.path("result_id");
    assertResponseData(response, EndPointConstants.successResultId);
  }


  @XrayTest(key = "ORN-5558", summary = "Multiple Person True Positive smoke test", description = "Testing of multiple person violations with pre-defined TP dataset", labels = "E2E")
  @Test(groups = {"smoke"}, description = "Smoke testing of multiple person violations with pre-defined TP dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getSmokeMultiplePersonTP")
  public void multiplePerson_TPTest(TestData testData) {
    log.info(testData);
    Response response;
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "MP/TP/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "MP/TP" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    File file = new File(imageFilePath + "MP/TP" + File.separator + testData.getFileName());
    response = executeMlAPIs(file);
    //Check response status is not 204
    if (response.getStatusCode() == 204)
      resultId = 0;
    else
      resultId = response.path("result_id");
    assertResponseData(response, EndPointConstants.multiplePersonsResultId);
  }

  @XrayTest(key = "ORN-5558", summary = "Multiple Person True Negatives smoke Test", description = "Testing of multiple person violations with pre-defined TN dataset", labels = "E2E")
  @Test(groups = {"smoke"}, description = "Smoke testing of multiple person violations with pre-defined TN dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getSmokeMultiplePersonTN")
  public void multiplePerson_TNTest(TestData testData) {
    log.info(testData);
    Response response;
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "MP/TN/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "MP/TN" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    File file = new File(imageFilePath + "MP/TN" + File.separator + testData.getFileName());
    response = executeMlAPIs(file);
    //Check response status is not 204
    if (response.getStatusCode() == 204)
      resultId = 0;
    else
      resultId = response.path("result_id");
    assertResponseData(response, EndPointConstants.successResultId);
  }
}
