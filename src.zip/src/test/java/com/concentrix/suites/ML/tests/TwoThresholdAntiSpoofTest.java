package com.concentrix.suites.ML.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.BaseTests.MLBaseTest;
import com.concentrix.automation.service.streaming.constants.EndPointConstants;
import com.concentrix.automation.service.streaming.pojo.request.TestData;
import com.concentrix.automation.service.streaming.pojo.response.ResponseResult;
import com.concentrix.suites.ML.testdata.MLDataProvider;
import lombok.extern.log4j.Log4j;
import org.assertj.core.api.Assertions;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.io.File;
import java.util.Objects;

@Listeners({app.getxray.xray.testng.listeners.XrayListener.class})
@Log4j
public class TwoThresholdAntiSpoofTest extends MLBaseTest {

  private final String imageFilePath = System.getProperty("user.dir") + File.separator + "src" + File.separator + "test" + File.separator + "resources" + File.separator + "ML" + File.separator + "twoThresholdSpoofImages" + File.separator;
  private int tpCount, fnCount, tnCount, fpCount, resultId = 0;
  double spoofScore = 0;
  final double SPOOF_THRESHOLD = 0.99;
  final double SPOOF_THRESHOLD_POSSIBILITY = 0.65;
  private String imagePathId = "";

  @XrayTest(key = "ORN-5043", summary = "Two Threshold Spoof Images positive Test", description = "Testing of spoof images with pre-defined TP dataset for two threshold", labels = "E2E")
  @Test(description = "Testing of spoof images with pre-defined TP dataset with two thresholds", dataProviderClass = MLDataProvider.class, dataProvider = "getTwoThresholdSpoofImageTP")
  public void twoThresholdSpoofTPTest(TestData testData) {
    log.info("Test Data: " + testData);
    String path = imageFilePath + "TP/" + testData.getFileName();
    ResponseResult responseResult = sendImageToFaceAuth(path, String.valueOf(EndPointConstants.FACE_AUTH_MODE_RESUME), "NoBlur");

    if (responseResult != null) {
      log.info(responseResult);
      resultId = responseResult.resultId;
      spoofScore = responseResult.spoofScore;
      log.info("Spoof Score:" + spoofScore);
    }

    Assertions.assertThat(spoofScore).isBetween(SPOOF_THRESHOLD_POSSIBILITY, SPOOF_THRESHOLD);
    Assert.assertEquals(responseResult.resultId, EndPointConstants.spoofPossibilityResultId);
    Assert.assertFalse(responseResult.isSpoof);
  }

  @XrayTest(key = "ORN-5044", summary = "Two Threshold Spoof Images negative Test", description = "Testing of spoof images with pre-defined TN dataset for two thresholds", labels = "E2E")
  @Test(description = "Testing of spoof images with pre-defined TN dataset with two thresholds", dataProviderClass = MLDataProvider.class, dataProvider = "getTwoThresholdSpoofImageTN")
  public void twoThresholdSpoofTNTest(TestData testData) {
    log.info("Test Data: " + testData);
    String path = imageFilePath + "TN/" + testData.getFileName();
    ResponseResult responseResult = sendImageToFaceAuth(path, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "NoBlur");

    if (responseResult != null) {
      log.info(responseResult);
      resultId = responseResult.resultId;
      spoofScore = responseResult.spoofScore;
    }

    Assertions.assertThat(responseResult.resultId).isIn(EndPointConstants.successResultId, EndPointConstants.spoofResultId);

    if (Objects.equals(responseResult.resultId, EndPointConstants.successResultId)) {
      Assert.assertFalse(responseResult.isSpoof);
      Assertions.assertThat(spoofScore).isEqualTo(0.0);
    } else if (Objects.equals(responseResult.resultId, EndPointConstants.spoofResultId)) {
      Assert.assertTrue(responseResult.isSpoof);
      Assertions.assertThat(spoofScore).isGreaterThan(SPOOF_THRESHOLD);
    }
  }

  @AfterMethod
  public void status(ITestResult result, ITestContext context) {
    String fileName = getTestName(result);

    log.info("Status of execution is:" + result.getStatus());

    try {
      if ("twoThresholdSpoofTPTest".equals(result.getName()) && result.getStatus() == ITestResult.SUCCESS) {
        log.info("Test case execution status is SUCCESS");
        File file = new File(imageFilePath + "TP/" + fileName);
        writeImageToPath(file, false);
        tpCount++;
      } else if ("twoThresholdSpoofTPTest".equals(result.getName()) && result.getStatus() == ITestResult.FAILURE) {
        log.info("Test case execution status is FAILURE");
        File file = new File(imageFilePath + "TP/" + fileName);
        writeImageToPath(file, true);
        saveActualResult(fileName, resultId, "twoThresholdSpoofTPTest", String.valueOf(EndPointConstants.spoofPossibilityResultId), imageFilePath + "TP/" + fileName,imagePathId);
        fnCount++;
      } else if ("twoThresholdSpoofTNTest".equals(result.getName()) && result.getStatus() == ITestResult.SUCCESS) {
        File file = new File(imageFilePath + "TN/" + fileName);
        writeImageToPath(file, false);
        tnCount++;
      } else if ("twoThresholdSpoofTNTest".equals(result.getName()) && result.getStatus() == ITestResult.FAILURE) {
        log.info("Test case execution status is FAILURE");
        File file = new File(imageFilePath + "TN/" + fileName);
        writeImageToPath(file, true);
        saveActualResult(fileName, resultId, "twoThresholdSpoofTPTest", String.valueOf(EndPointConstants.successResultId), imageFilePath + "TN/" + fileName,imagePathId);
        fpCount++;
      } else if (result.getStatus() == ITestResult.SKIP) {
        log.info("Test case execution status is SKIP");
      }

      context.setAttribute("spoofPossibilityTP", tpCount);
      context.setAttribute("spoofPossibilityFN", fnCount);
      context.setAttribute("spoofPossibilityTN", tnCount);
      context.setAttribute("spoofPossibilityFP", fpCount);
      context.setAttribute("resultList", list);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
