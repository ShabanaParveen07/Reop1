package com.concentrix.suites.ML.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.BaseTests.MLBaseTest;
import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.helper.GCSHelper;
import com.concentrix.automation.helper.streaming.StreamingApiHelper;
import com.concentrix.automation.service.streaming.constants.EndPointConstants;
import com.concentrix.automation.service.streaming.pojo.request.TestData;
import com.concentrix.automation.service.streaming.pojo.response.ResponseResult;
import com.concentrix.suites.ML.testdata.MLDataProvider;
import lombok.extern.log4j.Log4j;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.io.File;
import java.io.IOException;
import java.net.UnknownHostException;

@Listeners({app.getxray.xray.testng.listeners.XrayListener.class})
@Log4j
public class SpoofImageMultipleUserTest extends MLBaseTest {
  private String imageFilePath = System.getProperty("user.dir") + File.separator+ "src" + File.separator + "test" + File.separator + "resources" + File.separator + "ML" + File.separator;
  private int tpCount = 0;
  private int fnCount = 0;
  private int tnCount = 0;
  private int fpCount = 0;
  int resultId = 0;
  double spoofScore = 0;
  public static String objectKey;
  StreamingApiHelper streamingApiHelper;
  String lanId1 = "nunna.kiran@concentrix.com";
  String lanId2 = "sumit.agrawal1@concentrix.com";
  String lanId3 = "aishwarya.vatsa@concentrix.com";
  String lanId4 = "naga.k@concentrix.com";
  String lanId5 = "arun.yadav4@concentrix.com";
  String lanId6 = "shaik.shareef2@concentrix.com";

  String lanId7 = "shaik.parveen@concentrix.com";

  private String authToken4;
  private String authToken5;
  private String authToken6;
  private String authToken3;
  private String authToken1;
  private String authToken2;
  private String authToken7;
  @BeforeClass(alwaysRun = true)
  public void getAuthToken() throws UnknownHostException {
    streamingApiHelper = new StreamingApiHelper();
    authToken1 = generateAuthToken(lanId1);

    streamingApiHelper.refreshFaceStreaming(lanId2);
    streamingApiHelper.getCheckBaseValidation(lanId2);
    authToken2 = generateAuthToken(lanId2);

    streamingApiHelper.refreshFaceStreaming(lanId3);
    streamingApiHelper.getCheckBaseValidation(lanId3);
    authToken3 = generateAuthToken(lanId3);

    streamingApiHelper.refreshFaceStreaming(lanId4);
    streamingApiHelper.getCheckBaseValidation(lanId4);
    authToken4 = generateAuthToken(lanId4);

    streamingApiHelper.refreshFaceStreaming(lanId5);
    streamingApiHelper.getCheckBaseValidation(lanId5);
    authToken5 = generateAuthToken(lanId5);

    streamingApiHelper.refreshFaceStreaming(lanId6);
    streamingApiHelper.getCheckBaseValidation(lanId6);
    authToken6 = generateAuthToken(lanId6);

    streamingApiHelper.refreshFaceStreaming(lanId7);
    streamingApiHelper.getCheckBaseValidation(lanId7);
    authToken7 = generateAuthToken(lanId7);
  }

  @XrayTest(key = "ORN-4140", summary = "Spoof Images positive Test", description = "Testing of spoof images with pre-defined TP dataset", labels = "E2E")
  @Test(description = "Testing of spoof images with pre-defined TP dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getSpoofImageTP")
  public void spoofTPTest(TestData testData) throws InterruptedException, UnknownHostException {
    log.info("Test Data: " + testData);
    imageFilePath = "src/test/resources/ML/spoofImages/";
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "TP/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "TP" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    String path = imageFilePath + "TP/" + testData.getFileName();
    ResponseResult response = sendImageToFaceAuthWithAuthToken(path, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "NoBlur", lanId1,authToken1);
    if (response != null) {
      log.info(response);
      resultId = response.resultId;
    } else
      resultId = 0;
    Assert.assertEquals(response.resultId, EndPointConstants.spoofResultId);
    Assert.assertTrue(response.isSpoof);
  }

  @XrayTest(key = "ORN-4140", summary = "Spoof Images positive Test", description = "Testing of spoof images with pre-defined TP dataset", labels = "E2E")
  @Test(description = "Testing of spoof images with pre-defined TP dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getSpoofImage2TP")
  public void spoofTPTest2(TestData testData) throws InterruptedException, UnknownHostException {
     imageFilePath = "src/test/resources/ML/spoofImagesSumit/";
    log.info("Test Data: " + testData);
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "TP/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "TP" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    String path = imageFilePath + "TP/" + testData.getFileName();
    ResponseResult response = sendImageToFaceAuthWithAuthToken(path, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "NoBlur", lanId2,authToken2);
    if (response != null) {
      log.info(response);
      resultId = response.resultId;
      spoofScore = response.spoofScore;
    } else
      resultId = 0;
    Assert.assertEquals(response.resultId, EndPointConstants.spoofResultId);
    Assert.assertTrue(response.isSpoof);
  }

  @XrayTest(key = "ORN-4140", summary = "Spoof Images positive Test", description = "Testing of spoof images with pre-defined TP dataset", labels = "E2E")
  @Test(description = "Testing of spoof images with pre-defined TP dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getSpoofImage3TP")
  public void spoofTPTest3(TestData testData) throws InterruptedException, UnknownHostException {
    log.info("Test Data: " + testData);
    imageFilePath = "src/test/resources/ML/spoofImagesAishwarya/";
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "TP/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "TP" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    String path = imageFilePath + "TP/" + testData.getFileName();
    ResponseResult response = sendImageToFaceAuthWithAuthToken(path, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "NoBlur", lanId3,authToken3);
    if (response != null) {
      log.info(response);
      resultId = response.resultId;
      spoofScore = response.spoofScore;
    } else
      resultId = 0;
    Assert.assertEquals(response.resultId, EndPointConstants.spoofResultId);
    Assert.assertTrue(response.isSpoof);
  }

  @XrayTest(key = "ORN-4140", summary = "Spoof Images positive Test", description = "Testing of spoof images with pre-defined TP dataset", labels = "E2E")
  @Test(description = "Testing of spoof images with pre-defined TP dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getSpoofImage4TP")
  public void spoofTPTest4(TestData testData) throws InterruptedException, UnknownHostException {
    log.info("Test Data: " + testData);
    imageFilePath = "src/test/resources/ML/spoofImagesPreethi/";
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "TP/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "TP" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    String path = imageFilePath + "TP/" + testData.getFileName();
    ResponseResult response = sendImageToFaceAuthWithAuthToken(path, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "NoBlur", lanId4,authToken4);
    if (response != null) {
      log.info(response);
      resultId = response.resultId;
      spoofScore = response.spoofScore;
    } else
      resultId = 0;
    Assert.assertEquals(response.resultId, EndPointConstants.spoofResultId);
    Assert.assertTrue(response.isSpoof);
  }

  @XrayTest(key = "ORN-4140", summary = "Spoof Images positive Test", description = "Testing of spoof images with pre-defined TP dataset", labels = "E2E")
  @Test(description = "Testing of spoof images with pre-defined TP dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getSpoofImage5TP")
  public void spoofTPTest5(TestData testData) throws InterruptedException, UnknownHostException {
    log.info("Test Data: " + testData);
    imageFilePath = "src/test/resources/ML/spoofImagesArun/";
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "TP/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "TP" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    String path = imageFilePath + "TP/" + testData.getFileName();
    ResponseResult response = sendImageToFaceAuthWithAuthToken(path, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "NoBlur", lanId5,authToken5);
    if (response != null) {
      log.info(response);
      resultId = response.resultId;
      spoofScore = response.spoofScore;
    } else
      resultId = 0;
    Assert.assertEquals(response.resultId, EndPointConstants.spoofResultId);
    Assert.assertTrue(response.isSpoof);
  }

  @XrayTest(key = "ORN-4140", summary = "Spoof Images positive Test", description = "Testing of spoof images with pre-defined TP dataset", labels = "E2E")
  @Test(description = "Testing of spoof images with pre-defined TP dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getSpoofImage6TP")
  public void spoofTPTest6(TestData testData) throws InterruptedException, UnknownHostException {
    log.info("Test Data: " + testData);
    imageFilePath = "src/test/resources/ML/spoofImagesShareef/";
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "TP/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "TP" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    String path = imageFilePath + "TP/" + testData.getFileName();
    ResponseResult response = sendImageToFaceAuthWithAuthToken(path, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "NoBlur", lanId6,authToken6);
    if (response != null) {
      log.info(response);
      resultId = response.resultId;
      spoofScore = response.spoofScore;
    } else
      resultId = 0;
    Assert.assertEquals(response.resultId, EndPointConstants.spoofResultId);
    Assert.assertTrue(response.isSpoof);
  }

  @XrayTest(key = "ORN-4140", summary = "Spoof Images positive Test", description = "Testing of spoof images with pre-defined TP dataset", labels = "E2E")
  @Test(description = "Testing of spoof images with pre-defined TP dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getSpoofImage7TP")
  public void spoofTPTest7(TestData testData) throws InterruptedException, UnknownHostException {
    log.info("Test Data: " + testData);
    imageFilePath = "src/test/resources/ML/spoofImagesParveen/";
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "TP/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "TP" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    String path = imageFilePath + "TP/" + testData.getFileName();
    ResponseResult response = sendImageToFaceAuthWithAuthToken(path, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "NoBlur", lanId7,authToken7);
    if (response != null) {
      log.info(response);
      resultId = response.resultId;
      spoofScore = response.spoofScore;
    } else
      resultId = 0;
    Assert.assertEquals(response.resultId, EndPointConstants.spoofResultId);
    Assert.assertTrue(response.isSpoof);
  }

  @XrayTest(key = "ORN-4141", summary = "Spoof Images negative Test", description = "Testing of spoof images with pre-defined TN dataset", labels = "E2E")
  @Test(description = "Testing of spoof images with pre-defined TN dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getSpoofImageTN")
  public void spoofTNTest(TestData testData) throws InterruptedException, UnknownHostException {
    log.info("Test Data: " + testData);
    imageFilePath = "src/test/resources/ML/spoofImages/";
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "TN/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "TN" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    String path = imageFilePath + "TN/" + testData.getFileName();
    ResponseResult responseResult = sendImageToFaceAuthWithAuthToken(path, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "NoBlur", lanId1,authToken1);
    if (responseResult != null) {
      log.info(responseResult);
      resultId = responseResult.resultId;
      spoofScore = responseResult.spoofScore;
    } else
      resultId = 0;
    Assert.assertEquals(responseResult.resultId, EndPointConstants.successResultId);
    Assert.assertFalse(responseResult.isSpoof);
  }

  @XrayTest(key = "ORN-4141", summary = "Spoof Images negative Test", description = "Testing of spoof images with pre-defined TN dataset", labels = "E2E")
  @Test(description = "Testing of spoof images with pre-defined TN dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getSpoofImage2TN")
  public void spoofTNTest2(TestData testData) throws InterruptedException, UnknownHostException {
    log.info("Test Data: " + testData);
    imageFilePath = "src/test/resources/ML/spoofImagesSumit/";
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "TN/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "TN" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    String path = imageFilePath + "TN/" + testData.getFileName();
    ResponseResult responseResult = sendImageToFaceAuthWithAuthToken(path, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "NoBlur", lanId2,authToken2);
    if (responseResult != null) {
      log.info(responseResult);
      resultId = responseResult.resultId;
      spoofScore = responseResult.spoofScore;
    } else
      resultId = 0;
    Assert.assertEquals(responseResult.resultId, EndPointConstants.successResultId);
    Assert.assertFalse(responseResult.isSpoof);
  }

  @XrayTest(key = "ORN-4141", summary = "Spoof Images negative Test", description = "Testing of spoof images with pre-defined TN dataset", labels = "E2E")
  @Test(description = "Testing of spoof images with pre-defined TN dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getSpoofImage3TN")
  public void spoofTNTest3(TestData testData) throws InterruptedException, UnknownHostException {
    log.info("Test Data: " + testData);
    imageFilePath = "src/test/resources/ML/spoofImagesAishwarya/";
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "TN/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "TN" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    String path = imageFilePath + "TN/" + testData.getFileName();
    ResponseResult responseResult = sendImageToFaceAuthWithAuthToken(path, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "NoBlur", lanId3,authToken3);
    if (responseResult != null) {
      log.info(responseResult);
      resultId = responseResult.resultId;
      spoofScore = responseResult.spoofScore;
    } else
      resultId = 0;
    Assert.assertEquals(responseResult.resultId, EndPointConstants.successResultId);
    Assert.assertFalse(responseResult.isSpoof);
  }

  @XrayTest(key = "ORN-4141", summary = "Spoof Images negative Test", description = "Testing of spoof images with pre-defined TN dataset", labels = "E2E")
  @Test(description = "Testing of spoof images with pre-defined TN dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getSpoofImage4TN")
  public void spoofTNTest4(TestData testData) throws InterruptedException, UnknownHostException {
    log.info("Test Data: " + testData);
    imageFilePath = "src/test/resources/ML/spoofImagesPreethi/";
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "TN/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "TN" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    String path = imageFilePath + "TN/" + testData.getFileName();
    ResponseResult responseResult = sendImageToFaceAuthWithAuthToken(path, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "NoBlur", lanId4,authToken4);
    if (responseResult != null) {
      log.info(responseResult);
      resultId = responseResult.resultId;
      spoofScore = responseResult.spoofScore;
    } else
      resultId = 0;
    Assert.assertEquals(responseResult.resultId, EndPointConstants.successResultId);
    Assert.assertFalse(responseResult.isSpoof);
  }

  @XrayTest(key = "ORN-4141", summary = "Spoof Images negative Test", description = "Testing of spoof images with pre-defined TN dataset", labels = "E2E")
  @Test(description = "Testing of spoof images with pre-defined TN dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getSpoofImage5TN")
  public void spoofTNTest5(TestData testData) throws InterruptedException, UnknownHostException {
    log.info("Test Data: " + testData);
    imageFilePath = "src/test/resources/ML/spoofImagesArun/";
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "TN/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "TN" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    String path = imageFilePath + "TN/" + testData.getFileName();
    ResponseResult responseResult = sendImageToFaceAuthWithAuthToken(path, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "NoBlur", lanId5,authToken5);
    if (responseResult != null) {
      log.info(responseResult);
      resultId = responseResult.resultId;
      spoofScore = responseResult.spoofScore;
    } else
      resultId = 0;
    Assert.assertEquals(responseResult.resultId, EndPointConstants.successResultId);
    Assert.assertFalse(responseResult.isSpoof);
  }

  @XrayTest(key = "ORN-4141", summary = "Spoof Images negative Test", description = "Testing of spoof images with pre-defined TN dataset", labels = "E2E")
  @Test(description = "Testing of spoof images with pre-defined TN dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getSpoofImage6TN")
  public void spoofTNTest6(TestData testData) throws InterruptedException, UnknownHostException {
    log.info("Test Data: " + testData);
    imageFilePath = "src/test/resources/ML/spoofImagesShareef/";
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "TN/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "TN" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    String path = imageFilePath + "TN/" + testData.getFileName();
    ResponseResult responseResult = sendImageToFaceAuthWithAuthToken(path, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "NoBlur", lanId6,authToken6);
    if (responseResult != null) {
      log.info(responseResult);
      resultId = responseResult.resultId;
      spoofScore = responseResult.spoofScore;
    } else
      resultId = 0;
    Assert.assertEquals(responseResult.resultId, EndPointConstants.successResultId);
    Assert.assertFalse(responseResult.isSpoof);
  }

  @XrayTest(key = "ORN-4141", summary = "Spoof Images negative Test", description = "Testing of spoof images with pre-defined TN dataset", labels = "E2E")
  @Test(description = "Testing of spoof images with pre-defined TN dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getSpoofImage7TN")
  public void spoofTNTest7(TestData testData) throws InterruptedException, UnknownHostException {
    log.info("Test Data: " + testData);
    imageFilePath = "src/test/resources/ML/spoofImagesParveen/";
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "TN/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "TN" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    String path = imageFilePath + "TN/" + testData.getFileName();
    ResponseResult responseResult = sendImageToFaceAuthWithAuthToken(path, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "NoBlur", lanId7,authToken7);
    if (responseResult != null) {
      log.info(responseResult);
      resultId = responseResult.resultId;
      spoofScore = responseResult.spoofScore;
    } else
      resultId = 0;
    Assert.assertEquals(responseResult.resultId, EndPointConstants.successResultId);
    Assert.assertFalse(responseResult.isSpoof);
  }

  @AfterMethod
  public void status(ITestResult result, ITestContext context) {
    String fileName = getTestName(result);
    log.info("Status of execution is:" + result.getStatus());
    try {
      if (("spoofTPTest".equals(result.getName()) || "spoofTPTest2".equals(result.getName())|| "spoofTPTest3".equals(result.getName()) || "spoofTPTest4".equals(result.getName())
          || "spoofTPTest5".equals(result.getName()) || "spoofTPTest6".equals(result.getName()) || "spoofTPTest7".equals(result.getName())) && result.getStatus() == ITestResult.SUCCESS) {
        log.info("Test case execution status is SUCCESS");
        File file = new File(imageFilePath + "TP/" + fileName);
        writeImageToPath(file, false);
        tpCount++;
      } else if (("spoofTPTest".equals(result.getName()) || "spoofTPTest2".equals(result.getName()) || "spoofTPTest3".equals(result.getName()) || "spoofTPTest4".equals(result.getName())
          || "spoofTPTest5".equals(result.getName()) || "spoofTPTest6".equals(result.getName()) || "spoofTPTest7".equals(result.getName())) && result.getStatus() == ITestResult.FAILURE) {
        log.info("Test case execution status is FAILURE");
        File file = new File(imageFilePath + "TP/" + fileName);
        writeImageToPath(file, true);
        saveActualResult(fileName, resultId, spoofScore, "spoofTPTest", String.valueOf(EndPointConstants.spoofResultId), imageFilePath + "TP/" + fileName);
        fnCount++;
      } else if (("spoofTNTest".equals(result.getName()) || "spoofTNTest2".equals(result.getName()) || "spoofTNTest3".equals(result.getName())
          || "spoofTNTest4".equals(result.getName()) || "spoofTNTest5".equals(result.getName()) || "spoofTNTest6".equals(result.getName()) || "spoofTNTest7".equals(result.getName())) && result.getStatus() == ITestResult.SUCCESS) {
        File file = new File(imageFilePath + "TN/" + fileName);
        writeImageToPath(file, false);
        tnCount++;
      } else if (("spoofTNTest".equals(result.getName()) || "spoofTNTest2".equals(result.getName()) || "spoofTNTest3".equals(result.getName())
          || "spoofTNTest4".equals(result.getName()) || "spoofTNTest5".equals(result.getName()) || "spoofTNTest6".equals(result.getName()) || "spoofTNTest7".equals(result.getName())) && result.getStatus() == ITestResult.FAILURE) {
        log.info("Test case execution status is FAILURE");
        File file = new File(imageFilePath + "TN/" + fileName);
        writeImageToPath(file, true);
        saveActualResult(fileName, resultId, spoofScore, "spoofTNTest", String.valueOf(EndPointConstants.successResultId), imageFilePath + "TN/" + fileName);
        fpCount++;
      } else if (result.getStatus() == ITestResult.SKIP) {
        log.info("Test case execution status is SKIP");
      }
      context.setAttribute("spoofTP", tpCount);
      context.setAttribute("spoofFN", fnCount);
      context.setAttribute("spoofTN", tnCount);
      context.setAttribute("spoofFP", fpCount);
      context.setAttribute("resultList", list);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
