package com.concentrix.suites.ML.tests;

import com.concentrix.automation.helper.DBConnectionHelper;
import lombok.extern.log4j.Log4j;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Calendar;

@Log4j
public class CheckUserDetailsDbTest {

  private DBConnectionHelper dbConnectionHelper;

  @BeforeMethod(alwaysRun = true)
  public void postBaseLineImage() throws InterruptedException {
    dbConnectionHelper = DBConnectionHelper.getInstance();
  }

  @Test
  public void verifyUserDetailsInDb() throws SQLException {
    String envName = System.getProperty("env");
    if (envName == null)
      envName = "qa";
    try {
      ResultSet biometrics_employee_rs = dbConnectionHelper.executeQuery("SELECT * from fb_biometrics_" + envName + ".employee where employeeId in ('" + 102181355 + "')");
      ResultSet enrollment_employee_rs = dbConnectionHelper.executeQuery("SELECT * from fb_enrollment_" + envName + ".employee where employeeId in ('" + 102181355 + "')");
      Assert.assertTrue(biometrics_employee_rs.isBeforeFirst(), "biometrics employee ResultSet is empty");
      Assert.assertTrue(enrollment_employee_rs.isBeforeFirst(), "enrollment employee ResultSet is empty");
      while (biometrics_employee_rs.next()) {
        Assert.assertEquals(biometrics_employee_rs.getString("employeeId"), "102181355");
        log.info("fb_biometrics_qa.employee Data: " + biometrics_employee_rs.getString("employeeId"));
      }
      while (enrollment_employee_rs.next()) {
        Assert.assertEquals(enrollment_employee_rs.getString("employeeId"), "102181355");
        log.info("fb_enrollment_qa.employee Data: " + enrollment_employee_rs.getString("employeeId"));
      }
      biometrics_employee_rs.close();
      enrollment_employee_rs.close();

      ResultSet biometrics_agentEnrollment_rs = dbConnectionHelper.executeQuery("SELECT * from fb_biometrics_" + envName + ".AgentEnrollment where employeeId in ('" + 102181355 + "')");
      ResultSet enrollment_agentEnrollment_rs = dbConnectionHelper.executeQuery("SELECT * from fb_enrollment_" + envName + ".AgentEnrollment where employeeId in ('" + 102181355 + "')");

      while (biometrics_agentEnrollment_rs.next()) {
        Assert.assertEquals(biometrics_agentEnrollment_rs.getString("employeeId"), "102181355");
        log.info("fb_biometrics_qa.employee Data: " + biometrics_agentEnrollment_rs.getString("employeeId"));
      }
      while (enrollment_agentEnrollment_rs.next()) {
        Assert.assertEquals(enrollment_agentEnrollment_rs.getString("employeeId"), "102181355");
        log.info("fb_enrollment_qa.employee Data: " + enrollment_agentEnrollment_rs.getString("employeeId"));
      }
      biometrics_agentEnrollment_rs.close();
      enrollment_agentEnrollment_rs.close();
      ResultSet biometrics_employeeAdditionalInformation_rs = dbConnectionHelper.executeQuery("SELECT * from fb_biometrics_" + envName + ".Employeeadditionalinformation where SRC_PERSON_ID in ('" + 102181355 + "')");
      ResultSet enrollment_employeeAdditionalInformation_rs = dbConnectionHelper.executeQuery("SELECT * from fb_enrollment_" + envName + ".Employeeadditionalinformation where SRC_PERSON_ID in ('" + 102181355 + "')");

      while (biometrics_employeeAdditionalInformation_rs.next()) {
        Assert.assertEquals(biometrics_employeeAdditionalInformation_rs.getString("SRC_PERSON_ID"), "102181355");
        log.info("fb_biometrics_qa.employee Data: " + biometrics_employeeAdditionalInformation_rs.getString("SRC_PERSON_ID"));
      }
      while (enrollment_employeeAdditionalInformation_rs.next()) {
        Assert.assertEquals(enrollment_employeeAdditionalInformation_rs.getString("SRC_PERSON_ID"), "102181355");
        log.info("fb_enrollment_qa.employee Data: " + enrollment_employeeAdditionalInformation_rs.getString("SRC_PERSON_ID"));
      }
      biometrics_employeeAdditionalInformation_rs.close();
      enrollment_employeeAdditionalInformation_rs.close();

    } catch (Exception e) {
      log.error("Error in verifyUserDetailsInDb" + e.getMessage());
    } finally {
      dbConnectionHelper.closeConnection();
    }
  }

  @Test
  public void insertUserDetails() throws SQLException {
    try {
   //   Date date = new Date();
      SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss") ;
      //String currentDateTime = format.format(date);
      // create a sql date object so we can use it in our INSERT statement
      Timestamp ts1 = Timestamp.valueOf(LocalDateTime.now());
     // log.info(ts1);
      Calendar calendar = Calendar.getInstance();
      java.sql.Date startDate = new Date(calendar.getTime().getTime());
      Timestamp ts= new Timestamp(startDate.getTime());
      SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
      System.out.println(formatter.format(ts));
      // the mysql insert statement
      String query = "INSERT INTO fb_enrollment_qa.employee" +
          "(employeeId," +
          "lanid," +
          "firstname," +
          "lastname," +
          "emailaddr," +
          "supervisorempid," +
          "utcoffsetinsecs," +
          "securecx_active_flag," +
          "ExtAppAccessInd)"
          + " values ( ?, ?, ?, ?,?,?,?,?,?)";
      PreparedStatement preparedStmt = dbConnectionHelper.getConnection().prepareStatement(query);
      preparedStmt.setString(1, "102181355");
      preparedStmt.setString(2, "sumit.agrawal1@concentrix.com");
      preparedStmt.setString(3, "SUMIT");
      preparedStmt.setString(4, "AGRAWAL");
      preparedStmt.setString(5, "sumit.agrawal1@concentrix.com");
      preparedStmt.setInt(6, 1916);
      preparedStmt.setInt(7, 0);
      preparedStmt.setString(8, "Y");
      preparedStmt.setBoolean(9, false);
      preparedStmt.execute();
    } catch (Exception e) {
      System.err.println("Got an exception!");
      System.err.println(e.getMessage());
    }finally {
      dbConnectionHelper.closeConnection();
    }
  }

  @Test
  public void insertAgentEnrollment() throws SQLException {
    try {
      Calendar calendar = Calendar.getInstance();
      java.sql.Date startDate = new Date(calendar.getTime().getTime());
      SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
      System.out.println(formatter.format(startDate));

      String query = "INSERT INTO fb_enrollment_qa.AgentEnrollment" +
          "(Employeeid," +
          "SsoId," +
          "Ipaddress," +
          "Workstationname," +
          "EnrollmentActionDate," +
          "Enrollmentflag," +
          "EnrollmentDate)"
          + " values ( ?, ?, ?, ?,?,?,?)";
      PreparedStatement preparedStmt = dbConnectionHelper.getConnection().prepareStatement(query);
      preparedStmt.setString(1, "102181355");
      preparedStmt.setString(2, "sumit.agrawal1@concentrix.com");
      preparedStmt.setString(3, "10.187.163.79");
      preparedStmt.setString(4, "System.Net.IPHostEntry");
      preparedStmt.setString(5, "sumit.agrawal1@concentrix.com");
      preparedStmt.setString(6, "E");
      preparedStmt.setString(7, "2023-11-21 11:54:03");
      preparedStmt.execute();
    } catch (Exception e) {
      log.error("Got an exception!");
      log.error(e.getMessage());
    } finally {
      dbConnectionHelper.closeConnection();
    }
  }

  @Test
  public void insertEmployeeAdditionalInformationDetails() throws SQLException {
    try {
      String query = "INSERT INTO fb_enrollment_qa.Employeeadditionalinformation" +
          "(SRC_PERSON_ID," + "FIRST_NAME," + "LAST_NAME," + "HR_STATUS," + "PERSON_STATUS," + "SUPERVISOR_ID," + "SRC_FIN_DEPT_ID," + "AGENT_IND," +
          "ACTIVITY_ID," + "CITY_RESIDENCE," + "STATE_RESIDENCE," + "HR_REGION," + "GLBU," + "ALLIED_SOURCE," + "SRC_SITE_ID," + "SITE_NAME," +
          "SRC_CITY_ID," + "CITY_NAME," + "SRC_CAMPUS_ID," + "CAMPUS_NAME," + "SRC_STATE_ID," + "STATE_NAME," + "SRC_COUNTRY_ID," + "COUNTRY_NAME," +
          "SRC_REGION_ID," + "REGION_NAME," + "SRC_JOB_CODE," + "JOBTITLE_NAME," + "JOBCATEGORY_NAME," + "PERSONTYPE_NAME," + "SRC_PROJECT_ID,"
          + "PROJECT_NAME," + "SRC_PROGRAM_ID," + "PROGRAM_NAME," + "SRC_CLIENT_ID," + "CLIENT_NAME," + "SRC_VERTICAL_ID," +
          "VERTICAL_NAME," + "LAN_ID," + "WORKDAY_IND," + "JOB_FAMILY_GROUP," + "CURRENCY," + "WKDY_LOB," + "BUSINESS_TITLE," + "SAGE_MSA_ID,"
          + "SAGE_MSA_NAME," + "WKDY_MSA_ID," + "SAGE_DEPT_ID," + "SAGE_DEPT_NAME," + "SUBPROGRAM_ID," + "SUBPROGRAM_NAME," + "LAST_DAY_WORKED," +
          "CNX_LAN_ID," + "CNX_SAMACCOUNT," + "WINNT_LOGIN," + "JOB_UPDATE_DT)"
          + " values ( ?, ?, ?, ?,?, ?,?,?,?,?, ?,?,?,?,? ,?,?,?,?,?, ?,?,?,?,?, ?,?,?,?,? ,?,?,?,?,? ,?,?,?,?,?, ?,?,?,?,? ,?,?,?,?,? ,?,?,?,?,?,?)";
      PreparedStatement preparedStmt = dbConnectionHelper.getConnection().prepareStatement(query);
      preparedStmt.setString(1, "102181355"); //SRC_PERSON_ID
      preparedStmt.setString(2, "SUMIT"); //FIRST_NAME
      preparedStmt.setString(3, "AGRAWAL"); //LAST_NAME
      preparedStmt.setString(4, "A"); //HR_STATUS
      preparedStmt.setString(5, "A"); //PERSON_STATUS

      preparedStmt.setString(6, "100226302"); //SUPERVISOR_ID
      preparedStmt.setString(7, "W13118"); //SRC_FIN_DEPT_ID
      preparedStmt.setString(8, "N");  //AGENT_IND
      preparedStmt.setString(9, "W0ZDX2"); //ACTIVITY_ID
      preparedStmt.setString(10,"Pune"); //CITY_RESIDENCE

      preparedStmt.setString(11,"Maharashtra"); //STATE_RESIDENCE
      preparedStmt.setString(12,"INDIA");  //HR_REGION
      preparedStmt.setString(13,"50040"); //GLBU
      preparedStmt.setString(14,"CMG"); //ALLIED_SOURCE
      preparedStmt.setString(15,"00183"); //SRC_SITE_ID

      preparedStmt.setString(16,"Pune India"); //SITE_NAME
      preparedStmt.setString(17,"PUNE"); //SRC_CITY_ID
      preparedStmt.setString(18,"PUNE"); //CITY_NAME
      preparedStmt.setString(19,"00183"); //SRC_CAMPUS_ID
      preparedStmt.setString(20,"Pune, RMZ");  //CAMPUS_NAME

      preparedStmt.setString(21,"MAHARASHTR"); //SRC_STATE_ID
      preparedStmt.setString(22,"MAHARASHTRA"); //STATE_NAME
      preparedStmt.setString(23,"CRYIN"); //SRC_COUNTRY_ID
      preparedStmt.setString(24,"INDIA"); //COUNTRY_NAME
      preparedStmt.setString(25,"ASIA"); //SRC_REGION_ID

      preparedStmt.setString(26,"ASIA"); //REGION_NAME
      preparedStmt.setString(27,"JC1954"); //SRC_JOB_CODE
      preparedStmt.setString(28,"Sr. Software Test Engineer II"); //JOBTITLE_NAME
      preparedStmt.setString(29,"Staff"); //JOBCATEGORY_NAME
      preparedStmt.setString(30,"Regular"); //PERSONTYPE_NAME

      preparedStmt.setString(31,"W0028392"); //SRC_PROJECT_ID
      preparedStmt.setString(32,"SecureCX"); //PROJECT_NAME
      preparedStmt.setString(33,"OPOTHER_PG"); //SRC_PROGRAM_ID
      preparedStmt.setString(34,"OPEX_OTHER PGM"); //PROGRAM_NAME
      preparedStmt.setString(35,"OPEXOTHER"); //SRC_CLIENT_ID

      preparedStmt.setString(36,"OPEXOTHER"); //CLIENT_NAME
      preparedStmt.setString(37,"OTHER"); //SRC_VERTICAL_ID
      preparedStmt.setString(38,"Other"); // VERTICAL_NAME
      preparedStmt.setString(39,"sagr1355@india.convergys.com"); //LAN_ID
      preparedStmt.setString(40,"N"); //WORKDAY_IND

      preparedStmt.setString(41,"Application Development Group"); //JOB_FAMILY_GROUP
      preparedStmt.setString(42,"INR"); //CURRENCY
      preparedStmt.setString(43,"App Dev - Quality Assurance"); //WKDY_LOB
      preparedStmt.setString(44,"Sr. Software Test Engineer II"); //BUSINESS_TITLE
      preparedStmt.setString(45,"SECURECX"); //SAGE_MSA_ID

      preparedStmt.setString(46,"SecureCX"); //SAGE_MSA_NAME
      preparedStmt.setString(47,"5166 - Opexother - SECURECX"); //WKDY_MSA_ID
      preparedStmt.setString(48,"CSSDEVASIA"); //SAGE_DEPT_ID
      preparedStmt.setString(49,"(CORP) CSS Asia Development"); //SAGE_DEPT_NAME
      preparedStmt.setString(50,"OPOTHER_SP"); //SUBPROGRAM_ID

      preparedStmt.setString(51,"OPEX_OTHER SUB");  //SUBPROGRAM_NAME
      preparedStmt.setString(52,"0001-01-01"); //LAST_DAY_WORKED
      preparedStmt.setString(53,"sumit.agrawal1@concentrix.com"); //CNX_LAN_ID
      preparedStmt.setString(54,"sumit.agrawal1"); //CNX_SAMACCOUNT
      preparedStmt.setString(55,"sumit.agrawal1@concentrix.com"); //WINNT_LOGIN

      preparedStmt.setString(56,"2023-01-12 12:11:56"); //JOB_UPDATE_DT

      preparedStmt.execute();
    } catch (Exception e) {
      log.error("Got an exception!");
      log.error(e.getMessage());
    }finally {
      dbConnectionHelper.closeConnection();
    }
  }
}
