package com.concentrix.suites.ML.testdata;

import com.concentrix.automation.helper.FileHelper;
import com.concentrix.automation.service.streaming.pojo.request.TestData;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.testng.annotations.DataProvider;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;

public class MLDataProvider {

  private final static String jsonFilePath = "src/test/resources/ML/";

  @DataProvider(name = "getCellPhoneTP", parallel = false)
  public static Object[][] getCellPhoneTPData() throws IOException {
    //FileHelper.createJsonFile(jsonFilePath + "CP/TP",17);
    return readJsonFile("CellPhone_TP.json");
  }

  @DataProvider(name = "getCellPhoneTN", parallel = false)
  public static Object[][] getCellPhoneTNData() throws IOException {
    //FileHelper.createJsonFile(jsonFilePath + "CP/TN",5);
    return readJsonFile("CellPhone_TN.json");
  }

  @DataProvider(name = "getCellPhonePRETP")
  public static Object[][] getCellPhonePRETPData() throws IOException {
    //FileHelper.createJsonFile(jsonFilePath + "CP-PRE/TP",5);
    return readJsonFile("CP-PRE_TP.json");
  }

  @DataProvider(name = "getCellPhonePRETN")
  public static Object[][] getCellPhonePRETNData() throws IOException {
    return readJsonFile("CP-PRE_TN.json");
  }

  @DataProvider(name = "getNoFaceFoundTP", parallel = false)
  public static Object[][] getNoFaceFoundTPData() throws IOException {
    return readJsonFile("NoFaceFound_TP.json");
  }

  @DataProvider(name = "getNoFaceFoundTN", parallel = false)
  public static Object[][] getNoFaceFoundTNData() throws IOException {
    return readJsonFile("NoFaceFound_TN.json");
  }

  @DataProvider(name = "getMultiplePersonPRETP")
  public static Object[][] getMultiplePersonPRETPData() throws IOException {
   // FileHelper.createJsonFile(jsonFilePath + "MP-PRE/TP",43);
    return readJsonFile("MP-PRE_TP.json");
  }

  @DataProvider(name = "getMultiplePersonPRETN")
  public static Object[][] getMultiplePersonPRETNData() throws IOException {
    return readJsonFile("MP-PRE_TN.json");
  }

  @DataProvider(name = "getMultiplePersonTP")
  public static Object[][] getMultiplePersonTPData() throws IOException {
   // FileHelper.createJsonFile(jsonFilePath + "MP-PRE/TP",16);
    return readJsonFile("MultiplePerson_TP.json");
  }

  @DataProvider(name = "getMultiplePersonTN")
  public static Object[][] getMultiplePersonTNData() throws IOException {
    return readJsonFile("MultiplePerson_TN.json");
  }

  @DataProvider(name = "getFacialAuthenticationFailedImageTP", parallel = false)
  public static Object[][] getFacialAuthenticationFailedImageTPData() throws IOException {
    return readJsonFile("FacialAuthenticationFailed_TP.json");
  }

  @DataProvider(name = "getFacialAuthenticationFailedImageTN", parallel = false)
  public static Object[][] getFacialAuthenticationFailedImageTNData() throws IOException {
    return readJsonFile("FacialAuthenticationFailed_TN.json");
  }
  @DataProvider(name = "getFacialAuthenticationImageTN", parallel = false)
  public static Object[][] getFacialAuthenticationImageTNData() throws IOException {
   // FileHelper.createJsonFile(jsonFilePath + "FacialAuthenticationSumit/TN",5);
    return readJsonFile("FacialAuthenticationSumit_TN.json");
  }

  @DataProvider(name = "getFacialAuthenticationAishwaryaImageTN", parallel = false)
  public static Object[][] getFacialAuthenticationImageAishwaryaTNData() throws IOException {
   // FileHelper.createJsonFile(jsonFilePath + "FacialAuthenticationAishwarya/TN",5);
    return readJsonFile("FacialAuthenticationAishwarya_TN.json");
  }


  @DataProvider(name = "getSpoofImageTP", parallel = false)
  public static Object[][] getSpoofImageTPData() throws IOException {
    return readJsonFile("spoof_TP.json");
  }

  @DataProvider(name = "getSpoofImageTN", parallel = false)
  public static Object[][] getSpoofImageTNData() throws IOException {
    return readJsonFile("spoof_TN.json");
  }
  @DataProvider(name = "getSpoofImage2TP", parallel = false)
  public static Object[][] getSpoofImage2TPData() throws IOException {
    //FileHelper.createJsonFile(jsonFilePath + "spoofImagesAishwarya/TP",9);
    return readJsonFile("spoof_sumit_TP.json");
  }

  @DataProvider(name = "getSpoofImage2TN")
  public static Object[][] getSpoofImage2TNData() throws IOException {
    //FileHelper.createJsonFile(jsonFilePath + "spoofImagesAishwarya/TN",5);
    return readJsonFile("spoof_sumit_TN.json");
  }

  @DataProvider(name = "getSpoofImage3TP")
  public static Object[][] getSpoofImage3TPData() throws IOException {
   // FileHelper.createJsonFile(jsonFilePath + "spoofImagesAishwarya/TP",9);
    return readJsonFile("spoof_aishwarya_TP.json");
  }

  @DataProvider(name = "getSpoofImage3TN")
  public static Object[][] getSpoofImage3TNData() throws IOException {
    //FileHelper.createJsonFile(jsonFilePath + "spoofImagesAishwarya/TN",5);
    return readJsonFile("spoof_aishwarya_TN.json");
  }
  @DataProvider(name = "getSpoofImage4TP")
  public static Object[][] getSpoofImage4TPData() throws IOException {
    FileHelper.createJsonFile(jsonFilePath + "spoofImagesPreethi/TP",9);
    return readJsonFile("spoof_preethi_TP.json");
  }

  @DataProvider(name = "getSpoofImage4TN")
  public static Object[][] getSpoofImage4TNData() throws IOException {
    FileHelper.createJsonFile(jsonFilePath + "spoofImagesPreethi/TN",5);
    return readJsonFile("spoof_preethi_TN.json");
  }
  @DataProvider(name = "getSpoofImage5TP")
  public static Object[][] getSpoofImage5TPData() throws IOException {
    FileHelper.createJsonFile(jsonFilePath + "spoofImagesArun/TP",9);
    return readJsonFile("spoof_arun_TP.json");
  }

  @DataProvider(name = "getSpoofImage5TN")
  public static Object[][] getSpoofImage5TNData() throws IOException {
    FileHelper.createJsonFile(jsonFilePath + "spoofImagesArun/TN",5);
    return readJsonFile("spoof_arun_TN.json");
  }
  @DataProvider(name = "getSpoofImage6TP")
  public static Object[][] getSpoofImage6TPData() throws IOException {
    FileHelper.createJsonFile(jsonFilePath + "spoofImagesShareef/TP",9);
    return readJsonFile("spoof_shareef_TP.json");
  }

  @DataProvider(name = "getSpoofImage6TN")
  public static Object[][] getSpoofImage6TNData() throws IOException {
    FileHelper.createJsonFile(jsonFilePath + "spoofImagesShareef/TN",5);
    return readJsonFile("spoof_shareef_TN.json");
  }

  @DataProvider(name = "getSpoofImage7TP")
  public static Object[][] getSpoofImage7TPData() throws IOException {
    FileHelper.createJsonFile(jsonFilePath + "spoofImagesParveen/TP",9);
    return readJsonFile("spoof_parveen_TP.json");
  }

  @DataProvider(name = "getSpoofImage7TN")
  public static Object[][] getSpoofImage7TNData() throws IOException {
    FileHelper.createJsonFile(jsonFilePath + "spoofImagesParveen/TN",5);
    return readJsonFile("spoof_parveen_TN.json");
  }

  @DataProvider(name = "getTwoThresholdSpoofImageTP")
  public static Object[][] getTwoThresholdSpoofImageTP() throws IOException {
    return readJsonFile("twoThresholdSpoof_TP.json");
  }

  @DataProvider(name = "getTwoThresholdSpoofImageTN")
  public static Object[][] getTwoThresholdSpoofImageTN() throws IOException {
    return readJsonFile("twoThresholdSpoof_TN.json");
  }

  @DataProvider(name = "getSmokeCellPhonePRETP")
  public static Object[][] getSmokeCellPhonePRETPData() throws IOException {
    return readJsonFile("CP-PRE_TP_smoke.json");
  }

  @DataProvider(name = "getSmokeCellPhonePRETN")
  public static Object[][] getSmokeCellPhonePRETNData() throws IOException {
    return readJsonFile("CP-PRE_TN_smoke.json");
  }

  @DataProvider(name = "getSmokeCellPhoneTP", parallel = false)
  public static Object[][] getSmokeCellPhoneTPData() throws IOException {
    return readJsonFile("CellPhone_TP_smoke.json");
  }

  @DataProvider(name = "getSmokeCellPhoneTN", parallel = false)
  public static Object[][] getSmokeCellPhoneTNData() throws IOException {
    return readJsonFile("CellPhone_TN_smoke.json");
  }
  @DataProvider(name = "getSmokeMultiplePersonPRETP")
  public static Object[][] getSmokeMultiplePersonPRETPData() throws IOException {
    return readJsonFile("MP-PRE_TP_smoke.json");
  }

  @DataProvider(name = "getSmokeMultiplePersonPRETN")
  public static Object[][] getSmokeMultiplePersonPRETNData() throws IOException {
    return readJsonFile("MP-PRE_TN_smoke.json");
  }

  @DataProvider(name = "getSmokeMultiplePersonTP")
  public static Object[][] getSmokeMultiplePersonTPData() throws IOException {
    return readJsonFile("MultiplePerson_TP_smoke.json");
  }

  @DataProvider(name = "getSmokeMultiplePersonTN")
  public static Object[][] getSmokeMultiplePersonTNData() throws IOException {
    return readJsonFile("MultiplePerson_TN_smoke.json");
  }

  @DataProvider(name = "getViolationData")
  public static Object[][] getViolationData() throws IOException {
    return readJsonFile("ViolationImages.json");
  }

  @DataProvider(name = "getVisionSpoofTP", parallel = false)
  public static Object[][] getVisionSpoofTPData() throws IOException {
    //FileHelper.createJsonFile(jsonFilePath + "CP/TN",5);
    return readJsonFile("SpoofImageValidation.json");
  }

  private static Object[][] readJsonFile(String fileName) throws IOException {
    ObjectMapper mapper = new ObjectMapper();
    List<TestData> data = Arrays.asList(mapper.readValue(Paths.get(jsonFilePath + fileName).toFile(), TestData[].class));
    Object[][] jsonData = new Object[data.size()][1];
    int index = 0;
    for (Object[] each : jsonData) {
      each[0] = data.get(index++);
    }
    return jsonData;
  }
}
