package com.concentrix.suites.ML.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.BaseTests.MLBaseTest;
import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.helper.GCSHelper;
import com.concentrix.automation.service.streaming.constants.EndPointConstants;
import com.concentrix.automation.service.streaming.pojo.request.TestData;
import com.concentrix.automation.service.streaming.pojo.response.ResponseResult;
import com.concentrix.suites.ML.testdata.MLDataProvider;
import lombok.extern.log4j.Log4j;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;

@Listeners({ app.getxray.xray.testng.listeners.XrayListener.class })
@Log4j
public class SpoofImageTest extends MLBaseTest {

  private final String imageFilePath = System.getProperty("user.dir")+ File.separator + "src" + File.separator + "test" + File.separator + "resources" + File.separator + "ML" + File.separator + "spoofImages" + File.separator;
  private int tpCount = 0;
  private int fnCount = 0;
  private int tnCount = 0;
  private int fpCount = 0;
  int resultId = 0;
  double spoofScore = 0;
  private String imagePathId = "";
  public static String objectKey;

  @XrayTest(key = "ORN-4140", summary = "Spoof Images positive Test", description = "Testing of spoof images with pre-defined TP dataset", labels = "E2E")
  @Test(description = "Testing of spoof images with pre-defined TP dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getSpoofImageTP")
  public void spoofTPTest(TestData testData) {
    log.info("Test Data: " + testData);
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "TP/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
              ConfigurationFileHelper.getInstance().getProjectId(),
              ConfigurationFileHelper.getInstance().getBucketName(),
              objectKey,
              imageFilePath + "TP" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    String path = imageFilePath + "TP" + File.separator + testData.getFileName();
    ResponseResult responseResult = sendImageToFaceAuth(path, String.valueOf(EndPointConstants.FACE_AUTH_MODE_RESUME), "NoBlur");
    if (responseResult != null) {
      log.info(responseResult);
      resultId = responseResult.resultId;
     // will enable once changes deployed to UAT/PT
     //spoofScore = responseResult.spoofScore;
    } else
      resultId = 0;
    Assert.assertEquals(responseResult.resultId, EndPointConstants.spoofResultId);
    Assert.assertTrue(responseResult.isSpoof);
  }

  @XrayTest(key = "ORN-4141", summary = "Spoof Images negative Test", description = "Testing of spoof images with pre-defined TN dataset", labels = "E2E")
  @Test(description = "Testing of spoof images with pre-defined TN dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getSpoofImageTN")
  public void spoofTNTest(TestData testData) {
    log.info("Test Data: " + testData);
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "TN/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
              ConfigurationFileHelper.getInstance().getProjectId(),
              ConfigurationFileHelper.getInstance().getBucketName(),
              objectKey,
              imageFilePath + "TN" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    String path = imageFilePath + "TN" + File.separator + testData.getFileName();
    ResponseResult responseResult = sendImageToFaceAuth(path, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "NoBlur");
    if (responseResult != null) {
      log.info(responseResult);
      resultId = responseResult.resultId;
     //spoofScore = responseResult.spoofScore;
    } else
      resultId = 0;
    Assert.assertEquals(responseResult.resultId, EndPointConstants.successResultId);
    Assert.assertFalse(responseResult.isSpoof);
  }

  @AfterMethod
  public void status(ITestResult result, ITestContext context) {
    String fileName = getTestName(result);
    log.info("Status of execution is:" + result.getStatus());
    try {
      if ("spoofTPTest".equals(result.getName()) && result.getStatus() == ITestResult.SUCCESS) {
        log.info("Test case execution status is SUCCESS");
        File file = new File(imageFilePath + "TP" + File.separator + fileName);
        writeImageToPath(file,false);
        tpCount++;
      } else if ("spoofTPTest".equals(result.getName()) && result.getStatus() == ITestResult.FAILURE) {
        log.info("Test case execution status is FAILURE");
        File file = new File(imageFilePath + "TP" + File.separator + fileName);
        writeImageToPath(file,true);
       // saveActualResult(fileName, resultId,spoofScore, "spoofTPTest", String.valueOf(EndPointConstants.spoofResultId), imageFilePath + "TP/" + fileName);
        saveActualResult(fileName, resultId, "spoofTPTest", String.valueOf(EndPointConstants.spoofResultId), imageFilePath + "TP" + File.separator + fileName,imagePathId);
        fnCount++;
      } else if ("spoofTNTest".equals(result.getName()) && result.getStatus() == ITestResult.SUCCESS) {
        File file = new File(imageFilePath + "TN" + File.separator + fileName);
        writeImageToPath(file,false);
        tnCount++;
      } else if ("spoofTNTest".equals(result.getName()) && result.getStatus() == ITestResult.FAILURE) {
        log.info("Test case execution status is FAILURE");
        File file = new File(imageFilePath + "TN" + File.separator  + fileName);
        writeImageToPath(file,true);
       // saveActualResult(fileName, resultId,spoofScore, "spoofTNTest", String.valueOf(EndPointConstants.successResultId), imageFilePath + "TN/" + fileName);
        saveActualResult(fileName, resultId, "spoofTNTest", String.valueOf(EndPointConstants.successResultId), imageFilePath + "TN/" + fileName,imagePathId);
        fpCount++;
      } else if (result.getStatus() == ITestResult.SKIP) {
        log.info("Test case execution status is SKIP");
      }

      context.setAttribute("spoofTP", tpCount);
      context.setAttribute("spoofFN", fnCount);
      context.setAttribute("spoofTN", tnCount);
      context.setAttribute("spoofFP", fpCount);
      context.setAttribute("resultList", list);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

}
