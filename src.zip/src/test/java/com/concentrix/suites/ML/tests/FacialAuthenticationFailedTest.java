package com.concentrix.suites.ML.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.BaseTests.MLBaseTest;
import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.helper.GCSHelper;
import com.concentrix.automation.helper.streaming.StreamingApiHelper;
import com.concentrix.automation.rest.ConversionUtil;
import com.concentrix.automation.service.streaming.constants.EndPointConstants;
import com.concentrix.automation.service.streaming.pojo.request.TestData;
import com.concentrix.automation.service.streaming.pojo.response.ResponseResult;
import com.concentrix.suites.ML.testdata.MLDataProvider;
import lombok.extern.log4j.Log4j;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.io.File;
import java.io.IOException;
import java.net.UnknownHostException;

@Listeners({app.getxray.xray.testng.listeners.XrayListener.class})
@Log4j
public class FacialAuthenticationFailedTest extends MLBaseTest {

  private String imageFilePath = System.getProperty("user.dir") + File.separator + "src" + File.separator + "test" + File.separator + "resources" + File.separator + "ML" + File.separator + "FacialAuthenticationFailed" + File.separator;
  private int tpCount, fnCount, tnCount, fpCount = 0;
  int resultId = 0;
  public static String objectKey;
  double spoofScore = 0;
  StreamingApiHelper streamingApiHelper;
  private String imagePathId = "";
  String accuracy = "";
  String resData = "";
  String lanId1 = "sumit.agrawal1@concentrix.com";
  String lanId2 = "nunna.kiran@concentrix.com";
  String lanId3 = "aishwarya.vatsa@concentrix.com";
  private String authToken1;
  private String authToken2;
  private String authToken3;

  @BeforeClass(alwaysRun = true)
  public void getAuthToken() throws UnknownHostException {
    streamingApiHelper = new StreamingApiHelper();
    streamingApiHelper.refreshFaceStreaming(lanId1);
    streamingApiHelper.getCheckBaseValidation(lanId1);
    authToken1 = generateAuthToken(lanId1);

    streamingApiHelper.refreshFaceStreaming(lanId2);
    streamingApiHelper.getCheckBaseValidation(lanId2);
    authToken2 = generateAuthToken(lanId2);

    streamingApiHelper.refreshFaceStreaming(lanId3);
    streamingApiHelper.getCheckBaseValidation(lanId3);
    authToken3 = generateAuthToken(lanId3);

  }

  @XrayTest(key = "ORN-4619", summary = "Facial Authentication Failed TP Test", description = "Testing of facial authentication with pre-defined TP dataset", labels = "E2E")
  @Test(description = "Testing of facialAuthenticationFailed violations with pre-defined TP dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getFacialAuthenticationFailedImageTP")
  public void facialAuthenticationFailed_TPTest(TestData testData) throws InterruptedException {
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "TP/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    System.out.println(objectKey);
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "TP" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    String path = imageFilePath + "TP" + File.separator + testData.getFileName();
    ResponseResult response = sendImageToFaceAuthWithAuthToken(path, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "NoBlur", lanId2, authToken2);
    if (response != null) {
      log.info(response);
      resultId = response.resultId;
    } else
      resultId = 0;
//    System.out.println(responseResult);
//    resultId = responseResult.resultId;
    Assert.assertEquals(response.resultId, EndPointConstants.facialAuthenticationFailedResultId);
  }

  @XrayTest(key = "ORN-4621", summary = "Facial Authentication Failed TN Test", description = "Testing of facial authentication with pre-defined TN dataset", labels = "E2E")
  @Test(description = "Testing of facialAuthenticationFailed violations with pre-defined TN dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getFacialAuthenticationFailedImageTN")
  public void facialAuthenticationFailed_TNTest(TestData testData) throws InterruptedException {
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "TN/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "TN" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    String path = imageFilePath + "TN" + File.separator + testData.getFileName();
    ResponseResult response = sendImageToFaceAuthWithAuthToken(path, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "NoBlur", lanId2, authToken2);
    if (response != null) {
      log.info(response);
      resultId = response.resultId;
      spoofScore = response.spoofScore;
      accuracy = response.accuracy;
      resData = ConversionUtil.convertObjectToString(response);
    } else
      resultId = 0;
    Assert.assertEquals(response.resultId, EndPointConstants.successResultId);
    Assert.assertFalse(response.isSpoof);
  }

  @XrayTest(key = "ORN-4621", summary = "Test Facial Authentication with live images", description = "Testing of facial Authentication with pre-defined TN dataset", labels = "E2E")
  @Test(description = "Testing of facial Authentication with pre-defined TN dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getFacialAuthenticationImageTN")
  public void facialAuthenticationSumit_TNTest(TestData testData) throws InterruptedException {
    imageFilePath = "src/test/resources/ML/FacialAuthenticationSumit/";
    log.info("Test Data: " + testData);
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "TN/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "TN" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    String path = imageFilePath + "TN/" + testData.getFileName();
    ResponseResult response = sendImageToFaceAuthWithAuthToken(path, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "NoBlur", lanId1, authToken1);
    if (response != null) {
      log.info(response);
      resultId = response.resultId;
      spoofScore = response.spoofScore;
      accuracy = response.accuracy;
      resData = ConversionUtil.convertObjectToString(response);
    } else
      resultId = 0;
    Assert.assertEquals(response.resultId, EndPointConstants.successResultId);
    Assert.assertFalse(response.isSpoof);
  }

  @XrayTest(key = "ORN-4141", summary = "Spoof Images negative Test", description = "Testing of spoof images with pre-defined TN dataset", labels = "E2E")
  @Test(description = "Testing of spoof images with pre-defined TN dataset", dataProviderClass = MLDataProvider.class, dataProvider = "getFacialAuthenticationAishwaryaImageTN")
  public void facialAuthenticationAishwarya_TNTest(TestData testData) throws InterruptedException {
    log.info("Test Data: " + testData);
    imageFilePath = "src/test/resources/ML/FacialAuthenticationAishwarya/";
    objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "TN/" + testData.getFileName();
    objectKey = objectKey.replaceAll("\\\\", "/");
    try {
      GCSHelper.downloadObject(
          ConfigurationFileHelper.getInstance().getProjectId(),
          ConfigurationFileHelper.getInstance().getBucketName(),
          objectKey,
          imageFilePath + "TN" + File.separator + testData.getFileName());
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
    String path = imageFilePath + "TN/" + testData.getFileName();
    ResponseResult responseResult = sendImageToFaceAuthWithAuthToken(path, String.valueOf(EndPointConstants.FACE_AUTH_MODE_STARTUP), "NoBlur", lanId3,authToken3);
    if (responseResult != null) {
      log.info(responseResult);
      resultId = responseResult.resultId;
      spoofScore = responseResult.spoofScore;
      accuracy = responseResult.accuracy;
      resData = ConversionUtil.convertObjectToString(responseResult);
    } else
      resultId = 0;
    Assert.assertEquals(responseResult.resultId, EndPointConstants.successResultId);
    Assert.assertFalse(responseResult.isSpoof);
  }

  @AfterMethod
  public void status(ITestResult result, ITestContext context) {
    String fileName = getTestName(result);
    System.out.println("Status of execution is:" + result.getStatus());
    try {
      if ("facialAuthenticationFailed_TPTest".equals(result.getName()) && result.getStatus() == ITestResult.SUCCESS) {
        System.out.println("Test case execution status is SUCCESS");
        File file = new File(imageFilePath + "TP/" + fileName);
        writeImageToPath(file, false);
        tpCount++;
      } else if ("facialAuthenticationFailed_TPTest".equals(result.getName()) && result.getStatus() == ITestResult.FAILURE) {
        System.out.println("Test case execution status is FAILURE");
        //fileName = getTestName(result);
        File file = new File(imageFilePath + "TP" + File.separator + fileName);
        writeImageToPath(file, true);
        //saveActualResult(fileName, resultId, "facialAuthenticationFailed_TPTest", String.valueOf(EndPointConstants.spoofResultId), imageFilePath + "TP" + File.separator + fileName, imagePathId);
        saveActualResult(fileName, resultId, spoofScore, resData, accuracy, "spoofTPTest", String.valueOf(EndPointConstants.successResultId), imageFilePath + "TP/" + fileName);
        fnCount++;
      } else if ("facialAuthenticationFailed_TNTest".equals(result.getName()) && result.getStatus() == ITestResult.SUCCESS) {
        File file = new File(imageFilePath + "TN/" + fileName);
        writeImageToPath(file, false);
        tnCount++;
      } else if ("facialAuthenticationFailed_TNTest".equals(result.getName()) && result.getStatus() == ITestResult.FAILURE) {
        System.out.println("Test case execution status is FAILURE");
     //   fileName = getTestName(result);
        File file = new File(imageFilePath + "TN" + File.separator + fileName);
        writeImageToPath(file, true);
        //saveActualResult(fileName, resultId, "facialAuthenticationFailed_TNTest", String.valueOf(EndPointConstants.successResultId), imageFilePath + "TN" + File.separator + fileName, imagePathId);
        saveActualResult(fileName, resultId, spoofScore, resData, accuracy, "facialAuthenticationFailed_TNTest", String.valueOf(EndPointConstants.successResultId), imageFilePath + "TN" + File.separator + fileName);
        fpCount++;
      } else if ("facialAuthenticationSumit_TNTest".equals(result.getName()) && result.getStatus() == ITestResult.SUCCESS) {
        File file = new File(imageFilePath + "TN/" + fileName);
        writeImageToPath(file, false);
        tnCount++;
      } else if ("facialAuthenticationSumit_TNTest".equals(result.getName()) && result.getStatus() == ITestResult.FAILURE) {
        System.out.println("Test case execution status is FAILURE");
        //fileName = getTestName(result);
        File file = new File(imageFilePath + "TN" + File.separator + fileName);
        writeImageToPath(file, true);
        //saveActualResult(fileName, resultId, "facialAuthenticationSumit_TNTest", String.valueOf(EndPointConstants.successResultId), imageFilePath + "TN" + File.separator + fileName, imagePathId);
        saveActualResult(fileName, resultId, spoofScore, resData, accuracy, "facialAuthenticationSumit_TNTest", String.valueOf(EndPointConstants.successResultId), imageFilePath + "TN" + File.separator + fileName);
        fpCount++;
      }else if ("facialAuthenticationAishwarya_TNTest".equals(result.getName()) && result.getStatus() == ITestResult.SUCCESS) {
        File file = new File(imageFilePath + "TN/" + fileName);
        writeImageToPath(file, false);
        tnCount++;
      } else if ("facialAuthenticationAishwarya_TNTest".equals(result.getName()) && result.getStatus() == ITestResult.FAILURE) {
        System.out.println("Test case execution status is FAILURE");
        //fileName = getTestName(result);
        File file = new File(imageFilePath + "TN" + File.separator + fileName);
        writeImageToPath(file, true);
        //saveActualResult(fileName, resultId, "facialAuthenticationSumit_TNTest", String.valueOf(EndPointConstants.successResultId), imageFilePath + "TN" + File.separator + fileName, imagePathId);
        saveActualResult(fileName, resultId, spoofScore, resData, accuracy, "facialAuthenticationAishwarya_TNTest", String.valueOf(EndPointConstants.successResultId), imageFilePath + "TN" + File.separator + fileName);
        fpCount++;
      }
      else if (result.getStatus() == ITestResult.SKIP) {
        System.out.println("Test case execution status is SKIP");
      }
      context.setAttribute("facialAuthenticationFailed", true);
      context.setAttribute("facialAuthenticationFailed_TP", tpCount);
      context.setAttribute("facialAuthenticationFailed_FN", fnCount);
      context.setAttribute("facialAuthenticationFailed_TN", tnCount);
      context.setAttribute("facialAuthenticationFailed_FP", fpCount);
      context.setAttribute("resultList", list);
    } catch (Exception e) {
      e.printStackTrace();
    }

  }
}
