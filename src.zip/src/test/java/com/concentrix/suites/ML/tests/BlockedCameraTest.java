package com.concentrix.suites.ML.tests;

import app.getxray.xray.testng.annotations.XrayTest;
import com.concentrix.BaseTests.MLBaseTest;

import com.concentrix.automation.helper.Base64Helper;
import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.helper.DownloadImagesHelper;
import com.concentrix.automation.helper.GCSHelper;

import com.concentrix.automation.service.streaming.constants.EndPointConstants;

import io.restassured.response.Response;
import lombok.extern.log4j.Log4j;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Ignore;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.io.File;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import static io.restassured.RestAssured.given;


@Listeners({app.getxray.xray.testng.listeners.XrayListener.class})
@Log4j
public class BlockedCameraTest extends MLBaseTest {

  private int tpCount, fnCount, tnCount, fpCount = 0;

  public static String objectKey;

  private final String imageFilePath = System.getProperty("user.dir")+ File.separator + "src" + File.separator + "test" + File.separator + "resources" + File.separator + "ML" + File.separator;

    @XrayTest(key = "ORN-3651", summary = "Blocked Camera TP Test", description = "Testing of blocked camera violations with pre-defined TP dataset", labels = "E2E")
    @Test(groups = {"smoke"}, description = "Testing of blocked camera violations with pre-defined TP dataset")
    public void blockedCameraTPTest() {
        Response response;
        objectKey = imageFilePath.substring(imageFilePath.indexOf("ML")) + "blockedCamera/" + "blk.png";
        objectKey = objectKey.replaceAll("\\\\", "/");
        try {
            GCSHelper.downloadObject(
                    ConfigurationFileHelper.getInstance().getProjectId(),
                    ConfigurationFileHelper.getInstance().getBucketName(),
                    objectKey,
                    imageFilePath + "blockedCamera" + File.separator + "blk.png");
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage());
        }
        File file = new File(imageFilePath + "blockedCamera" + File.separator + "blk.png");
        response = executeMlAPIs(file);
        assertResponseData(response,EndPointConstants.blockedCameraResultId);
    }


  @Test(description = "Generate auth token test")
  public void GenerateAuth() throws Exception {
    //	GenerateAuthToken();

  }

  private String readFile(String filePath) throws IOException {
    // Creating a path choosing file from local
    // directory by creating an object of Path class
    Path fileName
        = Path.of(filePath);
    // Now calling Files.readString() method to
    // read the file
    String str = Files.readString(fileName);
    // Printing the string
    System.out.println(str);
    return str;
  }

  @Test
  public void saveImages() throws IOException {
    try {
      String imagePathData = readFile("C:\\projects\\Azure_local_Download\\Azure_local_Download\\gkepart2.txt");
      String[] ids = imagePathData.split("\\r\\n");
      log.info("Image data: " + ids);
      DownloadImagesHelper downloadImagesHelper = new DownloadImagesHelper();
      downloadImagesHelper.downloadImagesFromGKE(ids);
    } catch (Exception e) {
      log.error("Exception in SaveImage: " + e.getMessage());
    }

  }

  @Test
  public void encodeDecode() throws IOException {
   String pass = Base64Helper.encodePassword("");
    log.info("Encoded password:" + pass);
    String password = Base64Helper.decodePassword("");
    log.info("Decoded password:" + password);
  }

  @AfterMethod
  public void status(ITestResult result, ITestContext context) {
    log.info("Status of execution is:" + result.getStatus());
    try {
      if ("blockedCameraTPTest".equals(result.getName()) && result.getStatus() == ITestResult.SUCCESS) {
        log.info("Test case execution status is SUCCESS");
        tpCount++;
      } else if ("blockedCameraTPTest".equals(result.getName()) && result.getStatus() == ITestResult.FAILURE) {
        log.info("Test case execution status is FAILURE");
        fnCount++;
      } else if ("cellPhoneViolationTNTest".equals(result.getName()) && result.getStatus() == ITestResult.SUCCESS) {
        tnCount++;
      } else if ("cellPhoneViolationTNTest".equals(result.getName()) && result.getStatus() == ITestResult.FAILURE) {
        log.info("Test case execution status is FAILURE");
        fpCount++;
      } else if (result.getStatus() == ITestResult.SKIP) {
        log.info("Test case execution status is SKIP");
      }
      context.setAttribute("blockedCamera", true);
      context.setAttribute("blockedCameraTP", tpCount);
      context.setAttribute("blockedCameraFN", fnCount);
      context.setAttribute("blockedCameraTN", tnCount);
      context.setAttribute("blockedCameraFP", fpCount);
      context.setAttribute("resultList", list);
    } catch (Exception e) {
      e.printStackTrace();

    }
  }
}
