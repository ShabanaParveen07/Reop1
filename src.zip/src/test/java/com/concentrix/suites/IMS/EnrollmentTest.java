package com.concentrix.suites.IMS;

import com.concentrix.BaseTests.ConcentrixBaseTest;
import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.helper.CoreApiHelper;
import com.concentrix.automation.helper.streaming.StreamingApiHelper;
import com.concentrix.automation.service.core.pojo.request.EnrollmentApprovalRequest;
import com.concentrix.automation.service.core.pojo.request.FaceTrainingRequest;
import com.concentrix.automation.service.core.pojo.response.EnrollmentApprovalResponse;
import com.concentrix.automation.service.streaming.constants.EndPointConstants;
import com.concentrix.automation.service.streaming.pojo.response.GeneralResponse;
import com.concentrix.listeners.SuiteListener;
import io.restassured.response.Response;
import lombok.extern.log4j.Log4j;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.io.File;

import static com.concentrix.automation.helper.DateHelper.convertTimeToGivenDateFormat;

@Log4j
@Listeners(SuiteListener.class)
public class EnrollmentTest extends ConcentrixBaseTest {
  String bearerAuth;
  StreamingApiHelper streamingApiHelper;
  CoreApiHelper coreApiHelper;
  private final String imageFilePath = System.getProperty("user.dir") + File.separator + "src" + File.separator + "test" + File.separator + "resources" + File.separator + "ML" + File.separator + "EnrollmentImages" + File.separator;
  Response response;

  @BeforeClass(alwaysRun = true)
  public void beforeClass(ITestContext context) {
    bearerAuth = (String) context.getSuite().getAttribute("bearerAuthToken");
  }

  @Test(groups = {"smoke"},description = "Check enrollment functionality")
  public void enrollmentTest() throws InterruptedException {
    coreApiHelper = new CoreApiHelper();
    streamingApiHelper = new StreamingApiHelper();
    String frontImagePath = imageFilePath + "front.png";
    String leftImagePath = imageFilePath + "left.png";
    String rightImagePath = imageFilePath + "right.png";
    String frontImage = imageToBase64Converter(frontImagePath);
    String leftImage = imageToBase64Converter(leftImagePath);
    String rightImage = imageToBase64Converter(rightImagePath);
    String timeStamp = convertTimeToGivenDateFormat("yyyy-MM-dd HH:mm:ss");
    FaceTrainingRequest faceTrainingRequestFront = FaceTrainingRequest.builder().image(frontImage).lanID(ConfigurationFileHelper.getInstance().getLanID())
        .systemIP(ipAddress.toString().split("/")[1]).systemName(hostName).employeeId(ConfigurationFileHelper.getInstance()
            .getEmployeeId()).timestamp(timeStamp).imageProfile("F").build();

    FaceTrainingRequest faceTrainingRequestLeft = FaceTrainingRequest.builder().image(leftImage).lanID(ConfigurationFileHelper.getInstance().getLanID())
        .systemIP(ipAddress.toString().split("/")[1]).systemName(hostName).employeeId(ConfigurationFileHelper.getInstance()
            .getEmployeeId()).timestamp(timeStamp).imageProfile("L").build();

    FaceTrainingRequest faceTrainingRequestRight = FaceTrainingRequest.builder().image(rightImage).lanID(ConfigurationFileHelper.getInstance().getLanID())
        .systemIP(ipAddress.toString().split("/")[1]).systemName(hostName).employeeId(ConfigurationFileHelper.getInstance()
            .getEmployeeId()).timestamp(timeStamp).imageProfile("R").build();

    EnrollmentApprovalRequest enrollmentApprovalRequest = EnrollmentApprovalRequest.builder().employeeId(ConfigurationFileHelper.getInstance()
        .getEmployeeId()).enrollmentflag("E").remarks("").enrollmentAction("").loggedInUserEmployeeId(ConfigurationFileHelper.getInstance()
        .getEmployeeId()).build();

    GeneralResponse response = coreApiHelper.faceTraining(faceTrainingRequestFront, bearerAuth).as(GeneralResponse.class);
    String data = response.getData();
    Thread.sleep(10000);
    Response response1 = coreApiHelper.getLastImageProcessedStatus(data, ConfigurationFileHelper.getInstance().getLanID(), bearerAuth);
    Assert.assertEquals(response1.getStatusCode(), 200);

    response = coreApiHelper.faceTraining(faceTrainingRequestLeft, bearerAuth).as(GeneralResponse.class);
    log.info(response.toString());
    Thread.sleep(10000);
    data = response.getData();
    response1 = coreApiHelper.getLastImageProcessedStatus(data, ConfigurationFileHelper.getInstance().getLanID(), bearerAuth);
    Assert.assertEquals(response1.getStatusCode(), 200);

    response = coreApiHelper.faceTraining(faceTrainingRequestRight, bearerAuth).as(GeneralResponse.class);
    data = response.getData();
    Thread.sleep(10000);
    log.info(response.toString());
    response1 = coreApiHelper.getLastImageProcessedStatus(data, ConfigurationFileHelper.getInstance().getLanID(), bearerAuth);
    Assert.assertEquals(response1.getStatusCode(), 200);

    Response submitForApprovalRes = coreApiHelper.submitForApproval(bearerAuth, ConfigurationFileHelper.getInstance().getLanID());
    log.info(submitForApprovalRes.getBody().asString());
    Thread.sleep(10000);
    Assert.assertEquals(submitForApprovalRes.getStatusCode(), 200);

    Response agentEnrollmentApprovalRes = coreApiHelper.agentEnrollmentApproval(enrollmentApprovalRequest, bearerAuth);
    EnrollmentApprovalResponse enrollmentApprovalResponse = agentEnrollmentApprovalRes.getBody().as(EnrollmentApprovalResponse.class);
    log.info(enrollmentApprovalResponse);
    Assert.assertEquals(agentEnrollmentApprovalRes.getStatusCode(), EndPointConstants.responseOK, "Actual status code: " + agentEnrollmentApprovalRes.getStatusCode());
    Assert.assertEquals(enrollmentApprovalResponse.getEnrollmentflag(),"E");
    Assert.assertEquals(enrollmentApprovalResponse.getEmployeeId(),ConfigurationFileHelper.getInstance().getEmployeeId());
    Assert.assertEquals(enrollmentApprovalResponse.getLoggedInUserEmployeeId(),ConfigurationFileHelper.getInstance().getEmployeeId());
  }
}
