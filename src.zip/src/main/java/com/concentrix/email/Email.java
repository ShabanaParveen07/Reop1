package com.concentrix.email;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Date;
import java.util.Properties;
import java.util.stream.Stream;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import com.concentrix.automation.helper.ConfigurationFileHelper;


public class Email {

  public static void main(String[] args) throws IOException {

    String smtpHostServer = ConfigurationFileHelper.getInstance().getSmtpHost();

    Properties props = System.getProperties();

    props.put("mail.smtp.host", smtpHostServer);

    Session session = Session.getInstance(props, null);

    sendAttachmentEmail(session, ConfigurationFileHelper.getInstance().getEmailHeader(), args);

  }

  public static void sendAttachmentEmail(Session session, String subject, String[] args) throws IOException {
    try {
      String lineBody = "";
      String[] line = new String[3];
      MimeMessage msg = new MimeMessage(session);
      msg.addHeader("Content-type", "text/HTML; charset=UTF-8");
      msg.addHeader("format", "flowed");
      msg.addHeader("Content-Transfer-Encoding", "8bit");

      msg.setFrom(new InternetAddress(ConfigurationFileHelper.getInstance().getFromEmail(), ConfigurationFileHelper.getInstance().getEmailSubject()));
      String email = ConfigurationFileHelper.getInstance().getMailId();
      String[] emailList = email.split(";");
      for (int i = 0; i < emailList.length; i++) {
        msg.addRecipients(Message.RecipientType.TO, InternetAddress.parse(emailList[i]));
      }
      msg.setSubject(subject, "UTF-8");

      msg.setSentDate(new Date());
      String reportPath = ConfigurationFileHelper.getInstance().getReportPath();
      String textFilePath = ConfigurationFileHelper.getInstance().getFilePath();
      //Read from file 
      int n = 3;

      try (Stream<String> lines = Files.lines(Paths.get(System.getProperty("user.dir") + textFilePath))) {

        lineBody = lines.skip(n).findFirst().get();
        line = lineBody.split("<<<");
      } catch (IOException e) {
        e.printStackTrace();
      }
      // Create a multipart message for attachment
      Multipart multiPart = new MimeMultipart();

      MimeBodyPart textPart = new MimeBodyPart();
      String textContent = ConfigurationFileHelper.getInstance().getEmailText();
      String start = ConfigurationFileHelper.getInstance().getLinkStart();
      String end = ConfigurationFileHelper.getInstance().getLinkEnd();
      textPart.setContent("<html>\r\n" + "<style>\r\n" + "table, " + "th, td {\r\n" + "  border:1px solid black;\r\n" + "}\r\n" + "</style>\r\n" + "<body>\r\n" + "\r\n" + "<h2>Pipeline Passed!</h2>\r\n" + "\r\n" + "<table style=\"width:100%\">\r\n" + "  <tr>\r\n" + "   " + " <td>Commit</td>\r\n" + "    " + "<td>" + args[0] + "</td>\r\n" + "\r\n" + "  </tr>\r\n" + " " + " <tr>\r\n" + "    <td>Pipeline ID</td>\r\n" + "    <td>" + args[1] + "</td>\r\n" + "  </tr>\r\n" + "  <tr>\r\n" + "    <td>Suite Name</td>\r\n" + "    <td>" + args[2] + "</td>\r\n" + "  </tr>\r\n" + "<td>Environment</td>\r\n" + " <td>" + args[4] + "</td>\r\n" + " </tr>\r\n" + "</table>\r\n" + "\r\n" + "<p>" + "<b>" + line[0] + "</b>" + " </p>\r\n" + "\r\n" + "<p>Please find the report attached. </p>\r\n" + "\r\n" + "<p><a href= " + start + "" + args[3] + "" + end + ">Click here to view the artifacts.</a></p>\r\n" + "\r\n" + "</body>\r\n" + "</html>", "text/html");
      multiPart.addBodyPart(textPart);

      MimeBodyPart attachmentPart = new MimeBodyPart();
      String filepath = System.getProperty("user.dir") + reportPath;
      attachmentPart.attachFile(new File(filepath));
      multiPart.addBodyPart(attachmentPart);

      msg.setContent(multiPart);
      Transport.send(msg);

    } catch (MessagingException e) {
      e.printStackTrace();
    } catch (UnsupportedEncodingException e) {
      e.printStackTrace();
    }
  }


}

