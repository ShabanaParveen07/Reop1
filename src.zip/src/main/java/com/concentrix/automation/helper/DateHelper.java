package com.concentrix.automation.helper;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class DateHelper {
  public static String convertTimeToGivenDateFormat(String dateFormat) {
    Date date = new Date(System.currentTimeMillis());
    DateFormat format = new SimpleDateFormat(dateFormat);
    return format.format(date);
  }

  public static String convertLocalTimeToUTC(String dateFormat) {
    Date date = new Date(System.currentTimeMillis());
    SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
    sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
    return sdf.format(date);
  }

  public static String convertLocalTimeToUTCAndModify(String dateFormat, long milliSeconds) {
    Date date = new Date(System.currentTimeMillis() + milliSeconds);
    SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
    sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
    return sdf.format(date);
  }
}
