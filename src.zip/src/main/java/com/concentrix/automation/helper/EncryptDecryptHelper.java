package com.concentrix.automation.helper;
import lombok.extern.log4j.Log4j;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

@Log4j
public class EncryptDecryptHelper {

  public static String encryptString(String inputText, String key) throws Exception {
    byte[] iv = new byte[16];
    byte[] array;
    try {
      Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
      SecretKeySpec secretKeySpec = new SecretKeySpec(Base64.getDecoder().decode(key), "AES");
      IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);
      cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec, ivParameterSpec);
      array = cipher.doFinal(inputText.getBytes(StandardCharsets.UTF_8));
    } catch (Exception e) {
      e.printStackTrace();
      return null;
    }
    return Base64.getEncoder().encodeToString(array);
  }

  public static String decryptString(String cipherText, String decryptionKey) throws Exception {
    byte[] iv = new byte[16];
    byte[] buffer = Base64.getDecoder().decode(cipherText);
    try {
      Cipher aes = Cipher.getInstance("AES/CBC/PKCS5Padding");
      SecretKeySpec secretKeySpec = new SecretKeySpec(Base64.getDecoder().decode(decryptionKey), "AES");
      IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);
      aes.init(Cipher.DECRYPT_MODE, secretKeySpec, ivParameterSpec);
      byte[] decryptedBytes = aes.doFinal(buffer);
      return new String(decryptedBytes, StandardCharsets.UTF_8);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return null;
  }


}
