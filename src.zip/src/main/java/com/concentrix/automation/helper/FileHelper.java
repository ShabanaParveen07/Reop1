package com.concentrix.automation.helper;

import com.concentrix.automation.service.streaming.pojo.request.TestData;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.log4j.Log4j;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Stream;

@Log4j
public class FileHelper {
  /**
   * Deletes a file
   *
   * @param path : Path
   */
  public static void deleteFile(Path path) {
    try {
      Files.delete(path);
    } catch (IOException e) {
      log.error("Unable to delete file at this path", e);
    }
  }

  /**
   * Deletes a directory with or without files
   *
   * @param dir : String
   */
  public static void deleteDirectory(String dir) {
    Path path = Paths.get(dir);

    log.info("Deleting Folder: " + dir);

    try (Stream<Path> walk = Files.walk(path)) {
      walk
          .sorted(Comparator.reverseOrder())
          .forEach(FileHelper::deleteFile);
    } catch (IOException e) {
      log.info("Folder doesn't exist!!!");
    }
  }

  /**
   * This method will iterate through all files in a directory and create json file containing
   * all file names
   *
   * @param filePath file path
   */
  public static void createJsonFile(String filePath, int expectedResultId) {
    // TODO Auto-generated method stub
    try {
      List<TestData> list = new ArrayList<>();
      File fileDir = new File(filePath);
      if (fileDir.exists()) {
        List<String> fileList = Arrays.asList(fileDir.list());
        for (String name : fileList) {
          TestData obj = new TestData();
          obj.setFileName(name);
          obj.setResultId(expectedResultId);
          list.add(obj);
        }
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(list);
        FileWriter fileWriter = new FileWriter("test-output\\output.json");
        fileWriter.write(json);
        log.info(json);
        fileWriter.close();
      } else {
        log.info("Provide file path :" + filePath + "doesn't exist");
      }

    } catch (IOException e) {
      log.error(e.getMessage());
    }
  }

  /**
   * Create json file from failed test cases with 204 response error
   * @param list ActualFailedTestList
   */
  public static void createFailedTestJsonFile(List<List<String>> list) {
    try {
      File dir = new File("test-output/Actual Results");
      if (!dir.exists())
        dir.mkdirs();
      List<TestData> failedTestList = new ArrayList<>();
      for (List<String> record : list) {
        if (Integer.parseInt(record.get(2)) == 0) {
          TestData obj = new TestData();
          obj.setFileName(record.get(1));
          obj.setResultId(Integer.parseInt(record.get(3)));
          failedTestList.add(obj);
        }
      }
      if (!failedTestList.isEmpty()) {
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(failedTestList);
        FileWriter fileWriter = new FileWriter(dir + "//FailedTest.json");
        fileWriter.write(json);
        log.info(json);
        fileWriter.close();
      }

    } catch (IOException e) {
      log.error(e.getMessage());
    }
  }

  /**
   * This method compares two folder or directory and create new dir with files missing in second folder
   *
   * @param filePath1
   * @param filePath2
   */
  public static void compareFiles(String filePath1, String filePath2) {
    // TODO Auto-generated method stub
    BufferedImage image;
    try {
      List<TestData> list = new ArrayList<>();
      File fileDir1 = new File(filePath1);
      File fileDir2 = new File(filePath2);
      String result = fileDir2 + "/images";
      File path = new File(result);
      if (!path.exists()) {
        path.mkdirs();
      }
      if (fileDir1.exists() && fileDir2.exists()) {
        List<String> fileList1 = Arrays.asList(fileDir1.list());
        List<String> fileList2 = Arrays.asList(fileDir2.list());
        for (String fileName : fileList1) {
          if (!fileList2.contains(fileName)) {
            File file = new File(fileDir1 + "/" + fileName);
            log.info(file.getName());
            image = ImageIO.read(file);
            ImageIO.write(image, "jpg", new File(path + "/" + file.getName()));
          }
        }
      } else {
        log.info("Provide file path doesn't exist");
      }
    } catch (IOException e) {
      log.error(e.getMessage());
    }
  }
}
