package com.concentrix.automation.helper.streaming;

import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.rest.ApiBase;
import com.concentrix.automation.rest.ConversionUtil;
import com.concentrix.automation.rest.Request;
import com.concentrix.automation.service.streaming.pojo.request.*;
import io.restassured.http.Method;
import io.restassured.response.Response;
import lombok.extern.log4j.Log4j;

import java.util.HashMap;

import static com.concentrix.automation.service.CommonConstants.APIEndPoints.*;
import static com.concentrix.automation.service.CommonConstants.CommonConstants.*;

@Log4j
public class StreamingApiHelper {
  String host = ConfigurationFileHelper.getInstance().getBaseUrl().split("//")[1];
  HashMap<String, Object> headers;
  Request request;

  public Response authenticateStreaming(AuthenticationRequest authenticationRequest) {
    log.info("Authenticating Agent for Streaming");
    Request request = new Request();
    request.path = authenticateStreaming;
    request.headers = contentTypeHeader + "," + acceptAllHeader;
    request.method = Method.POST;
    headers = new HashMap<>();
    headers.put("Host", host.substring(0, host.length()));
    ApiBase apiBase = new ApiBase(request);
    return apiBase.setBody(ConversionUtil.convertObjectToString(authenticationRequest)).setHeader(headers).callApi();
  }

  public Response postImageToStreaming(String authToken, HashMap<Object, Object> faceStreamingRequestMap) {
    request = new Request();
    request.path = faceStreaming;
    request.headers = multiPartFormContentTypeHeader + "," + acceptAllHeader;
    request.method = Method.POST;
    headers = new HashMap<>();
    headers.put("Host", host.substring(0, host.length()));
    headers.put("Authorization", authToken);
    ApiBase apiBase = new ApiBase(request);
    return apiBase.setFormParam(faceStreamingRequestMap).setHeader(headers).callApi();
  }

  public Response postImageToStreamingWithAuthentication(String authToken, HashMap<Object, Object> faceStreamingRequestMap) {
    request = new Request();
    request.path = faceStreamingNew;
    request.headers = multiPartFormContentTypeHeader + "," + acceptAllHeader;
    request.method = Method.POST;
    headers = new HashMap<>();
    headers.put("Host", host.substring(0, host.length()));
    headers.put("Authorization", "Bearer " + authToken);
    ApiBase apiBase = new ApiBase(request);
    return apiBase.setFormParam(faceStreamingRequestMap).setHeader(headers).callApi();
  }

  public Response getLastImageProcessedStatus(String imageData, String lanId) {
    request = new Request();
    request.path = lastImageProcessedStatus;
    request.headers = contentTypeHeader + "," + acceptAllHeader;
    request.method = Method.GET;
    request.pathParameters = "userID:args[0],dataValue:args[1]";
    headers = new HashMap<>();
    headers.put("Host", host);
    String[] pathParams = new String[]{lanId, imageData};
    ApiBase apiBase = new ApiBase(request);
    return apiBase.setPathParam(pathParams).setHeader(headers).callApi();
  }

  public Response getLastImageProcessedStatusWithAuthentication(String imageData, String lanId, String authToken) {
    request = new Request();
    request.path = lastImageProcessedStatusNew;
    request.headers = contentTypeHeader + "," + acceptAllHeader;
    request.method = Method.GET;
    request.pathParameters = "userID:args[0],dataValue:args[1]";
    headers = new HashMap<>();
    headers.put("Host", host);
    headers.put("Authorization", "Bearer " + authToken);
    String[] pathParams = new String[]{lanId, imageData};
    ApiBase apiBase = new ApiBase(request);
    return apiBase.setPathParam(pathParams).setHeader(headers).callApi();
  }

  public Response postImageToFaceAuth(FaceAuthRequest faceAuthRequest) {
    log.info("Authenticating Agent for Streaming");
    Request request = new Request();
    request.path = faceAuth;
    request.headers = contentTypeHeader + "," + acceptAllHeader;
    request.method = Method.POST;
    headers = new HashMap<>();
    headers.put("Host", host.substring(0, host.length()));
    headers.put("Authorization", 20);
    ApiBase apiBase = new ApiBase(request);
    return apiBase.setBody(ConversionUtil.convertObjectToString(faceAuthRequest)).setHeader(headers).callApi();
  }

  public Response postImageToFaceAuthWithAuthentication(FaceAuthRequest faceAuthRequest, String authToken) {
    log.info("Authenticating Agent for Streaming");
    Request request = new Request();
    request.path = faceAuthNew;
    request.headers = contentTypeHeader + "," + acceptAllHeader;
    request.method = Method.POST;
    headers = new HashMap<>();
    headers.put("Host", host.substring(0, host.length()));
    headers.put("Authorization", "Bearer " + authToken);
    ApiBase apiBase = new ApiBase(request);
    return apiBase.setBody(ConversionUtil.convertObjectToString(faceAuthRequest)).setHeader(headers).callApi();
  }

  public Response postFeedback(FeedbackRequest feedbackRequest) {
    log.info("Posting Feedback");
    Request request = new Request();
    request.path = feedback;
    request.headers = contentTypeHeader;
    request.method = Method.POST;
    headers = new HashMap<>();
    headers.put("Host", host.substring(0, host.length()));
    ApiBase apiBase = new ApiBase(request);
    return apiBase.setBody(ConversionUtil.convertObjectToString(feedbackRequest)).setHeader(headers).callApi();
  }

  public Response postFeedbackWithAuthentication(FeedbackRequest feedbackRequest, String authToken) {
    log.info("Posting Feedback");
    Request request = new Request();
    request.path = feedback;
    request.headers = contentTypeHeader;
    request.method = Method.POST;
    headers = new HashMap<>();
    headers.put("Host", host.substring(0, host.length()));
    headers.put("Authorization", "Bearer " + authToken);
    ApiBase apiBase = new ApiBase(request);
    return apiBase.setBody(ConversionUtil.convertObjectToString(feedbackRequest)).setHeader(headers).callApi();
  }

  public Response getTrainingImagesByLanId(String lanId) {
    request = new Request();
    request.path = trainingImages;
    request.headers = contentTypeHeader + "," + acceptAllHeader;
    request.method = Method.GET;
    request.pathParameters = "userID:args[0]";
    headers = new HashMap<>();
    headers.put("Host", host);
    String[] pathParams = new String[]{lanId};
    ApiBase apiBase = new ApiBase(request);
    return apiBase.setPathParam(pathParams).callApi();
  }

  public Response getTrainingImagesByLanIdWithAuthentication(String lanId, String authToken) {
    request = new Request();
    request.path = trainingImagesNew;
    request.headers = contentTypeHeader + "," + acceptAllHeader;
    request.method = Method.GET;
    request.pathParameters = "userID:args[0]";
    headers = new HashMap<>();
    headers.put("Host", host);
    headers.put("Authorization", "Bearer " + authToken);
    String[] pathParams = new String[]{lanId};
    ApiBase apiBase = new ApiBase(request);
    return apiBase.setPathParam(pathParams).setHeader(headers).callApi();
  }

  public Response getCheckBaseValidation(String lanId) {
    request = new Request();
    request.path = baseValidation;
    request.headers = contentTypeHeader + "," + acceptAllHeader;
    request.method = Method.GET;
    request.pathParameters = "userID:args[0]";
    headers = new HashMap<>();
    headers.put("Host", host);
    String[] pathParams = new String[]{lanId};
    ApiBase apiBase = new ApiBase(request);
    return apiBase.setPathParam(pathParams).callApi();
  }

  public Response getCheckBaseValidationWithAuthentication(String lanId, String authToken) {
    request = new Request();
    request.path = baseValidationNew;
    request.headers = contentTypeHeader + "," + acceptAllHeader;
    request.method = Method.GET;
    request.pathParameters = "userID:args[0]";
    headers = new HashMap<>();
    headers.put("Accept", "application/json");
    headers.put("Authorization", "Bearer " + authToken);
    String[] pathParams = new String[]{lanId};
    ApiBase apiBase = new ApiBase(request);
    return apiBase.setPathParam(pathParams).setHeader(headers).callApi();
  }

  public Response getValues() {
    request = new Request();
    request.path = values;
    request.headers = contentTypeHeader + "," + acceptAllHeader;
    request.method = Method.GET;
    ApiBase apiBase = new ApiBase(request);
    return apiBase.callApi();
  }

  public Response getValuesWithAuthentication(String authToken) {
    request = new Request();
    request.path = valuesNew;
    request.headers = contentTypeHeader + "," + acceptAllHeader;
    request.method = Method.GET;
    headers = new HashMap<>();
    headers.put("Authorization", "Bearer " + authToken);
    ApiBase apiBase = new ApiBase(request);
    return apiBase.setHeader(headers).callApi();
  }

  public Response getStreamingConfigurations(String lanId, String appVersion) {
    request = new Request();
    request.path = streamingConfigurations;
    request.headers = contentTypeHeader + "," + acceptAllHeader;
    request.method = Method.GET;
    request.pathParameters = "userID:args[0],appVersion:args[1]";
    headers = new HashMap<>();
    headers.put("Host", ConfigurationFileHelper.getInstance().getCentralBaseUrl().split("//")[1]);
    String[] pathParams = new String[]{lanId, appVersion};
    ApiBase apiBase = new ApiBase(request);
    return apiBase.setHeader(headers).setPathParam(pathParams).callApi();
  }

  public Response getStreamingConfigurationsWithAuthentication(String lanId, String appVersion, String authToken) {
    request = new Request();
    request.path = streamingConfigurationsNew;
    request.headers = contentTypeHeader + "," + acceptAllHeader;
    request.method = Method.GET;
    request.pathParameters = "userID:args[0],appVersion:args[1]";
    headers = new HashMap<>();
    headers.put("Host", ConfigurationFileHelper.getInstance().getCentralBaseUrl().split("//")[1]);
    headers.put("Authorization", "Bearer " + authToken);
    String[] pathParams = new String[]{lanId, appVersion};
    ApiBase apiBase = new ApiBase(request);
    return apiBase.setHeader(headers).setPathParam(pathParams).callApi();
  }

  public Response postClientEvent(ClientEventRequest clientEventRequest) {
    log.info("Posting a Client Event");
    Request request = new Request();
    request.path = postClientEventLog;
    request.headers = contentTypeHeader;
    request.method = Method.POST;
    headers = new HashMap<>();
    headers.put("Host", host);
    ApiBase apiBase = new ApiBase(request);
    return apiBase.setBody(ConversionUtil.convertObjectToString(clientEventRequest)).setHeader(headers).callApi();
  }

  public Response postClientEventWithAuthentication(ClientEventRequest clientEventRequest, String authToken) {
    log.info("Posting a Client Event");
    Request request = new Request();
    request.path = postClientEventLogNew;
    request.headers = contentTypeHeader;
    request.method = Method.POST;
    headers = new HashMap<>();
    headers.put("Host", host);
    headers.put("Authorization", "Bearer " + authToken);
    ApiBase apiBase = new ApiBase(request);
    return apiBase.setBody(ConversionUtil.convertObjectToString(clientEventRequest)).setHeader(headers).callApi();
  }

  public Response getDisableMonitoringConfiguration(String userID, String authToken) {
    request = new Request();
    request.path = getDisableMonitoringConfiguration;
    request.headers = acceptAllHeader;
    request.method = Method.GET;
    request.pathParameters = "userID:args[0]";
    headers = new HashMap<>();
    headers.put("Host", host);
    headers.put("Authorization", "Bearer " + authToken);
    String[] pathParams = new String[]{userID};
    ApiBase apiBase = new ApiBase(request, "central");
    return apiBase.setHeader(headers).setPathParam(pathParams).callApi();
  }

  public Response getEmployeeSSOID(String userID) {
    request = new Request();
    request.path = getEmployeeSSOID;
    request.headers = acceptHeader;
    request.method = Method.GET;
    request.pathParameters = "userID:args[0]";
    headers = new HashMap<>();
    headers.put("Host", host);
    String[] pathParams = new String[]{userID};
    ApiBase apiBase = new ApiBase(request);
    return apiBase.setHeader(headers).setPathParam(pathParams).callApi();
  }

  public Response getAppKey() {
    request = new Request();
    request.path = getAppKey;
    request.headers = acceptHeader;
    request.method = Method.GET;
    headers = new HashMap<>();
    headers.put("Host", host);
    ApiBase apiBase = new ApiBase(request);
    return apiBase.setHeader(headers).callApi();
  }

  public Response getAppKeyWithAutherization(String authToken) {
    request = new Request();
    request.path = getAppKeyNew;
    request.headers = acceptHeader;
    request.method = Method.GET;
    headers = new HashMap<>();
    headers.put("Host", host);
    headers.put("Authorization", "Bearer " + authToken);
    ApiBase apiBase = new ApiBase(request);
    return apiBase.setHeader(headers).callApi();
  }

  public Response addStreamingAgentErrorLog(StreamingAgentErrorLogRequest streamingAgentErrorLogRequest) {
    request = new Request();
    request.path = AddStreamingAgentErrorLog;
    request.headers = contentTypeHeader;
    request.method = Method.POST;
    headers = new HashMap<>();
    ApiBase apiBase = new ApiBase(request, "central");
    return apiBase.setBody("[" + ConversionUtil.convertObjectToString(streamingAgentErrorLogRequest) + "]").callApi();
  }

  public Response addStreamingAgentErrorLogWithAdAuthentication(StreamingAgentErrorLogRequest streamingAgentErrorLogRequest, String adToken) {
    request = new Request();
    request.path = AddStreamingAgentErrorLogWithAdToken;
    request.headers = contentTypeHeader;
    request.method = Method.POST;
    headers = new HashMap<>();
    headers.put("Authorization", "Bearer " + adToken);
    ApiBase apiBase = new ApiBase(request, "central");
    return apiBase.setHeader(headers).setBody("[" + ConversionUtil.convertObjectToString(streamingAgentErrorLogRequest) + "]").callApi();
  }

  public Response sendStreamingAlert(SendStreamingAlertRequest sendStreamingAlertRequest) {
    request = new Request();
    request.path = sendStreamingAlert;
    request.headers = contentTypeHeader;
    request.method = Method.POST;
    ApiBase apiBase = new ApiBase(request);
    return apiBase.setBody(ConversionUtil.convertObjectToString(sendStreamingAlertRequest)).callApi();
  }

  public Response sendStreamingAlertWithAuthentication(SendStreamingAlertRequest sendStreamingAlertRequest, String authToken) {
    request = new Request();
    request.path = sendStreamingAlert;
    request.headers = contentTypeHeader;
    request.method = Method.POST;
    headers = new HashMap<>();
    headers.put("Authorization", "Bearer " + authToken);
    ApiBase apiBase = new ApiBase(request);
    return apiBase.setBody(ConversionUtil.convertObjectToString(sendStreamingAlertRequest)).setHeader(headers).callApi();
  }

  public Response addEmployeeOTPCode(AddEmployeeOTPCodeRequest addEmployeeOTPCodeRequest) {
    request = new Request();
    request.path = AddEmployeeOTPCode;
    request.headers = contentTypeHeader;
    request.method = Method.POST;
    ApiBase apiBase = new ApiBase(request, "central");
    return apiBase.setBody(ConversionUtil.convertObjectToString(addEmployeeOTPCodeRequest)).callApi();
  }

  public Response refreshFaceStreaming(String lanId) {
    request = new Request();
    request.path = refresh;
    request.headers = contentTypeHeader + "," + acceptAllHeader;
    request.method = Method.GET;
    request.pathParameters = "userID:args[0]";
    headers = new HashMap<>();
    headers.put("Host", host);
    String[] pathParams = new String[]{lanId};
    ApiBase apiBase = new ApiBase(request);
    return apiBase.setPathParam(pathParams).callApi();

  }

  public Response getAuthenticatedUserConfig(String authToken, String userID) {
    request = new Request();
    request.path = getAuthenticatedUserConfig;
    request.headers = acceptHeader;
    request.method = Method.GET;
    request.pathParameters = "userID:args[0]";
    headers = new HashMap<>();
    headers.put("Authorization", authToken);
    String[] pathParams = new String[]{userID};
    ApiBase apiBase = new ApiBase(request);
    return apiBase.setHeader(headers).setPathParam(pathParams).setHeader(headers).callApi();
  }

  public Response getConnectedClientsHealth() {
    request = new Request();
    request.path = health;
    request.headers = acceptHeader;
    request.method = Method.GET;
    headers = new HashMap<>();
    ApiBase apiBase = new ApiBase(request, "aks-connected-clients");
    return apiBase.setHeader(headers).callApi();
  }

  public Response getLogConfigurations(String userID) {
    request = new Request();
    request.path = getLogConfigurations;
    request.headers = acceptHeader;
    request.method = Method.GET;
    request.pathParameters = "userID:args[0]";
    headers = new HashMap<>();
    String[] pathParams = new String[]{userID};
    ApiBase apiBase = new ApiBase(request, "central");
    return apiBase.setHeader(headers).setPathParam(pathParams).callApi();
  }

  public Response getAgentLogConfigurations(String userID) {
    request = new Request();
    request.path = getAgentLogConfigurations;
    request.headers = acceptHeader;
    request.method = Method.GET;
    request.pathParameters = "userID:args[0]";
    headers = new HashMap<>();
    String[] pathParams = new String[]{userID};
    ApiBase apiBase = new ApiBase(request, "central");
    return apiBase.setHeader(headers).setPathParam(pathParams).callApi();
  }

  public Response postSupervisorOTP(String userID, String otp, String duration) {
    request = new Request();
    request.path = postSupervisorOTPCode;
    request.headers = acceptAllHeader;
    request.method = Method.POST;
    request.pathParameters = "userID:args[0],otp:args[1],duration:args[2]";
    String[] pathParams = new String[]{userID, otp, duration};
    ApiBase apiBase = new ApiBase(request, "central");
    return apiBase.setPathParam(pathParams).callApi();
  }
}
