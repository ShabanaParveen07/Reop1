package com.concentrix.automation.helper;
import lombok.extern.log4j.Log4j;

import java.io.File;
import java.io.IOException;

@Log4j
public class DownloadImagesHelper {
  private final String imageFilePath = System.getProperty("user.dir") + File.separator + "test-output/download" + File.separator;

  public static String objectKey;

  public void downloadImagesFromGKE(String[] imagePathIds) {
    String bucketName = "cs-standard-gke-asia-southeast1-kub02";
    File dir = new File("test-output/download");
    if (!dir.exists())
      dir.mkdirs();
    try {
      for (String imagePathId : imagePathIds) {
        GCSHelper.downloadObject(
            ConfigurationFileHelper.getInstance().getProjectId(),
            bucketName,
            imagePathId,
            imageFilePath + imagePathId + ".jpg");
      }
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
  }
}
