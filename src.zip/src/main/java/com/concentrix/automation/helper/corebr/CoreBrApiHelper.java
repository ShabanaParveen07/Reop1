package com.concentrix.automation.helper.corebr;

import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.concentrix.automation.rest.ApiBase;
import com.concentrix.automation.rest.ConversionUtil;
import com.concentrix.automation.rest.Request;
import com.concentrix.automation.service.corebr.pojo.request.ApproveAgentMonitoringRequest;
import com.concentrix.automation.service.corebr.pojo.request.BulkUpsertRequest;
import io.restassured.http.Method;
import io.restassured.response.Response;
import lombok.extern.log4j.Log4j;

import java.util.HashMap;

import static com.concentrix.automation.service.CommonConstants.APIEndPoints.*;
import static com.concentrix.automation.service.CommonConstants.CommonConstants.*;

@Log4j
public class CoreBrApiHelper {

  HashMap<String, Object> headers;
  Request request;

  public Response configureDisableMonitoring(BulkUpsertRequest bulkUpsertRequest, String authToken) {

    log.info("Creating a Disable Monitoring Request");
    request = new Request();
    request.path = bulkUpsert;
    request.headers = contentTypeHeader + "," + acceptAllHeader;
    request.method = Method.POST;
    headers = new HashMap<>();
    headers.put("Authorization", "Bearer " + authToken);
    ApiBase apiBase = new ApiBase(request, "core-br");
    return apiBase.setBody(ConversionUtil.convertObjectToString(bulkUpsertRequest)).setHeader(headers).callApi();

  }

  public Response approveAgentMonitoring(String authToken, ApproveAgentMonitoringRequest approveAgentMonitoringRequest) {

    log.info("Take the following action on Pending DM Request: " + approveAgentMonitoringRequest.getStatus());
    request = new Request();
    request.path = approveAgentMonitoring;
    request.headers = contentTypeHeader + "," + acceptAllHeader;
    request.method = Method.POST;
    headers = new HashMap<>();
    headers.put("Authorization", "Bearer " + authToken);
    headers.put("UserRole", "admin");
    ApiBase apiBase = new ApiBase(request, "core-br");
    return apiBase.setBody("[" + ConversionUtil.convertObjectToString(approveAgentMonitoringRequest) + "]").setHeader(headers).callApi();

  }
}
