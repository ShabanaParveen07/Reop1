package com.concentrix.automation.helper;

public class ConfigurationFileHelper {
  private static volatile ConfigurationFileHelper configurationFileUtil;

  private ConfigurationFileHelper() {
    String envName = System.getProperty("env");
    if (envName == null)
      envName = "qa";
    PropertiesHelper.loadProperties(getClass().getClassLoader().getResourceAsStream("configuration" + "-" + envName + ".properties"));
  }

  public static ConfigurationFileHelper getInstance() {
    if (configurationFileUtil == null) {
      synchronized (ConfigurationFileHelper.class) {
        if (configurationFileUtil == null) {
          configurationFileUtil = new ConfigurationFileHelper();
        }
      }
    }
    return configurationFileUtil;
  }

  public String getLanID() {
    return PropertiesHelper.getProperty("LanId");
  }

  public String getBaseUrl() {
    return PropertiesHelper.getProperty("baseUrl");
  }

  public String getBaseUrl2() {
    return PropertiesHelper.getProperty("baseUrl2");
  }

  public Integer getUtcOffsetinSecs() {
    return PropertiesHelper.getIntProperty("UtcOffsetinSecs");
  }

  public String getApplicationKey() {
    return PropertiesHelper.getProperty("ApplicationKey");
  }

  public String getSSOId() {
    return PropertiesHelper.getProperty("SSOId");
  }

  public String getSystemName() {
    return PropertiesHelper.getProperty("SystemName");
  }

  public String getStreamingAppVersion() {
    return PropertiesHelper.getProperty("StreamingAppVersion");
  }

  public String getModelName() {
    return PropertiesHelper.getProperty("ModelName");
  }

  public String getAzureHost() {
    return PropertiesHelper.getProperty("azureHost");
  }

  public String getAzureUser() {
    return PropertiesHelper.getProperty("azureUser");
  }

  public String getAzurePass() {
    return PropertiesHelper.getProperty("azurePass");
  }

  public String getSsoPass() {
    return PropertiesHelper.getProperty("SSOPass");
  }

  public String getProjectId() {
    return PropertiesHelper.getProperty("projectId");
  }

  public String getBucketName() {
    return PropertiesHelper.getProperty("bucketName");
  }

  public String getDomainName() {
    return PropertiesHelper.getProperty("domainName");
  }

  public String getApplicationName() {
    return PropertiesHelper.getProperty("applicationName");
  }

  public String getAccount() {
    return PropertiesHelper.getProperty("account");
  }

  public String getEmployeeId() {
    return PropertiesHelper.getProperty("empId");
  }

  public String getCentralBaseUrl() {
    return PropertiesHelper.getProperty("centralBaseUrl");
  }

  public String getMailId() {
    return PropertiesHelper.getProperty("MailId");
  }

  public String getSmtpHost() {
    return PropertiesHelper.getProperty("SmtpHostServer");
  }

  public String getEmailHeader() {
    return PropertiesHelper.getProperty("EmailHeader");
  }

  public String getEmailSubject() {
    return PropertiesHelper.getProperty("EmailSubject");
  }

  public String getEmailText() {
    return PropertiesHelper.getProperty("EmailText");
  }

  public String getFromEmail() {
    return PropertiesHelper.getProperty("FromEmail");
  }

  public String getReportPath() {
    return PropertiesHelper.getProperty("ReportUrl");
  }

  public String getFilePath() {
    return PropertiesHelper.getProperty("FileUrl");
  }

  public String getLinkStart() {
    return PropertiesHelper.getProperty("HyperLinkStart");
  }

  public String getLinkEnd() {
    return PropertiesHelper.getProperty("HyperLinkEnd");
  }

  public String getSupervisorSSOId() {
    return PropertiesHelper.getProperty("SupervisorSSOId");
  }

  public String getSupervisorId() {
    return PropertiesHelper.getProperty("supervisorId");
  }

  public String getDisableMonitoringId() {
    return PropertiesHelper.getProperty("DisableMonitoringId");
  }

  public String getDisableMonitoringFirstName() {
    return PropertiesHelper.getProperty("DisableMonitoringFirstName");
  }

  public String getDisableMonitoringLastName() {
    return PropertiesHelper.getProperty("DisableMonitoringLastName");
  }

  public String getDisableMonitoringEnrollmentFlag() {
    return PropertiesHelper.getProperty("DisableMonitoringEnrollmentFlag");
  }

  public String getDisableMonitoringSecureCXEnabled() {
    return PropertiesHelper.getProperty("DisableMonitoringSecureCXEnabled");
  }

  public String getDisableMonitoringInitialStatus() {
    return PropertiesHelper.getProperty("DisableMonitoringInitialStatus");
  }

  public String getDisableMonitoringApproveComments() {
    return PropertiesHelper.getProperty("DisableMonitoringApproveComments");
  }

  public String DisableMonitoringRejectComments() {
    return PropertiesHelper.getProperty("DisableMonitoringRejectComments");
  }

  public String getDisableMonitoringApproveAction() {
    return PropertiesHelper.getProperty("DisableMonitoringApproveAction");
  }

  public String getDisableMonitoringRejectAction() {
    return PropertiesHelper.getProperty("DisableMonitoringRejectAction");
  }

  public String getDisableMonitoringShortDisableAction() {
    return PropertiesHelper.getProperty("DisableMonitoringShortDisableAction");
  }

  public String getDisableMonitoringFullDayDisableAction() {
    return PropertiesHelper.getProperty("DisableMonitoringFullDayDisableAction");
  }

  public String getAppKeyExpectedResult() {
    return PropertiesHelper.getProperty("ExpectedResult");
  }

  public String getStatusCode() {
    return PropertiesHelper.getProperty("StatusCode");
  }

  public String getAksEastWriteBaseUrl() {
    return PropertiesHelper.getProperty("aksEastWriteBaseUrl");
  }

  public String getAksEastConnectedClientsBaseUrl() {
    return PropertiesHelper.getProperty("aksEastConnectedClientsBaseUrl");
  }

  public String getEncryptionKey() {
    return PropertiesHelper.getProperty("encryptionKey");
  }

  public String getOrionCentralBaseUrl() {
    return PropertiesHelper.getProperty("orionCentralBaseUrl");
  }

  public String getClientId() {
    return PropertiesHelper.getProperty("clientId");
  }

  public String getClientSecret() {
    return PropertiesHelper.getProperty("clientSecret");
  }

  public String getTenetId() {
    return PropertiesHelper.getProperty("tenetId");
  }

  public String getSecureCxAppId() {
    return PropertiesHelper.getProperty("secureCxAppId");
  }

  public String getEnv(){
    return PropertiesHelper.getProperty("env");
  }
  public String getWorkdayEmailID() {return PropertiesHelper.getProperty("WorkdayEmail");}
}
