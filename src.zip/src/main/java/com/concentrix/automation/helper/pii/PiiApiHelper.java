package com.concentrix.automation.helper.pii;

import com.concentrix.automation.rest.ApiBase;
import com.concentrix.automation.rest.Request;
import com.concentrix.automation.service.CommonConstants.APIEndPoints;
import io.restassured.http.Method;
import io.restassured.response.Response;
import lombok.extern.log4j.Log4j;

import static com.concentrix.automation.service.CommonConstants.CommonConstants.acceptAllHeader;
import static com.concentrix.automation.service.CommonConstants.CommonConstants.contentTypeHeader;

@Log4j
public class PiiApiHelper {
  Request request;

  public Response piiApiV1(String piiApiRequestBody) {
    log.info("Creating a pii Request");
    request = new Request();
    request.path = APIEndPoints.piiV2;
    request.headers = contentTypeHeader + "," + acceptAllHeader;
    request.method = Method.POST;
    ApiBase apiBase = new ApiBase(request, "orion-central");
    return apiBase.setBody(piiApiRequestBody).callApi();
  }
}
