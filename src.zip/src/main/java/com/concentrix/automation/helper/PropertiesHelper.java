package com.concentrix.automation.helper;

import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.exception.ExceptionUtils;

import java.io.InputStream;
import java.util.Properties;

@Log4j2
public class PropertiesHelper {
    private static volatile Properties properties;

    protected static void loadProperties(InputStream fileInputStream) {
        if (properties == null) {
            synchronized (PropertiesHelper.class) {
                if (properties == null)
                    properties = load(fileInputStream);
            }
        }
    }

    private static Properties load(InputStream fileInputStream) {
        Properties properties = null;
        try {
            properties = new Properties();
            properties.load(fileInputStream);
            log.info(fileInputStream + " loaded successfully.");
        } catch (Exception e) {
            log.error(fileInputStream + " could not be loaded " + ExceptionUtils.getStackTrace(e));
        }
        return properties;
    }

    public static Properties getProperties() {
        return properties;
    }

    public static String getProperty(String property) {
        if (properties == null) {
            return null;
        }
        return properties.getProperty(property).trim();
    }

    public static int getIntProperty(String property) {
        if (properties == null) {
            return 0;
        }
        return Integer.parseInt(properties.getProperty(property).trim());
    }
}
