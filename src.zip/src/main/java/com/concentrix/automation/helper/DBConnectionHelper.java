package com.concentrix.automation.helper;

import lombok.extern.log4j.Log4j;

import java.sql.*;

@Log4j
public class DBConnectionHelper {

  private static volatile DBConnectionHelper dbConnectionHelper;
  private Connection con;

  private DBConnectionHelper() {
    // TODO Auto-generated constructor stub
    try {
      String pass = Base64Helper.decodePassword(ConfigurationFileHelper.getInstance().getAzurePass());
      Class.forName("com.mysql.cj.jdbc.Driver");
      con = DriverManager.getConnection("jdbc:mysql://" + ConfigurationFileHelper.getInstance().getAzureHost(),
          ConfigurationFileHelper.getInstance().getAzureUser(),
          pass);
      log.info("Db connection is created");
    } catch (Exception e) {
      log.error(e.getMessage());
    }
  }

  public static DBConnectionHelper getInstance() {
    if (dbConnectionHelper == null) {
      synchronized (DBConnectionHelper.class) {
        if (dbConnectionHelper == null) {
          dbConnectionHelper = new DBConnectionHelper();
        }
      }
    }
    return dbConnectionHelper;
  }

  public Connection getConnection() {
    return con;
  }

  public ResultSet executeQuery(String sqlQuery) {
    ResultSet rs = null;
    try {
      Statement stmt = con.createStatement();
      rs = stmt.executeQuery(sqlQuery);
    } catch (Exception e) {
      log.error(e.getMessage());
    }
    return rs;
  }

  public int executeUpdateQuery(String sqlQuery) {
    int value = -1;
    try {
      Statement stmt = con.createStatement();
       value = stmt.executeUpdate(sqlQuery);
    } catch (Exception e) {
      log.error(e.getMessage());
    }
    return value;
  }

  public void closeConnection() throws SQLException {
    con.close();
    log.info("Db connection is closed");
  }
}
