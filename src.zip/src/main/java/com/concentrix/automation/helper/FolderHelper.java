package com.concentrix.automation.helper;

import java.io.File;
import java.util.List;

public class FolderHelper {

    public static void createFolders(String prefix, List<String> folders) {

        for(int i = 0 ; i < folders.size(); i++) {
            if(!new File(prefix+folders.get(i)).exists()) {
                new File(prefix+folders.get(i)).mkdirs();
            }
        }
    }
}
