package com.concentrix.automation.helper.vision;

import com.concentrix.automation.rest.ApiBase;
import com.concentrix.automation.rest.ConversionUtil;
import com.concentrix.automation.rest.Request;
import com.concentrix.automation.service.vision.pojo.request.ImageValidationRequest;
import io.restassured.http.Method;
import io.restassured.response.Response;

import java.util.HashMap;

import static com.concentrix.automation.service.CommonConstants.CommonConstants.*;
import static com.concentrix.automation.service.vision.constants.ApiEndPoints.*;

public class VisionHelper {
  Request request;
  HashMap<String, Object> headers;

  public Response EnrollmentHelper(String requestBody, String authToken){
    request = new Request();
    request.path = visionEnrollment;
    request.headers = contentTypeHeader;
    request.method = Method.POST;
    headers = new HashMap<>();
    headers.put("Authorization", "Bearer "+authToken);
    ApiBase apiBase = new ApiBase(request,"central");
    if(authToken.length()>0) {
      return apiBase.setBody(requestBody).setHeader(headers).callApi();
    }
    else {
      return apiBase.setBody(requestBody).callApi();
    }
  }

  public Response TokenHelper(String emailid){
    request = new Request();
    request.path = tokenUrl;
    request.headers = contentTypeHeader + "," + acceptAllHeader;
    request.method = Method.GET;
    request.pathParameters = "emailId:args[0]";
    String[] pathParams = new String[]{emailid};
    ApiBase apiBase = new ApiBase(request,"central");
    return apiBase.setPathParam(pathParams).callApi();
  }

  public Response imageValidation(ImageValidationRequest imageValidationRequest, String authToken){
    request = new Request();
    request.path = imageValidationUrl;
    request.headers = contentTypeHeader + "," + acceptAllHeader;
    request.method = Method.POST;
    headers = new HashMap<>();
    headers.put("Authorization", "Bearer "+authToken);
    ApiBase apiBase = new ApiBase(request,"central");
    return apiBase.setHeader(headers).setBody(ConversionUtil.convertObjectToString(imageValidationRequest)).callApi();
  }

}
