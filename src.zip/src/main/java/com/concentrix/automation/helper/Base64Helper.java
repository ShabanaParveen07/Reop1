package com.concentrix.automation.helper;

import org.apache.commons.codec.binary.Base64;


public class Base64Helper {

  /**
   * Encoded Password is converted using Base64 -> https://www.base64encode.org/
   *
   * @param encodedPassword
   * @return decodedPassword
   */

  public static String decodePassword(String encodedPassword) {
    byte[] decodeBytes = Base64.decodeBase64(encodedPassword);
    String decodedPassword = new String(decodeBytes);
    return decodedPassword;
  }

  public static String encodePassword(String passwordText) {
    byte[] encodedBytes  = java.util.Base64.getEncoder().encode(passwordText.getBytes());
    String encodedPassword = new String(encodedBytes);
    return encodedPassword;
  }

}


