package com.concentrix.automation.helper;


import com.google.auth.Credentials;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.storage.*;
import lombok.extern.log4j.Log4j;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Paths;

@Log4j
public class GCSHelper {
  public static void downloadObject(
      String projectId, String bucketName, String objectName, String destFilePath) throws IOException {
    int count = 0;
    int maxTries = 3;
    Blob blob;
    Credentials credentials = GoogleCredentials.fromStream(new FileInputStream(System.getProperty("user.dir") + "//concentrix-2226848.json"));
    Storage storage = StorageOptions.newBuilder().setCredentials(credentials).setProjectId(projectId).build().getService();
    while (true) {
      try {
        blob = storage.get(BlobId.of(bucketName, objectName));
        break;
      } catch (StorageException s) {
        log.warn("Retrying count " + count + " for " + objectName);
        if (++count == maxTries)
          throw s;
      }
    }
    if (blob != null) {
      blob.downloadTo(Paths.get(destFilePath));
      log.info("Downloaded object " + objectName + " from bucket name " + bucketName + " to " + destFilePath);
    }else{
      log.info("Given image path " + objectName + " doesn't exist");
    }

  }

}
