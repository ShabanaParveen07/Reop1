package com.concentrix.automation.helper.streaming;

import com.concentrix.automation.helper.ConfigurationFileHelper;
import lombok.extern.log4j.Log4j;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;

import static com.concentrix.automation.helper.DateHelper.convertTimeToGivenDateFormat;

/**
 * Helper class for evaluating ML Model
 */
@Log4j
public class MLConfusionMetricsHelper {

  private static final DecimalFormat df = new DecimalFormat("0.000");
  private static PrintWriter printWriter = null;

  public MLConfusionMetricsHelper() {
    System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------");
    System.out.printf("%30s %20s %20s %5s %5s %5s %5s %10s %10s %10s %10s", "Model", "Class", "Total Images", "TP", "FP", "FN", "TN", "Efficacy", "Recall", "Accuracy", "F1-Score");
    System.out.println();

    try {
      printWriter = createLogFile();
    } catch (IOException e) {
      log.error(e.getStackTrace());
    }
  }

  public Double calculateEfficacyPrecision(double truePositives, double falsePositives) {
    Double precision = (double) 0;
    try {
      precision = truePositives / (truePositives + falsePositives);
    } catch (ArithmeticException e) {
      log.error(e.getMessage());
    }
    return Double.valueOf(df.format(precision));
  }

  public Double calculateAccuracy(double truePositives, double trueNegatives, double falsePositives, double falseNegatives) {
    Double accuracy = (double) 0;
    try {
      accuracy = (truePositives + trueNegatives) / (truePositives + falsePositives + trueNegatives + falseNegatives);
    } catch (ArithmeticException e) {
      log.error(e.getMessage());
    }
    return Double.valueOf(df.format(accuracy));
  }

  public Double calculateRecall(double truePositives, double falseNegatives) {
    Double recall = (double) 0;
    try {
      recall = truePositives / (truePositives + falseNegatives);
    } catch (ArithmeticException e) {
      log.error(e.getMessage());
    }
    return Double.valueOf(df.format(recall));
  }

  /**
   * Calculate F1Score value
   *
   * @param recall:   Double
   * @param precision or Efficacy: Double
   * @return Double
   */
  public Double calculateF1Score(Double recall, Double precision) {
    Double f1Score = (double) 0;
    try {
      f1Score = (2 * (recall * precision)) / (recall + precision);
    } catch (ArithmeticException e) {
      log.error(e.getMessage());
    }
    return Double.valueOf(df.format(f1Score));
  }

  /**
   * Generate validation data set
   *
   * @param violationType : String
   * @param TP:           int - True Positives
   * @param FP:           int - False Positives
   * @param FN:           int - False Negatives
   * @param TN:           int - True Negatives
   */
  public void generateValidationDataSet(String violationType, int TP, int FP, int FN, int TN) {
    Double recall = calculateRecall(TP, FN);
    Double precision = calculateEfficacyPrecision(TP, FP);
    Double f1Score = calculateF1Score(recall, precision);

    System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------");
    System.out.format("%30s %20s %20s %5s %5s %5s %5s %10s %10s %10s %10s", ConfigurationFileHelper.getInstance().getModelName(), violationType, (TP + FP + FN + TN), TP, FP, FN, TN, precision, recall, calculateAccuracy(TP, TN, FP, FN), f1Score);
    System.out.println();
    System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------");

    try {
      addToLogFile(printWriter, violationType, TP, FP, FN, TN, precision, recall, calculateAccuracy(TP, TN, FP, FN), f1Score);
    } catch (IOException e) {
      log.error(e.getStackTrace());
    }
  }

  /**
   * This method creates a csv file at ./mlConFusionMetricsResults/ location consisting of confusion metrics header only
   *
   * @return PrintWriter
   * @throws IOException: for csv file
   */
  public static PrintWriter createLogFile() throws IOException {
    File dir = new File("./mlConFusionMetricsResults/");

    if (!dir.exists())
      dir.mkdirs();

    String csvFilePath = "./mlConFusionMetricsResults/" + "result" + "_" + convertTimeToGivenDateFormat("yyyy-MM-dd-HH-mm-ss") + ".csv";

    PrintWriter printWriter = new PrintWriter(new FileWriter(csvFilePath, true));
    CSVPrinter csvPrinter = new CSVPrinter(printWriter, CSVFormat.DEFAULT.withHeader("Model", "Class", "Total Images", "TP", "FP", "FN", "TN", "Efficacy", "Recall", "Accuracy", "F1-Score"));
    csvPrinter.flush();

    return printWriter;
  }

  /**
   * It adds row to csv file at ./mlConFusionMetricsResults/ location with violation details
   *
   * @param printWriter:   PrintWriter
   * @param violationType: String
   * @param TP:            int - True Positives
   * @param FP:            int - False Positives
   * @param FN:            int - False Negatives
   * @param TN:            int - True Negatives
   * @param precision:     Double
   * @param recall:        Double
   * @param accuracy:      Double
   * @param f1Score:       Double
   * @throws IOException: throws for csv file
   */
  public static void addToLogFile(PrintWriter printWriter, String violationType, int TP, int FP, int FN, int TN, Double precision, Double recall, Double accuracy, Double f1Score) throws IOException {
    CSVPrinter newPrinter = new CSVPrinter(printWriter, CSVFormat.DEFAULT);
    newPrinter.printRecord(ConfigurationFileHelper.getInstance().getModelName(), violationType, (TP + FP + FN + TN), TP, FP, FN, TN, precision, recall, accuracy, f1Score);
    newPrinter.flush();
  }
}
