package com.concentrix.automation.helper;

import com.concentrix.automation.rest.ApiBase;
import com.concentrix.automation.rest.ConversionUtil;
import com.concentrix.automation.rest.Request;
import com.concentrix.automation.service.core.pojo.request.EnrollmentApprovalRequest;
import com.concentrix.automation.service.core.pojo.request.FaceTrainingRequest;
import io.restassured.http.Method;
import io.restassured.response.Response;
import lombok.extern.log4j.Log4j;

import java.util.HashMap;

import static com.concentrix.automation.service.CommonConstants.APIEndPoints.*;
import static com.concentrix.automation.service.CommonConstants.CommonConstants.acceptAllHeader;
import static com.concentrix.automation.service.CommonConstants.CommonConstants.contentTypeHeader;

@Log4j
public class CoreApiHelper {
  HashMap<String, Object> headers;
  Request request;

  public Response faceTraining(FaceTrainingRequest faceTrainingRequest, String authToken) {

    log.info("Creating a face training Request");
    request = new Request();
    request.path = faceTraining;
    request.headers = contentTypeHeader + "," + acceptAllHeader;
    request.method = Method.POST;
    headers = new HashMap<>();
    headers.put("Authorization", "Bearer " + authToken);
    ApiBase apiBase = new ApiBase(request, "core");
    return apiBase.setBody(ConversionUtil.convertObjectToString(faceTrainingRequest)).setHeader(headers).callApi();
  }
  public Response getLastImageProcessedStatus(String imageData, String lanId, String authToken) {
    request = new Request();
    request.path = faceTrainingLastImageProcessedStatus;
    request.headers = contentTypeHeader + "," + acceptAllHeader;
    request.method = Method.GET;
    request.pathParameters = "userID:args[0],dataValue:args[1]";
    headers = new HashMap<>();
    headers.put("Authorization", "Bearer " + authToken);
    String[] pathParams = new String[]{lanId, imageData};
    ApiBase apiBase = new ApiBase(request,"core");
    return apiBase.setPathParam(pathParams).setHeader(headers).callApi();
  }
  public Response submitForApproval(String authToken,String lanId) {

    log.info("Creating a face training Request");
    request = new Request();
    request.path = enrollmentComplete;
    request.headers = contentTypeHeader + "," + acceptAllHeader;
    request.method = Method.GET;
    request.pathParameters = "userID:args[0]";
    headers = new HashMap<>();
    String[] pathParams = new String[]{lanId};
    headers.put("Authorization", "Bearer " + authToken);
    ApiBase apiBase = new ApiBase(request, "core");
    return apiBase.setPathParam(pathParams).setHeader(headers).callApi();
  }
  public Response agentEnrollmentApproval(EnrollmentApprovalRequest enrollmentApprovalRequest, String authToken) {

    log.info("Creating a face training Request");
    request = new Request();
    request.path = agentEnrollmentApproval;
    request.headers = contentTypeHeader + "," + acceptAllHeader;
    request.method = Method.POST;
    headers = new HashMap<>();
    headers.put("Authorization", "Bearer " + authToken);
    ApiBase apiBase = new ApiBase(request, "core");
    return apiBase.setBody(ConversionUtil.convertObjectToString(enrollmentApprovalRequest)).setHeader(headers).callApi();
  }
}
