package com.concentrix.automation.rest;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.google.gson.Gson;
import lombok.extern.log4j.Log4j;

import java.lang.reflect.Type;
import java.util.Map;
import java.util.stream.Collectors;

@Log4j
public class ConversionUtil {

    public static Map<String,Object> convertObjectToMap(Object obj)
    {
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> outputMap = mapper.convertValue(obj, new TypeReference<Map<String, Object>>() {});
        Map<String,Object> returnMap = outputMap.entrySet().stream()
                .collect(Collectors.toMap(Map.Entry::getKey, e -> e.getValue()));
        return returnMap;
    }

    public static String convertObjectToString(Object object){
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);

        String json = null;
        try {
            json = objectMapper.writeValueAsString(object);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return json;
    }

    /**
     * This methods deserializes the specified Json into an object of the specified class.
     *
     * @param response
     * @param className
     * @return Object
     */

    public static Object convertFromJson(String response, String className) {
        Gson gson = new Gson ( );
        Object containerObject = null;
        try {
            containerObject = Class.forName ( className ).newInstance ( );
            containerObject = gson.fromJson ( response, containerObject.getClass ( ) );
        } catch ( Exception e ) {
            e.printStackTrace ( );
        }
        return containerObject;
    }

    public static Object convertFromJson(String response, Type type) {
        Gson gson = new Gson ( );
        Object containerObject = null;
        try {
            containerObject = gson.fromJson ( response, type );
        } catch ( Exception e ) {
            e.printStackTrace ( );
        }
        return containerObject;
    }

    public static Object convertToJson(Object object) {
        Gson gson = new Gson ( );
        try {
            return gson.toJson ( object );
        } catch ( Exception e ) {
            e.printStackTrace ( );
            return null;
        }
    }

    public static <T> T deserializedResponse(String response, Class T) {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
        T deserializedRes = null;
        try {
            deserializedRes = (T) mapper.readValue(response, T);
        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return deserializedRes;

    }

}