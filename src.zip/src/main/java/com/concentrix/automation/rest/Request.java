package com.concentrix.automation.rest;

import io.restassured.http.Method;

import java.util.Arrays;
import java.util.HashMap;

public class Request {

    public String url;
    public Method method;
    public Object body;
    public String bodyJsonFilePath;
    public String path;
    public String headers;
    public String pathParameters;
    public String queryParameters;
    public HashMap<Object, Object> formParam;

    public String authentication;


    @Override
    public String toString() {
        return "Request: {" + "url='" + url + '\'' + ",method='" + method + '\'' + ", body=" + body + ", bodyJsonFilePath='" + bodyJsonFilePath
                + '\'' + ", path='" + path + '\'' + ", headers='" + headers + '\'' + ", pathParameters='"
                + pathParameters + '\'' + ", queryParameters='" + queryParameters + '\'' + ", formParam="
                + Arrays.deepToString(new HashMap[]{formParam}) + '}';
    }

    public String GetRequestData(){
        return "Request: {" + "url='" + url + '\'' + ",method='" + method + '\'' + ", path=" + path + "}";
    }

}
