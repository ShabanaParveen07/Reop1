package com.concentrix.automation.rest;

import com.concentrix.automation.helper.ConfigurationFileHelper;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import io.restassured.response.Response;
import lombok.extern.log4j.Log4j;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.StringJoiner;

@Log4j
public class ApiBase {

  private String serviceName;
  private String apiName;
  RequestHandler requestHandler;
  Request request = null;
  Response response = null;

  String stream = "";

  public ApiBase(Request request) {
    this.request = request;
    requestHandler = new RequestHandler();
    setApiInfo();
    createBody();
  }

  public ApiBase(Request request, String stream) {
    this.request = request;
    this.stream = stream;
    requestHandler = new RequestHandler();
    setApiInfo();
    createBody();
  }

  private void setApiInfo() {
    String url;
    if (stream.equals("itoc") || stream.equals("core-br") || stream.equals("core") || stream.equals("central")) {
      url = ConfigurationFileHelper.getInstance().getCentralBaseUrl();
    } else if (stream.equals("aks-east-write")) {
      url = ConfigurationFileHelper.getInstance().getAksEastWriteBaseUrl();
    } else if (stream.equals("aks-connected-clients")) {
      url = ConfigurationFileHelper.getInstance().getAksEastConnectedClientsBaseUrl();
    }else if (stream.equals("orion-central")) {
      url = ConfigurationFileHelper.getInstance().getOrionCentralBaseUrl();
    }else {
      url = ConfigurationFileHelper.getInstance().getBaseUrl();
    }
    requestHandler.setEndPoint(url);
    request.url = url;
    requestHandler.setBasePath(request.path);
  }

  private void createBody() {

    File file;
    ObjectMapper objectMapper;
    String body = null;
    try {
      if ((request.bodyJsonFilePath != null)) {
        file = new File(getClass().getClassLoader().getResource(request.bodyJsonFilePath).getFile());
        objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ObjectNode objectNode = objectMapper.readValue(file, ObjectNode.class);
        body = objectMapper.writeValueAsString(objectNode);
      } else if (request.body != null) {
        body = request.body.toString();
      }
      if (body != null) {
        request.body = body;
      }

    } catch (Exception e) {
      log.error(e.getMessage());
    }

  }

  public ApiBase setBody(String[] bodyArgs) {
    File file;
    ObjectMapper objectMapper;
    String body = null;

    try {
      if ((request.bodyJsonFilePath != null)) {
        file = new File(getClass().getClassLoader().getResource(request.bodyJsonFilePath).getFile());
        objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ObjectNode objectNode = objectMapper.readValue(file, ObjectNode.class);
        body = objectMapper.writeValueAsString(objectNode);
      } else if (request.body != null) {
        body = request.body.toString();
      } else {
        log.info("body or bodyFilePath is missing");
      }

      for (int i = 0; i < bodyArgs.length; i++) {
        body = body.replace("args[" + i + "]", bodyArgs[i]);
      }

      request.body = body;
    } catch (Exception e) {
      log.error(e.getMessage());
    }
    return this;

  }

  public ApiBase setBody(String body) {
    request.body = body;
    return this;
  }

  public ApiBase setBody(File body) {
    request.body = body;
    return this;
  }

  public ApiBase setQuery(String[] queryArgs) {
    if (request.queryParameters != null) {
      String query = request.queryParameters;
      for (int i = 0; i < queryArgs.length; i++) {
        query = query.replace("args[" + i + "]", queryArgs[i]);
      }
      request.queryParameters = query;
    }
    return this;
  }

  public ApiBase setQuery(Map<String, Object> queryMap) {
    StringJoiner joiner = new StringJoiner("&");
    for (String s : queryMap.keySet()) {
      joiner.add(s + "=" + queryMap.get(s));
    }
    request.queryParameters = joiner.toString();
    return this;
  }

  public ApiBase setPathParam(String[] pathParamArgs) {
    if (request.pathParameters != null) {
      String pathParamModified = request.pathParameters;
      for (int i = 0; i < pathParamArgs.length; i++) {
        pathParamModified = pathParamModified.replace("args[" + i + "]", pathParamArgs[i]);
      }
      request.pathParameters = pathParamModified;
    }
    return this;
  }

  public ApiBase setPathParam(Map<String, Object> pathParam) {
    StringJoiner joiner = new StringJoiner(",");
    for (String s : pathParam.keySet()) {
      joiner.add(s + ":" + pathParam.get(s));
    }
    request.pathParameters = joiner.toString();
    return this;
  }

  public ApiBase setFormParam(HashMap<Object, Object> objectMap) {
    request.formParam = objectMap;
    return this;
  }

  public ApiBase setHeader(Map<String, Object> header) {
    StringJoiner joiner = new StringJoiner(",");
    for (String s : header.keySet()) {
      joiner.add(s + ":" + header.get(s));
    }
    if (request.headers != null) {
      request.headers = request.headers + "," + joiner;
    } else {
      request.headers = joiner.toString();
    }

    return this;
  }

  private Response sendCall() {
    switch (request.method) {
      case GET:
        return requestHandler.returnGetApiResp();
      case POST:
        return requestHandler.returnPostApiResp();
      case PATCH:
        return requestHandler.returnPatchApiResp();
      case PUT:
        return requestHandler.returnPutApiResp();
      case DELETE:
        return requestHandler.returnDeleteApiResp();

    }
    return null;
  }

  public Response callApi() {
    try {
      log.info(request.GetRequestData());
      if (request.headers != null)
        requestHandler.setHeader(request.headers);
      if (request.queryParameters != null && !request.queryParameters.isEmpty())
        requestHandler.setQuery(request.queryParameters);
      if (request.pathParameters != null && !request.pathParameters.isEmpty())
        requestHandler.setPathParam(request.pathParameters);
      if (request.body != null && request.body instanceof String) {
        requestHandler.setBody(request.body.toString());
      } else if (request.body != null && request.body instanceof File) {
        requestHandler.setBody((File) request.body);
      }
      if (request.formParam != null)
        requestHandler.setFormParam(request.formParam);
      if (request.authentication != null)
        requestHandler.setAuth(request.authentication);
      response = sendCall();
      log.info("Response: " + response.statusCode() + " || " + response.getStatusLine() + " || " + response.getBody().asString());
    } catch (Exception e) {
      log.error(e.getMessage());
    }
    return response;
  }

}
