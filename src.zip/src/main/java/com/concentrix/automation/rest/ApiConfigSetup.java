package com.concentrix.automation.rest;

import io.restassured.specification.RequestSpecification;
import lombok.extern.log4j.Log4j;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.given;

@Log4j
public class ApiConfigSetup<T extends ApiConfigSetup<?>> {

    HashMap<String, Object> header;
    HashMap<String, Object> query;
    HashMap<String, String> param;
    RequestSpecification spec;
    protected final T self;

    protected ApiConfigSetup(final Class<T> selfClass) {
        this.self = selfClass.cast(this);
        spec = given();
    }

    public T setHeader(String s) {
        header = new HashMap<String, Object>();
        String[] h = s.split(",");
        for (int i = 0; i < h.length; i++) {
            String[] hl = h[i].split(":");
            header.put(hl[0], (Object) hl[1]);
        }
        spec.headers(header);
        return self;
    }

    public T setHeader(Map<String, String> header) {
        spec.headers(header);
        return self;
    }

    public T setQuery(String s) {
        query = new HashMap<String, Object>();
        String[] q = s.split("&");
        for (int i = 0; i < q.length; i++) {
            int l = q[i].length();
            int index = q[i].indexOf("=");
            query.put(q[i].substring(0, index), (Object) q[i].substring(index + 1, l));
        }
        spec.queryParams(query);
        return self;
    }

    public T setQuery(Map<String, String> query) {
        spec.queryParams(query);
        return self;
    }

    public T setEndPoint(String uri) {
        spec.baseUri(uri);
        return self;
    }

    public T setBasePath(String path) {
        spec.basePath(path);
        return self;
    }

    public T setBody(String body) {
        spec.body(body);
        return self;
    }

    public T setBody(File f) {
        spec.body(f);
        return self;
    }

    public T setPathParam(String s) {
        param = new HashMap<String, String>();
        String[] p = s.split(",");
        for (int i = 0; i < p.length; i++) {
            String[] pp = p[i].split(":");
            param.put(pp[0], pp[1]);
        }
        spec.pathParams(param);
        return self;
    }

    public T setPathParam(Map<String, String> param) {
        spec.pathParams(param);
        return self;
    }

    public T setFormParam(HashMap<Object, Object> objectMap) {
        for (Object o : objectMap.keySet()) {
                spec.multiPart(o.toString(), objectMap.get(o));
            }
        return self;
    }

    public T setAuth(String bearerToken) {
        spec.auth().oauth2(bearerToken);
        return self;
    }

    public RequestSpecification getSpec() {
        if (spec == null)
            spec = given();
        return spec;
    }

}
