package com.concentrix.automation.rest;

import io.restassured.response.Response;
import lombok.extern.log4j.Log4j;

@Log4j
public class RequestHandler extends ApiConfigSetup<RequestHandler> {

  private static Response response;

  public RequestHandler() {
    super(RequestHandler.class);
  }

  public Response returnGetApiResp() {
    try {
      log.info(spec.log().uri());
      response = spec.when().relaxedHTTPSValidation()
          .get()
          .then()
          .extract()
          .response();
    } catch (Exception e) {
      e.printStackTrace();
    }

    return response;
  }


  public Response returnPostApiResp() {
    try {
      log.info(spec.log().uri());
      response = spec.when().relaxedHTTPSValidation()
          .post()
          .then()
          .extract()
          .response();
    } catch (Exception e) {
      e.printStackTrace();
    }

    return response;
  }

  public Response returnPatchApiResp() {
    try {
      response = spec.when().log().all()
          .patch()
          .then()
          .log()
          .all()
          .extract()
          .response();
    } catch (Exception e) {
      e.printStackTrace();
    }

    return response;
  }

  public Response returnPutApiResp() {
    try {
      response = spec.when().log().all()
          .put()
          .then()
          .log()
          .all()
          .extract()
          .response();
    } catch (Exception e) {
      e.printStackTrace();
    }

    return response;
  }

  public Response returnDeleteApiResp() {
    try {
      response = spec.when().log().all()
          .delete()
          .then()
          .log()
          .all()
          .extract()
          .response();
    } catch (Exception e) {
      e.printStackTrace();
    }

    return response;
  }


}
