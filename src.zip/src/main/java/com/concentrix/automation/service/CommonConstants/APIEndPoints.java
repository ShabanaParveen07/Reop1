package com.concentrix.automation.service.CommonConstants;

public final class APIEndPoints {

  public static String authenticateStreaming = "/core-frontdoor-write/api/AuthenticateStreaming/";
  public static String authenticateStreamingProd = "/Api/AuthenticateStreaming/";

  public static String faceStreaming = "/core-frontdoor-write/api/FaceStreaming";

  public static String faceStreamingProd = "/api/FaceStreaming";
  public static String faceStreamingNew = "/api-gateway/core-frontdoor-write/api-service/FaceStreaming";

  public static String lastImageProcessedStatus = "/core-frontdoor-read/api/FaceStreaming/GetLastImageProcesStatus/{userID}/{dataValue}";
  public static String lastImageProcessedStatusNew = "/api-gateway/core-frontdoor-read/api-service/FaceStreaming/GetLastImageProcesStatus/{userID}/{dataValue}";

  public static String faceAuth = "core-frontdoor-write/api/FaceStreaming/faceAuth";
  public static String faceAuthNew = "api-gateway/core-frontdoor-write/api-service/FaceStreaming/faceAuth";

  public static String faceAuthNewProd = "/core-frontdoor-write/api-service/FaceStreaming/faceAuth/";
  public static String feedback = "core-frontdoor-write/api/Feedback";
  public static String feedbackNew = "api-gateway/core-frontdoor-write/api-service/Feedback";
  public static String trainingImages = "core-frontdoor-write/api/FaceTraining/GetTrainingImageByLanId/{userID}";
  public static String trainingImagesNew = "api-gateway/core-frontdoor-write/api-service/FaceTraining/GetTrainingImageByLanId/{userID}";

  public static String baseValidation = "/core-frontdoor-write/api/FaceStreaming/CheckBaseValidation/{userID}";
  public static String baseValidationNew = "/api-gateway/core-frontdoor-write/api-service/FaceStreaming/CheckBaseValidation/{userID}";

  public static String values = "/core-frontdoor-write/api/values";
  public static String valuesNew = "/api-gateway/core-frontdoor-write/api/values";

  public static String streamingConfigurations = "/api-gateway/central/api/StreamingEndPoint/GetStreamingConfigurationsWithUserData/{userID}/{appVersion}";
  public static String streamingConfigurationsNew = "/api-gateway/central/api/StreamingEndPoint/GetStreamingConfigurationsWithUserData/{userID}/{appVersion}";

  public static String postClientEventLog = "/core-frontdoor-write/api/FaceStreaming/LogClientEvent";
  public static String postClientEventLogNew = "/api-gateway/core-frontdoor-write/api-service/FaceStreaming/LogClientEvent";
  public static String getDisableMonitoringConfiguration = "/api-gateway/core-frontdoor-read/api-service/AgentMonitoring/GetDisableMonitoringConfiguration/{userID}";

  public static String approveAgentMonitoring = "/api-gateway/core-br/api/AgentMonitoring/ApproveAgentMonitoring";

  public static String bulkUpsert = "/api-gateway/core-br/api/AgentMonitoring/BulkUpsert";

  public static String getEmployeeSSOID = "/core-frontdoor-write/api/AuthenticateStreaming/GetEmploeeSSOid/{userID}";

  public static String getAppKey = "/core-frontdoor-write/api/Configuration/AppKey";
  public static String getAppKeyNew = "/api-gateway/core-frontdoor-read/api-service/Configuration/AppKey";
  public static String sendStreamingAlert = "/core-frontdoor-write/api/FaceStreaming/SendStreamingAlert";
  public static String sendStreamingAlertNew = "/api-gateway/core-frontdoor-write/api-service/FaceStreaming/SendStreamingAlert";
  public static String AddStreamingAgentErrorLog = "/api-gateway/central/api/StreamingEndPoint/AddStreamingAgentErrorLog";
  public static String AddStreamingAgentErrorLogWithAdToken = "/api-gateway/central/apiservice/StreamingEndPoint/AddStreamingAgentErrorLog";
  public static String AddEmployeeOTPCode = "/api-gateway/central/api/StreamingEndPoint/AddEmployeeOTPCode";

  public static String refresh = "/core-frontdoor-write/api/FaceStreaming/Refresh/{userID}";

  public static String faceTraining = "/api-gateway/core/api/FaceTraining/";

  public static String enrollmentComplete = "/api-gateway/core/api/FaceTraining/EnrollmentComplete/{userID}";

  public static String agentEnrollmentApproval = "/api-gateway/core-br/api/AgentEnrollmentApproval";

  public static String faceTrainingLastImageProcessedStatus = "/api-gateway/core/api/FaceTraining/GetLastImageProcesStatus/{userID}/{dataValue}";

  public static String health = "/health";

  public static String getAuthenticatedUserConfig = "/core-frontdoor-read/api/FaceStreaming/GetAuthenticatedUserConfig/{userID}";

  public static String getLogConfigurations = "/securecx-log/api/LogConfiguration/GetLogConfigurations/{userID}";

  public static String getAgentLogConfigurations = "/securecx-log/api/AgentLog/GetAgentLogConfiguration/{userID}";

  public static String postSupervisorOTPCode = "api-gateway/central/api/StreamingEndPoint/SupervisorOTPEmailNotification/{userID}/{otp}/{duration}";

  public static String piiV1 = "/pii/api/v1";
  public static String piiV2 = "/pii/api/v2";


}
