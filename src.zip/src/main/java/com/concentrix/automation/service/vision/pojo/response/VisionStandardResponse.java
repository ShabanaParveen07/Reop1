package com.concentrix.automation.service.vision.pojo.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class VisionStandardResponse {
  @JsonProperty("responseResult")
  public String responseResult;
  @JsonProperty("responseStatus")
  public String responseStatus;

  @JsonProperty("data")
  public String data;
  @JsonProperty("responseResult1")
  public String responseResult1;
}
