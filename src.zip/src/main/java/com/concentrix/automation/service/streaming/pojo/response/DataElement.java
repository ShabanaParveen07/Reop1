package com.concentrix.automation.service.streaming.pojo.response;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class DataElement {

    @JsonProperty("ShowPopup")
    private String showPopup;

    @JsonProperty("BlurSettings")
    private String blurSettings;

    @JsonProperty("MiscSettings")
    private String miscSettings;

    @JsonProperty("AuditSettings")
    private String auditSettings;

    @JsonProperty("ImageSettings")
    private String imageSettings;

    @JsonProperty("CameraSettings")
    private String cameraSettings;

    @JsonProperty("ClientSettings")
    private String clientSettings;

    @JsonProperty("ReadAPIBaseUrl")
    private String readAPIBaseURL;

    @JsonProperty("RetryIntervals")
    private String retryIntervals;

    @JsonProperty("correlationId")
    private String correlationId;

    @JsonProperty("StatusEndpoint")
    private String statusEndpoint;

    @JsonProperty("DefaultLanguage")
    private String defaultLanguage;

    @JsonProperty("BandwidthSettings")
    private String bandWidthSettings;

    @JsonProperty("StreamingEndpoint")
    private String streamingEndpoint;

    @JsonProperty("AcknowlegeSettings")
    private String acknowledgeSettings;

    @JsonProperty("DisableMicrophones")
    private String disableMicrophones;

    @JsonProperty("CalibrationSettings")
    private String calibrationSettings;

    @JsonProperty("FaceAuthDuringSession")
    private String faceAuthDuringSession;

    @JsonProperty("MLIntegrationSettings")
    private String mlIntegrationSettings;

    @JsonProperty("ViolationLogIntervals")
    private String violationLogIntervals;

    @JsonProperty("NonMLViolationSettings")
    private String nonMLViolationSettings;

    @JsonProperty("RtNotificationEndpoint")
    private String rtNotificationEndpoint;

    @JsonProperty("ApplicationExitSettings")
    private String applicationExitSettings;

    @JsonProperty("ClientAppVersionSettings")
    private String clientAppVersionSettings;

    @JsonProperty("AuthenticationOTPSettings")
    private String authenticationOTPSettings;

    @JsonProperty("ImageUploadStorageSettings")
    private String imageUploadStorageSettings;

    @JsonProperty("DisableMonotoringDelaySetting")
    private String disableMonitoringDelaySetting;

    @JsonProperty("RtNotificationHealthcheckEndpoint")
    private String rtNotificationHealthCheckEndpoint;

    @JsonProperty("WorkDayConsent")
    private String workdayConsent;

    @JsonProperty("UILocalization")
    private String uiLocalization;

    @JsonProperty("ConfigMessageSettings")
    private String configMessageSettings;

    @JsonProperty("ServerMessageSettings")
    private String serverMessageSettings;

    @JsonProperty("IsConfigUpdated")
    private String isConfigUpdated;

    @JsonProperty("ConfigVersion")
    private String configVersion;

    @JsonProperty("startDate")
    private String startDate;

    @JsonProperty("endDate")
    private String endDate;

    @JsonProperty("ssO_ID")
    private String ssoId;

    @JsonProperty("isShortDuration")
    private Boolean isShortDuration;

    @JsonProperty("id")
    private Integer id;

    @JsonProperty("meeting_Name")
    private String meetingName;

    @JsonProperty("ClientActionsNewFormat")
    private String[] clientActionsNewFormat;

    @JsonProperty("gcpImageUploadConfig")
    private String gcpImageUploadConfig;

    @JsonProperty("azureImageUploadConfig")
    private String azureImageUploadConfig;

    @JsonProperty("streamingClientApplicationSource")
    private String streamingClientApplicationSource;

    @JsonProperty("imageUploadCloudProvider")
    private String imageUploadCloudProvider;

    @JsonProperty("RetryInterval")
    private String retryInterval;

    @JsonProperty("ConfigRefreshInterval")
    private String configRefreshInterval;

}
