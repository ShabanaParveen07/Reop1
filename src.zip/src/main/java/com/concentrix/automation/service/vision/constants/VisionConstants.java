package com.concentrix.automation.service.vision.constants;

public class VisionConstants {
  public static final String EMIALID ="automationuser%s@gmail.com";
  public static final String ENROLLMENTLOCATION="Hyderabad";
  public static final String FIRSTNAME="Automation";
  public static final String LASTNAME="User";
  public static final String JOBID1="T1116857";
  public static final String JOBID2="T1347751";
  public static final String JobName1="Team Leader, Operations";
  public static final String JobName2="Manager, Planning and Scheduling";
  public static final String LANGUAGE="en";
  public static final String LANID="lanid";
  public static final String EMAILADDR="emailaddr";
  public static final String EMPLOYEEID="employeeId";
  public static final String DBFIRSTNAME="firstname";
  public static final String DBLASTNAME="lastname";
  public static final String EMPID="empid";
  public static final String SYSTEMENVIRONMENTID="systemenviornmentid";
  public static final String IMAGEPROFILE="imageprofile";
  public static final String ENROLLMENTACTION="EnrollmentAction";
  public static final String ENROLLMENTACTIONBY="EnrollmentActionBy";
  public static final String REMARKS="Remarks";
  public static final String APPROVE="Approve";
  public static final String SYSTEMAUTOAPPROVE="System Auto Approve";

  public static final String ENROLLMENTFALG="Enrollmentflag";
  public static final String DBJOBID="JobId";
  public static final String COUNT="count";
  public static final String RESPONSERESULT = "Hi %s , Your enrollment images are successfully captured.";
  public static final String SUCCESS = "Success";
  public static final String INVALIDTOKEN="Authorization failed : Invalid token";
  public static final String INVLAIDUSER="Authorization failed : Invalid user";
  public static final String NOTOKENFOUND="Authorization failed : No Token found";
  public static final String INVALIDEMAIL="Hi %s, Your eamil id format is incorrect.";
  public static final String FAIL="Fail";




}
