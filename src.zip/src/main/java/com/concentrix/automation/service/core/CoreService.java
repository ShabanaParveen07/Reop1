package com.concentrix.automation.service.core;

public class CoreService {
}
