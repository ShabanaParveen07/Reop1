package com.concentrix.automation.service.streaming.pojo.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FeedbackRequest {

    @JsonProperty("EmpId")
    private String empId;

    @JsonProperty("SsoId")
    private String ssoId;

    @JsonProperty("LanId")
    private String lanId;

    @JsonProperty("Account")
    private String account;

    @JsonProperty("SecurecxClientVersion")
    private String secureCXClientVersion;

    @JsonProperty("SubmitDate")
    private String submitDate;

    @JsonProperty("IpAddress")
    private String ipAddress;

    @JsonProperty("ComputerName")
    private String computerName;

    @JsonProperty("DomainName")
    private String domainName;

    @JsonProperty("ApplicationName")
    private String applicationName;

    @JsonProperty("Experience")
    private String experience;

    @JsonProperty("FeedbackType")
    private String feedbackType;

    @JsonProperty("FeedbackComments")
    private String feedbackComments;

    @JsonProperty("ModuleName")
    private String moduleName;

}
