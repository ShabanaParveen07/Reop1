package com.concentrix.automation.service.CommonConstants;

import java.io.File;

public final class CommonConstants {

    public static String acceptHeader="Accept:application/json";
    public static String acceptAllHeader = "Accept:*/*";
    public static String  contentTypeHeader="Content-Type:application/json";
    public static String formContentTypeHeader = "Content-Type:application/x-www-form-urlencoded";
    public static String multiPartFormContentTypeHeader = "Content-Type:multipart/form-data";
    public static String plainTextContentTypeHeader = "Content-Type:text/plain";

    public static File ML_IMAGES_FOLDER = new File(System.getProperty("user.dir")+ File.separator + "src" + File.separator + "test" + File.separator + "resources" + File.separator + "ML");


}
