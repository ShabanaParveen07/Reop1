package com.concentrix.automation.service.streaming.pojo.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AuthenticationRequest {
    private Integer utcOffsetinSecs;
    private String lanID;
    private String applicationKey;
    private String sSOId;
    private String systemIP;
    private String systemName;
    private String timestamp;
    private Integer timeZoneOffset;
    private String trainingAppVersion;
    private String streamingAppVersion;
}
