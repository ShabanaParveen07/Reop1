package com.concentrix.automation.service.corebr.pojo.request;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BulkUpsertConfigurations {

  @JsonProperty("id")
  private Integer id;

  @JsonProperty("employeeId")
  private String employeeId;

  @JsonProperty("firstName")
  private String firstName;

  @JsonProperty("lastName")
  private String lastName;

  @JsonProperty("meetingName")
  private String meetingName;

  @JsonProperty("endDate")
  private String endDate;

  @JsonProperty("startDate")
  private String startDate;

  @JsonProperty("isShortDuration")
  private Boolean isShortDuration;

  @JsonProperty("createdOn")
  private String createdOn;

  @JsonProperty("action")
  private String action;

  @JsonProperty("isFullDayDisable")
  private Boolean isFullDayDisable;

  @JsonProperty("employeeSSOId")
  private String employeeSSOId;

  @JsonProperty("supervisorSSOId")
  private String supervisorSSOId;

  @JsonProperty("enrollmentFlag")
  private String enrollmentFlag;

  @JsonProperty("secureCXEnable")
  private String secureCXEnable;

  @JsonProperty("supervisorId")
  private String supervisorId;

  @JsonProperty("approvedDate")
  private String approvedDate;

  @JsonProperty("approvedById")
  private String approvedById;

  @JsonProperty("status")
  private String status;

  @JsonProperty("rowChecked")
  private Boolean rowChecked;

  @JsonProperty("comments")
  private String comments;


}
