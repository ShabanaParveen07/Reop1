package com.concentrix.automation.service.streaming.pojo.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class TrainingImageResponse {

    @JsonProperty("empid")
    public String empId;

    @JsonProperty("lanid")
    public String lanId;

    @JsonProperty("imagebagid")
    public Integer imageBagId;

    @JsonProperty("imagesource")
    public String imageSource;

    @JsonProperty("imagefile")
    public String imageFile;

    @JsonProperty("enrollmentflag")
    public String enrollmentFlag;

    @JsonProperty("imageProfile")
    public String imageProfile;
}
