package com.concentrix.automation.service.streaming.pojo.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class StandardResponse {

    @JsonProperty("correlationId")
    private String correlationId;

    @JsonProperty("success")
    private Boolean success;

    @JsonProperty("data")
    private DataElement data;

    @JsonProperty("userInfo")
    private UserInfo userInfo;

    @JsonProperty("errorMessage")
    private String errorMessage;

    @JsonProperty("status")
    private Boolean status;

    @JsonProperty("error")
    private String error;
}
