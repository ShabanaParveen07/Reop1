package com.concentrix.automation.service.streaming.pojo.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.File;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FaceStreamingRequest {

    @JsonProperty("file")
    private File file;

    @JsonProperty("LanId")
    private String lanId;

    @JsonProperty("Token")
    private String token;

    @JsonProperty("SystemIP")
    private String systemIp;

    @JsonProperty("SystemName")
    private String systemName;

    @JsonProperty("Timestamp")
    private String timeStamp;

    @JsonProperty("StreamingAppVersion")
    private String streamingAppVersion;

    @JsonProperty("ThickClient")
    private String thickClient;

    @JsonProperty("BlurType")
    private String blurType;

    @JsonProperty("BlurBackgroundType")
    private String blurBackgroundType;

    @JsonProperty("BLUR_KERNEL_SIZE")
    private String blurKernelSize;

    @JsonProperty("SecondaryPersonBlurType")
    private String secondaryPersonBlurType;

    @JsonProperty("TimeZoneOffset")
    private String timeZoneOffset;

    @JsonProperty("FaceAuthMode")
    private int faceAuthMode;







}
