package com.concentrix.automation.service.streaming.pojo.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetAuthenticatedUserConfigData {

  @JsonProperty("gcpImageUploadConfig")
  private GcpImageUploadConfig gcpImageUploadConfig;

  @JsonProperty("azureImageUploadConfig")
  private AzureImageUploadConfig azureImageUploadConfig;

  @JsonProperty("streamingClientApplicationSource")
  private StreamingClientApplicationSource streamingClientApplicationSource;

  @JsonProperty("imageUploadCloudProvider")
  private String imageUploadCloudProvider;

}

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
class GcpImageUploadConfig {
  @JsonProperty("authUri")
  private String authUri;

  @JsonProperty("tokenUri")
  private String tokenUri;

  @JsonProperty("projectId")
  private String projectId;

  @JsonProperty("bucketName")
  private String bucketName;

  @JsonProperty("privateKey")
  private String privateKey;

  @JsonProperty("accountType")
  private String accountType;

  @JsonProperty("clientEmail")
  private String clientEmail;

  @JsonProperty("privateKeyId")
  private String privateKeyId;

  @JsonProperty("authProviderx509CertUrl")
  private String authProviderx509CertUrl;

  @JsonProperty("configClientx509CertUrl")
  private String configClientx509CertUrl;

}

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
class AzureImageUploadConfig {
  @JsonProperty("containerName")
  private String containerName;

  @JsonProperty("connectionString")
  private String connectionString;
}

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
class StreamingClientApplicationSource {
  @JsonProperty("containerName")
  private String containerName;

  @JsonProperty("relaunchTimeout")
  private String relaunchTimeout;

  @JsonProperty("appToStartAfterUpdate")
  private String appToStartAfterUpdate;

  @JsonProperty("blobStorageConnectionString")
  private String blobStorageConnectionString;
}
