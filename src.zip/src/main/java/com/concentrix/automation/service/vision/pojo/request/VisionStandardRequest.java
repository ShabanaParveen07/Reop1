package com.concentrix.automation.service.vision.pojo.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
@NoArgsConstructor
public class VisionStandardRequest {

  public String emailId;
  public String candidateID;
  public String location;
  public String firstname;
  public String lastname;
  public String jobid;
  public String jobname;
  public String language;
  public boolean isexists;
  public List<Images> images;
}


