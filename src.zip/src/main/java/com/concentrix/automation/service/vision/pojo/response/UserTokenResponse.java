package com.concentrix.automation.service.vision.pojo.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserTokenResponse {

  @JsonProperty("emailId")
  public String emailId;
  @JsonProperty("candidateID")
  public String candidateID;
  @JsonProperty("location")
  public String location;
 @JsonProperty("firstname")
  public String firstname;
  @JsonProperty("middlename")
  public String middlename;
  @JsonProperty("lastname")
  public String lastname;
  @JsonProperty("jobid")
  public String jobid;
  @JsonProperty("jobname")
  public String jobname;
  @JsonProperty("language")
  public String language;
  @JsonProperty("isenrolled")
  public Boolean isenrolled;
  @JsonProperty("isexists")
  public Boolean isexists;
  @JsonProperty("isblocked")
  public Boolean isblocked;
}
