package com.concentrix.automation.service.streaming.pojo.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FaceAuthRequest {
    @JsonProperty("SSOId")
    private String sSOId;
    @JsonProperty("BlurImage")
    private String blurImage;
    @JsonProperty("ClearImage")
    private String clearImage;
    @JsonProperty("FaceAuthMode")
    private String faceAuthMode;
    @JsonProperty("ClientTimeStamp")
    private String clientTimeStamp;
    @JsonProperty("StreamingAppVersion")
    private String streamingAppVersion;
    @JsonProperty("BlurType")
    private String blurType;
    @JsonProperty("BLUR_KERNEL_SIZE")
    private Integer blurKernelSize;
    @JsonProperty("BlurBackgroundType")
    private String blurBackgroundType;
    @JsonProperty("SecondaryPersonBlurType")
    private String secondaryPersonBlurType;
    @JsonProperty("SystemIP")
    private String systemIP;
    @JsonProperty("SystemName")
    private String systemName;

}
