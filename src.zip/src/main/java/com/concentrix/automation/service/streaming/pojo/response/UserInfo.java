package com.concentrix.automation.service.streaming.pojo.response;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserInfo {

    @JsonProperty("userName")
    private String userName;

    @JsonProperty("isOTPAllowed")
    private Boolean isOtpAllowed;

    @JsonProperty("isSupervisorOTPAllowed")
    private Boolean isSupervisorOTPAllowed;

    @JsonProperty("isBackupCodeAllowed")
    private Boolean isBackUpCodeAllowed;

    @JsonProperty("ssoId")
    private String ssoId;

    @JsonProperty("enrollmentDate")
    private String enrollmentDate;

    @JsonProperty("rootCorrelationId")
    private String rootCorrelationId;

    @JsonProperty("correlationId")
    private String correlationId;


}
