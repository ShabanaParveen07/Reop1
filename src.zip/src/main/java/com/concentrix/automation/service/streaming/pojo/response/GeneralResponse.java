package com.concentrix.automation.service.streaming.pojo.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

/**
 * Modal for Response from all the requests
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class GeneralResponse {

    @JsonProperty("responseResult")
    private String responseResult;

    @JsonProperty("responseStatus")
    private String responseStatus;

    @JsonProperty("data")
    private String data;

    @JsonProperty("responseResult1")
    private String responseResult1;

    @JsonProperty("additionalProperties")
    private Map<String, Object> additionalProperties;

}
