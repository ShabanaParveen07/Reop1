package com.concentrix.automation.service.streaming.pojo.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ResponseResult {

    @JsonProperty("status")
    public Integer status;
    @JsonProperty("msg")
    public String msg;
    @JsonProperty("accuracy")
    public String accuracy;
    @JsonProperty("face_auth_mode")
    public Integer faceAuthMode;
    @JsonProperty("time")
    public Double time;
    @JsonProperty("recognition")
    public Integer recognition;
    @JsonProperty("result_id")
    public Integer resultId;
    @JsonProperty("is_spoof")
    public Boolean isSpoof;
    @JsonProperty("spoof_score")
    public Double spoofScore;
}
