package com.concentrix.automation.service.streaming.pojo.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AddEmployeeOTPCodeRequest {

  @JsonProperty("LanId")
  private String lanId;

  @JsonProperty("OtpCode")
  private String otpCode;

  @JsonProperty("IsLoginSuccess")
  private Boolean isLoginSuccess;

  @JsonProperty("IsSupervisorOTP")
  private Boolean isSupervisorOTP;

  @JsonProperty("IsOTPExpired")
  private Boolean isOTPExpired;
}
