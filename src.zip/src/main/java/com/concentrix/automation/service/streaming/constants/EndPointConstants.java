package com.concentrix.automation.service.streaming.constants;

import com.concentrix.automation.helper.ConfigurationFileHelper;

import java.io.File;

public class EndPointConstants {

    public static File BLOCKED_CAMERA_IMAGE = new File(System.getProperty("user.dir")+ File.separator + "src" + File.separator + "test" + File.separator + "resources" + File.separator + "Endpoint" + File.separator + "BlockedCamera.jpg");
    public static File CELL_PHONE_IMAGE = new File(System.getProperty("user.dir")+ File.separator + "src" + File.separator + "test" + File.separator + "resources" + File.separator + "Endpoint" + File.separator + "Cell-Phone.jpg");

    public static File BASE_LINE_IMAGE = new File(System.getProperty("user.dir")+ File.separator + "src" + File.separator + "test" + File.separator + "resources" + File.separator + "Endpoint" + File.separator + "BaseLine.jpg");

    public static String BLOCKED_CAMERA_SCREEN_GREY_OUT_ERROR = "Blocking Camera View detected, screen will be greyed out. Ensure camera has a clear view, click OK and then click on Resume to release the screen";

    public static String BLOCKED_CAMERA_SCREEN_GREY_OUT_ERROR_NEW = "42/BlockingCameraActionDataGrayOutKey:" + BLOCKED_CAMERA_SCREEN_GREY_OUT_ERROR;

    public static String CELLPHONE_ALERT_MESSAGE = "Cellphone is detected, please rectify to avoid screen grey out.";

    public static String CELL_PHONE_ALERT_MESSAGE_NEW = "Greyout Potential Reportable Event - Cellphone:"  + "Cellphone detected, please rectify to avoid screen grey out.";

    public static String NO_FACES_FOUND_LOCK_OUT_ERROR_MESSAGE = "Violation Detected - No Faces Found, Desktop will be locked.";

    public static String CELLPHONE_GREY_OUT_ERROR_MESSAGE = "Cellphone detected, screen will be greyed out. " +
            "Clear your workspace, click OK and then click on Resume to release the screen";

    public static String LOCK_OUT_ERROR_MESSAGE_NEW = "6/ActionDataDisplayAlertMessage:Violation Detected - {ViolationType}, Desktop will be locked.";

    public static String CELLPHONE_GREY_OUT_ERROR_MESSAGE_NEW = "0/PRECellphoneActionDataGrayOutKey:" + CELLPHONE_GREY_OUT_ERROR_MESSAGE;

    public static String statusY = "Y";

    public static String statusF = "F";

    public static Integer blockedCameraResultId = 42;

    public static String blockedCameraResultDescription = "Blocking Camera View";

    public static String screenGreyOutText = "ScreenGreyOut";
    public static String screenLockOutText = "ScreenLockOut";

    public static String showAlertText = "ShowAlert";

    public static String cellPhoneResultDescription = "Cell Phone";

    public static Integer cellPhonePREResultId = 44;

    public static Integer cellPhoneResultId = 17;

    public static Integer successResultId = 5;

    public static int responseOK = 200;

    public static File NO_FACES_FOUND_IMAGE = new File(System.getProperty("user.dir")+ File.separator + "src" + File.separator + "test" + File.separator + "resources" + File.separator + "Endpoint" + File.separator + "No_Faces_Found.jpg");


    public static File MULTIPLE_PERSONS_IMAGE = new File(System.getProperty("user.dir")+ File.separator + "src" + File.separator + "test" + File.separator + "resources" + File.separator + "Endpoint" + File.separator + "Multiple_Persons.jpg");

    public static String noFacesFoundResultDescription = "No Faces Found";

    public static Integer noFacesFoundResultId = 6;

    public static Integer facialAuthenticationFailedResultId = 20;

    public static String multiplePersonsResultDescription = "Multiple Persons";

    public static Integer multiplePersonsResultId = 16;

    public static Integer multiplePersonsPREResultId = 43;

    public static Integer spoofResultId = 9;

    public static Integer spoofPossibilityResultId = 91;


    public static String MULTIPLE_PERSONS_ALERT_MESSAGE = "Multiple persons detected, please rectify to avoid screen grey out.";

    public static String MULTIPLE_PERSONS_ALERT_MESSAGE_NEW = "Greyout Multiple Persons:Multiple persons detected, please rectify to avoid screen grey out.";

    public static String MULTIPLE_PERSONS_LOCK_OUT_ERROR_MESSAGE = "Violation Detected - Multiple Persons, Desktop will be locked.";
    public static String MULTIPLE_PERSONS_LOCK_OUT_ERROR_MESSAGE_NEW = "16/ActionDataDisplayAlertMessage:Violation Detected - {ViolationType}, Desktop will be locked.";

    public static String successDescription = "Success";

    public static int FACE_AUTH_MODE_STARTUP = 20;

    public static int FACE_AUTH_MODE_RESUME = 21;
    public static Integer RESULT_ID_WITH_NO_FACE_FOUND = 25;
    public static String NO_FACES_FOUND_ON_STARTUP_DESCRIPTION = "Facial authentication failed on startup (no faces found)";

    public static Integer noFacesFoundOnStartUpResultId = 23;

    public static String BLOCKED_CAMERA_ON_STARTUP_DESCRIPTION = "Camera view has been blocked, kindly clear the obstacle in front of the camera view";

    public static Integer blockedCameraOnStartupResulId = 45;

    public static Integer authenticationFailedOnStartUpResultId = 20;

    public static Integer unknownPersonResultId = 9;

    public static String unknownPersonDescription = "Unknown Person";

    public static String UNKNOWN_PERSON_ERROR = "Violation Detected - Unknown Person, Desktop will be locked.";

    public static String UNKNOWN_PERSON_ERROR_NEW = "9/ActionDataDisplayAlertMessage:Violation Detected - {ViolationType}, Desktop will be locked.";

    public static String AUTHENTICATION_FAILED_ON_STARTUP_RESULT_DESCRIPTION = "Facial authentication failed on startup";

    public static File OTHER_PERSON_IMAGE = new File(System.getProperty("user.dir")+ File.separator + "src" + File.separator + "test" + File.separator + "resources" + File.separator + "Endpoint" + File.separator + "Other_Person.jpeg");

    public static String NO_FACES_FOUND_ON_RESUME_DESCRIPTION = "Facial authentication failed on resume (no faces found)";

    public static Integer noFacesFoundOnResumeResultId = 25;

    public static String BLOCKED_CAMERA_ON_RESUME_DESCRIPTION = "Camera view has been blocked, kindly clear the obstacle in front of the camera view";

    public static String AUTHENTICATION_FAILED_ON_RESUME_RESULT_DESCRIPTION = "Facial authentication failed on resume";

    public static File SPOOF_IMAGE = new File(System.getProperty("user.dir")+ File.separator + "src" + File.separator + "test" + File.separator + "resources" + File.separator + "Endpoint" + File.separator + "Spoof_Image.jpg");

    public static int imageRecognized = 1;

    public static int imageNotRecognized = 0;

    public static double minimumAccuracy = 0.5;

    public static int FACE_AUTH_MODE_SESSION = 50;

}