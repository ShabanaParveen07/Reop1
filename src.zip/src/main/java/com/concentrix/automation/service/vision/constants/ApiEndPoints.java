package com.concentrix.automation.service.vision.constants;

public class ApiEndPoints {
  public static final String visionEnrollment = "/onboard/api/ExternalUser/Enrollment";
  public static final String tokenUrl = "/onboard/api/ExternalAuth/Token/{emailId}";
  public static final String imageValidationUrl = "/onboard/api/ExternalUser/Imagevalidation";
}
