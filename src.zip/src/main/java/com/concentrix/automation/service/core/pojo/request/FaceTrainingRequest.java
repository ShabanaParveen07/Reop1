package com.concentrix.automation.service.core.pojo.request;

import com.fasterxml.jackson.annotation.*;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FaceTrainingRequest {

  @JsonProperty("Image")
  private String image;
  @JsonProperty("LanID")
  private String lanID;
  @JsonProperty("SystemIP")
  private String systemIP;
  @JsonProperty("SystemName")
  private String systemName;
  @JsonProperty("EmployeeId")
  private String employeeId;
  @JsonProperty("Timestamp")
  private String timestamp;
  @JsonProperty("ImageProfile")
  private String imageProfile;

}

