package com.concentrix.automation.service.streaming.pojo.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetLastImageProcessedStatusResponse {

  @JsonProperty("imagebagid")
  private Long imageBagID;

  @JsonProperty("imagecachekey")
  private String imageCacheKey;

  @JsonProperty("result_desc")
  private String resultDescription;

  @JsonProperty("processedon")
  private String processedOn;

  @JsonProperty("result_id")
  private Integer resultId;

  @JsonProperty("status")
  private String status;

  @JsonProperty("result_desc1")
  private String resultDescription1;

  @JsonProperty("actions")
  private Actions[] actions;

  @JsonProperty("actionsNewFormat")
  private Actions[] actionsNewFormat;

  @JsonProperty("faceauthmode")
  private int faceAuthMode;
}
