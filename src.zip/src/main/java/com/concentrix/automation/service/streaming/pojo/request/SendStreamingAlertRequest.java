package com.concentrix.automation.service.streaming.pojo.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SendStreamingAlertRequest {

  @JsonProperty("ClientInfo")
  private String clientInfo;

  @JsonProperty("RootCorrelationId")
  private String rootCorrelationId;

  @JsonProperty("CorrelationId")
  private String correlationId;

  @JsonProperty("Data")
  private ClientEventData data;
}
