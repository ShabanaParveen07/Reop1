package com.concentrix.automation.service.corebr;

public class CoreBusinessRules {
}
